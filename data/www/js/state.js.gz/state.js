// 全局工具函数（从 utils.js 迁移，确保始终可用）
function escapeHtml(str) {
    if (str == null) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// 应用状态管理
const AppState = {
    currentPage: 'dashboard',
    configTab: 'modbus',
    currentUser: { name: '', role: '', canManageFs: false },
    sidebarCollapsed: false,
    _logAutoRefreshTimer: null,  // 日志自动刷新定时器

    // 已加载的模块记录
    _loadedModules: {},
    _moduleCallbacks: {},
    // 模块加载队列（有限并发加载，最多2个并发）
    _moduleLoadQueue: [],
    _moduleLoadingCount: 0,
    _MAX_CONCURRENT_LOADS: 2,

    // ============ 初始化 ============
    init() {
        this.setupTheme();  // 主题初始化
        this.setupUserDropdown(); // 用户下拉菜单
        this.setupSidebarToggle();
        this.setupLanguage();
        this.setupConfigTabs();
        this.setupEventListeners();
        this.setupGlobalEventDelegation(); // 全局事件委托
        this.refreshPage();
    },

    // ============ 全局事件委托 ============
    setupGlobalEventDelegation() {
        const self = this;
        // 全局事件委托 - 替代内联 onclick
        document.addEventListener('click', (e) => {
            const el = e.target.closest('[data-action]');
            if (!el) return;

            const action = el.dataset.action;
            const args = el.dataset.args ? el.dataset.args.split(',') : [];

            // 优先在 AppState 上查找方法，如果不存在则在 app 对象上查找
            if (typeof this[action] === 'function') {
                e.preventDefault();
                this[action](...args);
            } else if (typeof window.app !== 'undefined' && typeof window.app[action] === 'function') {
                e.preventDefault();
                window.app[action](...args);
            } else {
                // 方法尚未注册（模块可能还在加载中），延迟重试一次
                e.preventDefault();
                setTimeout(function() {
                    if (typeof self[action] === 'function') {
                        self[action](...args);
                    } else if (typeof window.app !== 'undefined' && typeof window.app[action] === 'function') {
                        window.app[action](...args);
                    }
                }, 800);
            }
        });

        // 全局 change 事件委托 - 替代内联 onchange
        document.addEventListener('change', (e) => {
            const el = e.target.closest('[data-change-action]');
            if (!el) return;

            const action = el.dataset.changeAction;
            const value = el.value;

            // 优先在 AppState 上查找方法，如果不存在则在 app 对象上查找
            if (typeof this[action] === 'function') {
                this[action](value);
            } else if (typeof window.app !== 'undefined' && typeof window.app[action] === 'function') {
                window.app[action](value);
            }
        });
    },

    // 触发 OTA 文件选择
    triggerOtaFileSelect() {
        const fileInput = document.getElementById('ota-file');
        if (fileInput) fileInput.click();
    },

    // 注册模块方法 - 将方法混入 AppState
    registerModule(name, methods) {
        const self = this;
        Object.keys(methods).forEach(key => {
            self[key] = typeof methods[key] === 'function' ? methods[key].bind(self) : methods[key];
        });
        self._loadedModules[name] = true;
        // 延迟执行回调，确保模块脚本中后续的 Object.assign 也完成
        if (self._moduleCallbacks[name]) {
            const cbs = self._moduleCallbacks[name];
            delete self._moduleCallbacks[name];
            setTimeout(function() {
                cbs.forEach(function(cb) { cb(); });
            }, 0);
        }
    },

    // 按需加载模块JS文件（串行加载，自动重试）
    _loadModule(name, callback) {
        const self = this;
        if (this._loadedModules[name]) {
            if (callback) callback();
            return;
        }
        // 注册回调
        if (callback) {
            if (!this._moduleCallbacks[name]) this._moduleCallbacks[name] = [];
            this._moduleCallbacks[name].push(callback);
        }
        // 如果已在队列中，不重复入队
        if (this._moduleLoadQueue.some(function(item) { return item.name === name; })) return;
        // 入队
        this._moduleLoadQueue.push({ name: name, retries: 0 });
        this._processModuleQueue();
    },

    // 有限并发处理模块加载队列（最多2个并发）
    _processModuleQueue() {
        const self = this;
        // 如果已达到最大并发数或队列为空，返回
        if (this._moduleLoadingCount >= this._MAX_CONCURRENT_LOADS || this._moduleLoadQueue.length === 0) return;

        // 找到第一个未在加载中的模块
        let item = null;
        for (let i = 0; i < this._moduleLoadQueue.length; i++) {
            if (!this._moduleLoadQueue[i].loading) {
                item = this._moduleLoadQueue[i];
                break;
            }
        }
        if (!item) return;

        // 如果模块已加载（可能在排队期间被另一个回调加载了）
        if (this._loadedModules[item.name]) {
            this._moduleLoadQueue = this._moduleLoadQueue.filter(q => q.name !== item.name);
            this._processModuleQueue();
            return;
        }

        item.loading = true;
        this._moduleLoadingCount++;

        // 移除可能存在的旧 script 标签（失败后清理）
        const oldScript = document.querySelector('script[data-module="' + item.name + '"]');
        if (oldScript) oldScript.remove();

        const script = document.createElement('script');
        script.src = '/js/modules/' + item.name + '.js';
        script.dataset.module = item.name;

        script.onload = function() {
            self._moduleLoadingCount--;
            // 从队列中移除
            self._moduleLoadQueue = self._moduleLoadQueue.filter(q => q.name !== item.name);
            // 立即尝试加载下一个（减少延迟）
            setTimeout(function() { self._processModuleQueue(); }, 10);
        };

        script.onerror = function() {
            console.warn('[Module] Failed to load: ' + item.name + ' (attempt ' + (item.retries + 1) + '/3)');
            script.remove();
            self._moduleLoadingCount--;
            item.loading = false;

            if (item.retries < 2) {
                item.retries++;
                // 延迟重试，给 ESP32 喘息时间
                setTimeout(function() { self._processModuleQueue(); }, 1000);
            } else {
                console.error('[Module] Giving up loading: ' + item.name);
                self._moduleLoadQueue = self._moduleLoadQueue.filter(q => q.name !== item.name);
                // 继续加载队列中的下一个
                setTimeout(function() { self._processModuleQueue(); }, 200);
            }
        };

        document.head.appendChild(script);

        // 尝试并发加载下一个
        this._processModuleQueue();
    },

    // ============ 用户下拉菜单 ============
    setupUserDropdown() {
        const dropdownBtn = document.getElementById('user-dropdown-btn');
        const dropdownMenu = document.getElementById('user-dropdown-menu');
        
        if (!dropdownBtn || !dropdownMenu) return;
        
        // 切换下拉菜单显示
        dropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const dropdown = dropdownBtn.closest('.user-dropdown');
            dropdown.classList.toggle('open');
        });
        
        // 点击外部关闭下拉菜单
        document.addEventListener('click', (e) => {
            if (!dropdownBtn.contains(e.target) && !dropdownMenu.contains(e.target)) {
                const dropdown = dropdownBtn.closest('.user-dropdown');
                if (dropdown) dropdown.classList.remove('open');
            }
        });
        
        // 点击菜单项后关闭下拉菜单
        dropdownMenu.querySelectorAll('.dropdown-item').forEach(item => {
            item.addEventListener('click', () => {
                const dropdown = dropdownBtn.closest('.user-dropdown');
                if (dropdown) dropdown.classList.remove('open');
            });
        });
    },

    // ============ 主题管理 ============
    setupTheme() {
        // 检测系统主题偏好
        const savedTheme = localStorage.getItem('theme');
        const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        
        // 优先级: 用户手动设置 > 系统偏好
        let theme;
        if (savedTheme) {
            theme = savedTheme;
        } else {
            theme = systemPrefersDark ? 'dark' : 'light';
            // 标记为自动模式（未手动设置）
            localStorage.setItem('theme-auto', 'true');
        }
        
        this.setTheme(theme, false);
        this.updateThemeToggleIcon(theme);
        
        // 绑定主题切换按钮 (下拉菜单中的)
        const themeToggleItem = document.getElementById('theme-toggle-item');
        if (themeToggleItem) {
            themeToggleItem.addEventListener('click', () => this.toggleTheme());
        }
        
        // 监听系统主题变化（仅在自动模式下）
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            const isAutoMode = localStorage.getItem('theme-auto') === 'true';
            if (isAutoMode) {
                const newTheme = e.matches ? 'dark' : 'light';
                this.setTheme(newTheme, false);
                this.updateThemeToggleIcon(newTheme);
            }
        });
    },
    
    setTheme(theme, isManual = true) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        // 如果是手动设置，清除自动模式标记
        if (isManual) {
            localStorage.removeItem('theme-auto');
        }
        
        this.updateThemeToggleIcon(theme);
    },
    
    toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'dark' ? 'light' : 'dark';
        this.setTheme(newTheme, true);
    },
    
    updateThemeToggleIcon(theme) {
        const themeToggleItem = document.getElementById('theme-toggle-item');
        if (themeToggleItem) {
            const iconSpan = themeToggleItem.querySelector('.item-icon');
            const textSpan = themeToggleItem.querySelector('span:not(.item-icon)');
            
            if (iconSpan) {
                iconSpan.textContent = theme === 'dark' ? '☀' : '🌙';
            }
            if (textSpan) {
                // 获取当前语言的翻译
                const key = theme === 'dark' ? 'theme-light' : 'theme-dark';
                const translated = window.i18n ? window.i18n.t(key) : (theme === 'dark' ? '浅色模式' : '深色模式');
                textSpan.textContent = translated;
            }
        }
    },

    // ============ 会话验证 ============
    refreshPage() {
        const token = localStorage.getItem('auth_token');

        // 在 API 调用前保存"记住密码"凭据到局部变量
        // （防止 401 处理器清除 localStorage 中的凭据）
        const savedRemember = localStorage.getItem('remember');
        const savedUsername = localStorage.getItem('username');
        const savedPassword = localStorage.getItem('password');

        if (!token) {
            // 没有 token，尝试使用保存的凭据自动登录
            this._tryAutoLogin(savedRemember, savedUsername, savedPassword);
            return;
        }
        apiGet('/api/auth/session')
            .then(res => {
                if (res && res.success && res.data && res.data.sessionValid) {
                    this.currentUser.name = res.data.username || 'Admin';
                    this.currentUser.role = res.data.role || 'VIEWER';
                    this.currentUser.canManageFs = res.data.canManageFs === true;
                    this._showAppPage();
                    this._loadModule('dashboard', () => {
                        this.renderDashboard();
                        this.loadSystemMonitor();
                    });
                    this._loadModule('users', () => this.loadUsers());
                } else {
                    // 会话无效，尝试使用保存的凭据重新登录
                    this._tryAutoLogin(savedRemember, savedUsername, savedPassword);
                }
            })
            .catch(() => {
                // 会话验证失败（如 401），尝试自动重新登录
                this._tryAutoLogin(savedRemember, savedUsername, savedPassword);
            });
    },

    // 尝试使用保存的凭据自动登录
    _tryAutoLogin(remember, username, password) {
        if (remember === 'true' && username && password) {
            apiPost('/api/auth/login', { username, password })
                .then(res => {
                    if (res && res.success) {
                        const sid = res.sessionId;
                        localStorage.setItem('auth_token', sid);
                        localStorage.setItem('sessionId', sid);
                        // 恢复"记住密码"凭据（可能已被 401 处理器清除）
                        localStorage.setItem('remember', 'true');
                        localStorage.setItem('username', username);
                        localStorage.setItem('password', password);

                        this.currentUser.name = res.username || username;
                        sessionStorage.setItem('currentUsername', this.currentUser.name);

                        // 获取角色和权限信息
                        apiGet('/api/auth/session').then(sr => {
                            if (sr && sr.success && sr.data) {
                                this.currentUser.role = sr.data.role || 'VIEWER';
                                this.currentUser.canManageFs = sr.data.canManageFs === true;
                            }
                        }).catch(() => {});

                        this._showAppPage();
                        this._loadModule('dashboard', () => {
                            this.renderDashboard();
                            this.loadSystemMonitor();
                        });
                        this._loadModule('users', () => this.loadUsers());
                    } else {
                        // 自动登录失败（如密码已更改），清除无效凭据并显示登录页
                        localStorage.removeItem('password');
                        localStorage.removeItem('remember');
                        this._showLoginPage();
                    }
                })
                .catch(() => {
                    this._showLoginPage();
                });
        } else {
            this._showLoginPage();
        }
    },

    _showLoginPage() {
        document.getElementById('login-page').style.display = 'flex';
        document.getElementById('app-container').style.display = 'none';

        // 预填充已保存的用户名和"记住密码"状态
        const savedUsername = localStorage.getItem('username');
        const savedRemember = localStorage.getItem('remember');
        const usernameInput = document.getElementById('username');
        const rememberCheckbox = document.getElementById('remember');
        if (usernameInput && savedUsername) usernameInput.value = savedUsername;
        if (rememberCheckbox && savedRemember === 'true') rememberCheckbox.checked = true;
    },

    _showAppPage() {
        document.getElementById('login-page').style.display = 'none';
        document.getElementById('app-container').style.display = 'block';
        // 登录成功后将URL从 /login 等路径重定向到根路径 /
        if (location.pathname !== '/' || location.hash) {
            history.replaceState(null, '', '/');
        }
    },

    // ============ 通用折叠面板 ============
    toggleSection(bodyId) {
        const body = document.getElementById(bodyId);
        const icon = document.getElementById(bodyId + '-icon');
        if (!body) return;
        if (body.style.display === 'none' || !body.style.display) {
            body.style.display = 'block';
            if (icon) icon.innerHTML = '&#9660;';
        } else {
            body.style.display = 'none';
            if (icon) icon.innerHTML = '&#9654;';
        }
    },

    // ============ 侧边栏 ============
    setupSidebarToggle() {
        const btn = document.getElementById('sidebar-toggle');
        if (btn) btn.addEventListener('click', () => this.toggleSidebar());
        if (localStorage.getItem('sidebarCollapsed') === 'true') this.collapseSidebar();
    },

    toggleSidebar() {
        // 移动端使用 expanded 类，桌面端使用 collapsed 类
        const sidebar = document.getElementById('sidebar');
        if (!sidebar) return;
        
        // 检测是否为移动端
        const isMobile = window.innerWidth <= 768;
        
        if (isMobile) {
            // 移动端：切换 expanded 类
            if (sidebar.classList.contains('expanded')) {
                sidebar.classList.remove('expanded');
                this.sidebarCollapsed = true;
                const btn = document.getElementById('sidebar-toggle');
                if (btn) btn.textContent = '☰';
            } else {
                sidebar.classList.add('expanded');
                this.sidebarCollapsed = false;
                const btn = document.getElementById('sidebar-toggle');
                if (btn) btn.textContent = '✕';
            }
        } else {
            // 桌面端：使用原有逻辑
            this.sidebarCollapsed ? this.expandSidebar() : this.collapseSidebar();
        }
    },

    collapseSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) {
            sidebar.classList.add('collapsed');
            sidebar.classList.remove('expanded');
            this.sidebarCollapsed = true;
            localStorage.setItem('sidebarCollapsed', 'true');
            const btn = document.getElementById('sidebar-toggle');
            if (btn) btn.textContent = '☰';
        }
    },

    expandSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) {
            sidebar.classList.remove('collapsed');
            this.sidebarCollapsed = false;
            localStorage.setItem('sidebarCollapsed', 'false');
            const btn = document.getElementById('sidebar-toggle');
            if (btn) btn.textContent = '✕';
        }
    },

    // ============ 语言 ============
    setupLanguage() {
        // 初始化时立即应用 i18n 到登录页（在登录前就需要正确显示）
        i18n.updatePageText();

        // 登录页语言切换
        const loginLangSelect = document.getElementById('login-language-select');
        if (loginLangSelect) {
            loginLangSelect.value = i18n.currentLang;
            loginLangSelect.addEventListener('change', e => {
                i18n.setLanguage(e.target.value);
                // 同步主应用的语言选择器
                const mainSelect = document.getElementById('language-select');
                if (mainSelect) mainSelect.value = e.target.value;
            });
        }

        // 主应用语言切换
        const langSelect = document.getElementById('language-select');
        if (langSelect) {
            langSelect.value = i18n.currentLang;
            langSelect.addEventListener('change', e => {
                i18n.setLanguage(e.target.value);
                // 同步登录页的语言选择器
                if (loginLangSelect) loginLangSelect.value = e.target.value;
                // 刷新当前页面的动态 i18n 内容（安全调用已加载的模块方法）
                if (typeof this.renderDashboard === 'function') this.renderDashboard();
                if (typeof this.loadSystemMonitor === 'function') this.loadSystemMonitor();
                if (typeof this.loadUsers === 'function') this.loadUsers();
            });
        }
    },

    // ============ 配置选项卡 ============
    setupConfigTabs() {
        ['#protocol-page', '#network-page', '#device-page'].forEach(pageSelector => {
            const page = document.querySelector(pageSelector);
            if (!page) return;
            page.querySelectorAll('.config-tab').forEach(tab => {
                tab.addEventListener('click', () => {
                    this.showConfigTab(pageSelector.replace('#', ''), tab.getAttribute('data-tab'));
                });
            });
        });

        // 协议配置表单提交
        document.querySelectorAll('#protocol-page form').forEach(form => {
            form.addEventListener('submit', e => {
                e.preventDefault();
                if (typeof this.saveProtocolConfig === 'function') this.saveProtocolConfig(form.id);
            });
        });
        
        // MQTT增加主题按钮
        const addMqttTopicBtn = document.getElementById('add-mqtt-topic-btn');
        if (addMqttTopicBtn) {
            addMqttTopicBtn.addEventListener('click', () => {
                if (typeof this.addMqttPublishTopic === 'function') this.addMqttPublishTopic();
            });
        }
        
        // MQTT增加订阅按钮
        const addMqttSubscribeBtn = document.getElementById('add-mqtt-subscribe-btn');
        if (addMqttSubscribeBtn) {
            addMqttSubscribeBtn.addEventListener('click', () => {
                if (typeof this.addMqttSubscribeTopic === 'function') this.addMqttSubscribeTopic();
            });
        }

        // MQTT客户端ID或认证方式修改时，清除测试结果提示
        const mqttTestResultEl = document.getElementById('mqtt-test-result');
        if (mqttTestResultEl) {
            const clearTestResult = () => { mqttTestResultEl.textContent = ''; };
            const cidEl = document.getElementById('mqtt-client-id');
            const atEl = document.getElementById('mqtt-auth-type');
            if (cidEl) cidEl.addEventListener('input', clearTestResult);
            if (atEl) atEl.addEventListener('change', clearTestResult);
        }

        // 网络配置表单已在 setupNetworkFormHandlers() 中专门处理，无需通用监听
    },

    _getProtocolName(formId) {
        const map = { 'modbus-rtu': 'Modbus RTU', 'modbus-tcp': 'Modbus TCP', mqtt: 'MQTT', http: 'HTTP', coap: 'CoAP' };
        for (const key of Object.keys(map)) {
            if (formId.includes(key)) return map[key];
        }
        return 'TCP';
    },

    showConfigTab(pageId, tabId) {
        const page = document.getElementById(pageId);
        if (!page) return;
        page.querySelectorAll('.config-tab').forEach(t => {
            t.classList.toggle('active', t.getAttribute('data-tab') === tabId);
        });
        page.querySelectorAll('.config-content').forEach(c => c.classList.remove('active'));
        const target = page.querySelector(`#${tabId}`);
        if (target) target.classList.add('active');
        
        // 切换到协议配置页面时自动加载配置
        if (pageId === 'protocol-page') {
            if (typeof this.loadProtocolConfig === 'function') this.loadProtocolConfig(tabId);
        }
        
        // 切换到设备监控页面时自动加载网络状态
        if (pageId === 'dashboard-page') {
            if (typeof this.loadNetworkStatus === 'function') this.loadNetworkStatus();
        }
        // 切换到NTP时间tab时自动加载时间
        if (pageId === 'device-page' && tabId === 'dev-ntp') {
            if (typeof this.loadDeviceTime === 'function') this.loadDeviceTime();
        }
        // 切换到基本信息tab时自动加载硬件信息
        if (pageId === 'device-page' && tabId === 'dev-basic') {
            if (typeof this._loadDeviceHardwareInfo === 'function') this._loadDeviceHardwareInfo();
        }
        // 切换到热点配置tab时自动加载配网状态
        if (pageId === 'network-page' && tabId === 'ap-config') {
            if (typeof this.loadProvisionStatus === 'function') this.loadProvisionStatus();
        }
        // 切换到蓝牙配网tab时自动加载蓝牙配网状态和配置
        if (pageId === 'device-page' && tabId === 'dev-ble') {
            if (typeof this.loadBLEProvisionStatus === 'function') this.loadBLEProvisionStatus();
            if (typeof this.loadBLEProvisionConfig === 'function') this.loadBLEProvisionConfig();
        }
        // 切换到OTA升级tab时自动加载OTA状态
        if (pageId === 'device-page' && tabId === 'dev-ota') {
            if (typeof this.loadOtaStatus === 'function') this.loadOtaStatus();
        }
    },

    // ============ 事件绑定（仅通用事件） ============
    setupEventListeners() {
        // 登录表单
        const loginForm = document.getElementById('login-form');
        if (loginForm) loginForm.addEventListener('submit', e => { e.preventDefault(); this.handleLogin(); });

        // 菜单
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', e => { e.preventDefault(); this.changePage(item.dataset.page); });
        });

        // 修改密码
        const changePwdBtn = document.getElementById('change-password-btn');
        if (changePwdBtn) changePwdBtn.addEventListener('click', () => this.showChangePasswordModal());

        // 退出登录
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) logoutBtn.addEventListener('click', () => this.logout());

        // 模态窗关闭
        const closeId = (id) => { const el = document.getElementById(id); if (el) el.style.display = 'none'; };
        ['close-password-modal', 'cancel-password-btn'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('click', () => closeId('change-password-modal'));
        });

        // 确认修改密码
        const confirmPwd = document.getElementById('confirm-password-btn');
        if (confirmPwd) confirmPwd.addEventListener('click', () => this.changePassword());

        // 移动端侧边栏：点击菜单项后自动收起
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', () => {
                const sidebar = document.getElementById('sidebar');
                if (sidebar && window.innerWidth <= 768 && sidebar.classList.contains('expanded')) {
                    sidebar.classList.remove('expanded');
                    this.sidebarCollapsed = true;
                    const btn = document.getElementById('sidebar-toggle');
                    if (btn) btn.textContent = '☰';
                }
            });
        });
    },

    // ============ 登录 ============
    handleLogin() {
        const username = (document.getElementById('username') || {}).value;
        const password = (document.getElementById('password') || {}).value;
        const remember = (document.getElementById('remember') || {}).checked;

        if (!username || !password) {
            Notification.warning(i18n.t('login-empty-warning'), i18n.t('login-fail-title'));
            return;
        }

        const submitBtn = document.querySelector('#login-form button[type="submit"]');
        const originalText = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) { submitBtn.innerHTML = i18n.t('login-logging-in-html'); submitBtn.disabled = true; }

        apiPost('/api/auth/login', { username, password })
            .then(res => {
                if (res && res.success) {
                    const sid = res.sessionId;

                    // 保存 token 到 localStorage，fetch-api.js 会自动注入 Authorization 头
                    localStorage.setItem('auth_token', sid);

                    // 记住密码
                    if (remember) {
                        localStorage.setItem('remember', 'true');
                        localStorage.setItem('username', username);
                        localStorage.setItem('password', password);  // 保存密码用于自动填充
                        localStorage.setItem('sessionId', sid);
                    } else {
                        ['remember', 'username', 'password', 'sessionId'].forEach(k => localStorage.removeItem(k));
                    }

                    this.currentUser.name = res.username || username;
                    sessionStorage.setItem('currentUsername', this.currentUser.name);

                    // 获取角色和权限信息
                    apiGet('/api/auth/session').then(sr => {
                        if (sr && sr.success && sr.data) {
                            this.currentUser.role = sr.data.role || 'VIEWER';
                            this.currentUser.canManageFs = sr.data.canManageFs === true;
                        }
                    }).catch(() => {});

                    this._showAppPage();
                    this._loadModule('dashboard', () => {
                        this.renderDashboard();
                        this.loadSystemMonitor();
                    });
                    this._loadModule('users', () => this.loadUsers());
                    Notification.success(i18n.t('login-success-msg'), i18n.t('login-welcome-title'));
                } else {
                    Notification.error((res && res.error) || i18n.t('login-fail-title'), i18n.t('login-fail-title'));
                }
            })
            .catch((err) => {
                // 登录失败，显示错误信息
                const errorMsg = (err && err.data && err.data.error) || i18n.t('login-fail-msg');
                Notification.error(errorMsg, i18n.t('login-fail-title'));
            })
            .finally(() => {
                if (submitBtn) { submitBtn.innerHTML = originalText; submitBtn.disabled = false; }
            });
    },

    // ============ 页面切换 ============
    changePage(page) {
        const pageAlias = { monitor: 'dashboard' };
        const normalizedPage = pageAlias[page] || page;
        
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const target = document.getElementById(normalizedPage + '-page');
        if (!target) {
            console.warn('[changePage] target page not found:', page, '=>', normalizedPage);
            return;
        }
        target.classList.add('active');

        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.toggle('active', item.dataset.page === normalizedPage);
        });

        const titleKey = `page-title-${normalizedPage}`;
        const titleEl = document.getElementById('page-title');
        if (titleEl) titleEl.textContent = i18n.t(titleKey);

        this.currentPage = normalizedPage;

        // 模块名到页面的映射
        const pageModuleMap = {
            dashboard: 'dashboard',
            network: 'network',
            device: 'device-config',
            users: 'users',
            roles: 'roles',
            peripheral: 'peripherals',
            'periph-exec': 'periph-exec',
            protocol: 'protocol',
            'rule-script': 'rule-script',
            data: 'files',
            logs: 'logs',
            'device-control': 'device-control'
        };

        // 按需加载模块并执行页面加载器
        const pageLoaders = {
            dashboard: () => { this.renderDashboard(); this.loadSystemMonitor(); },
            network: () => { this.loadNetworkConfig(); },
            device: () => { this.loadDeviceConfig(); },
            users: () => { this.loadUsers(); },
            roles: () => { this.loadRoles(); },
            peripheral: () => { this.loadPeripherals(); },
            'periph-exec': () => { this.loadPeriphExecPage(); },
            protocol: () => { this.loadProtocolConfig('mqtt'); if (this._startMqttStatusPolling) this._startMqttStatusPolling(); },
            'rule-script': () => { this.loadRuleScriptPage(); },
            data: () => { this.loadFileTree('/'); this.loadFileSystemInfo(); },
            logs: () => {
                this._currentLogFile = 'system.log';
                const currentSpan = document.getElementById('current-log-file');
                if (currentSpan) currentSpan.textContent = i18n.t('log-current-file-prefix') + this._currentLogFile;
                this.loadLogs();
                const autoRefresh = document.getElementById('log-auto-refresh');
                if (autoRefresh && autoRefresh.checked) {
                    this.startLogAutoRefresh();
                }
            },
            'device-control': () => {
                // 模块可能已加载，检查方法是否存在
                if (typeof this.loadDeviceControlPage === 'function') {
                    this.loadDeviceControlPage();
                } else {
                    console.warn('[changePage] loadDeviceControlPage not available, module may not be loaded');
                    // 显示加载提示（使用正确的元素 ID：dc-content）
                    var content = document.getElementById('dc-content');
                    if (content) {
                        content.innerHTML = '<div class="dc-empty">⏳ ' + i18n.t('loading') + '</div>';
                        // 延迟重试一次
                        var self = this;
                        setTimeout(function() {
                            if (typeof self.loadDeviceControlPage === 'function') {
                                self.loadDeviceControlPage();
                            } else {
                                content.innerHTML = '<div class="dc-empty" style="color:var(--danger);">❌ 模块加载失败，请刷新页面重试</div>';
                            }
                        }, 1000);
                    } else {
                        console.error('[changePage] dc-content element not found!');
                    }
                }
            }
        };

        // 日志页面离开时停止自动刷新
        if (normalizedPage !== 'logs' && this._logAutoRefreshTimer) {
            clearInterval(this._logAutoRefreshTimer);
            this._logAutoRefreshTimer = null;
        }

        // 停止协议页面的所有轮询（如果离开协议页面）
        if (normalizedPage !== 'protocol') {
            // 停止 MQTT 状态轮询
            if (typeof this._stopMqttStatusPolling === 'function') {
                this._stopMqttStatusPolling();
            }
            // 停止 Modbus 主站状态轮询
            if (typeof this._stopMasterStatusRefresh === 'function') {
                this._stopMasterStatusRefresh();
            }
            // 停止 Modbus 线圈自动刷新
            if (this._coilAutoRefreshTimer) {
                clearInterval(this._coilAutoRefreshTimer);
                this._coilAutoRefreshTimer = null;
            }
            // 停止 PID 自动刷新
            if (typeof this._stopPidAutoRefresh === 'function') {
                this._stopPidAutoRefresh();
            }
        }

        const moduleName = pageModuleMap[normalizedPage];
        const loader = pageLoaders[normalizedPage];
        
        if (moduleName && loader) {
            this._loadModule(moduleName, loader);
        } else if (loader) {
            loader();
        } else {
            console.warn('[changePage] no page loader mapped for:', normalizedPage);
        }
    },

    // ============ 修改密码 ============
    showChangePasswordModal() {
        const modal = document.getElementById('change-password-modal');
        if (modal) modal.style.display = 'flex';
        ['current-password-input', 'new-password-input', 'confirm-password-input'].forEach(id => {
            const el = document.getElementById(id); if (el) el.value = '';
        });
        const errDiv = document.getElementById('password-error');
        if (errDiv) errDiv.style.display = 'none';
    },

    changePassword() {
        const oldPwd = (document.getElementById('current-password-input') || {}).value || '';
        const newPwd = (document.getElementById('new-password-input') || {}).value || '';
        const confirmPwd = (document.getElementById('confirm-password-input') || {}).value || '';
        const errDiv = document.getElementById('password-error');

        const showErr = (msg) => {
            if (errDiv) { errDiv.textContent = msg; errDiv.style.display = 'block'; }
            Notification.error(msg, i18n.t('change-pwd-fail'));
        };

        if (!oldPwd || !newPwd || !confirmPwd) return showErr(i18n.t('validate-all-fields'));
        if (newPwd !== confirmPwd) return showErr(i18n.t('password-error') || i18n.t('validate-new-pwd-mismatch'));
        if (newPwd.length < 6) return showErr(i18n.t('validate-new-pwd-len'));

        if (errDiv) errDiv.style.display = 'none';

        const btn = document.getElementById('confirm-password-btn');
        if (btn) { btn.disabled = true; btn.textContent = i18n.t('change-pwd-submitting'); }

        apiPost('/api/auth/change-password', { oldPassword: oldPwd, newPassword: newPwd })
            .then(res => {
                if (res && res.success) {
                    Notification.success(i18n.t('change-pwd-success-msg'), i18n.t('change-pwd-success-title'));
                    const modal = document.getElementById('change-password-modal');
                    if (modal) modal.style.display = 'none';
                    // 修改密码后后端会踢出所有会话，需重新登录
                    setTimeout(() => {
                        localStorage.removeItem('auth_token');
                        this._showLoginPage();
                    }, 1500);
                } else {
                    showErr((res && res.error) || i18n.t('change-pwd-fail-msg'));
                }
            })
            .catch(() => {})
            .finally(() => { if (btn) { btn.disabled = false; btn.textContent = i18n.t('confirm-change-btn'); } });
    },

    // ============ 退出登录 ============
    logout() {
        if (!confirm(i18n.t('logout-confirm') || '确定要退出登录吗？')) return;

        this._showLoginPage();
        document.getElementById('login-form') && document.getElementById('login-form').reset();

        apiPost('/api/auth/logout', {})
            .then(() => {})
            .catch(() => {})
            .finally(() => {
                localStorage.removeItem('auth_token');
                localStorage.removeItem('sessionId');
                localStorage.removeItem('password');
                sessionStorage.removeItem('savedPassword');
                sessionStorage.removeItem('currentUsername');
                Notification.success(i18n.t('logout-success'), i18n.t('logout-title'));
            });
    },

    // ============ 关闭所有浮层（token 过期时调用）============
    closeAllOverlays() {
        // 1. 关闭所有 .modal 弹窗
        document.querySelectorAll('.modal').forEach(function (m) {
            m.style.display = 'none';
        });

        // 2. 关闭动态创建的全屏浮层（如角色权限详情弹窗）
        document.querySelectorAll('div[style*="position: fixed"][style*="z-index"]').forEach(function (el) {
            // 排除 Notification 容器等非弹窗元素
            if (el.querySelector('.modal-content, [onclick*="remove"]')) {
                el.remove();
            }
        });

        // 3. 关闭用户下拉菜单
        document.querySelectorAll('.user-dropdown.open').forEach(function (d) {
            d.classList.remove('open');
        });

        // 4. 停止日志自动刷新定时器
        if (typeof this.stopLogAutoRefresh === 'function') this.stopLogAutoRefresh();

        // 5. 停止 MQTT 状态轮询（如有）
        if (typeof this._stopMqttStatusPolling === 'function') {
            this._stopMqttStatusPolling();
        }
    },

    // ============ 工具方法 ============
    getAuthHeader() {
        const token = localStorage.getItem('auth_token');
        return token ? { 'Authorization': `Bearer ${token}` } : {};
    },

    /**
     * 设置文本内容
     */
    _setText(id, text) {
        const el = document.getElementById(id);
        if (el) el.textContent = text;
    },

    /**
     * 设置 HTML 内容
     */
    _setHtml(id, html) {
        const el = document.getElementById(id);
        if (el) el.innerHTML = html;
    },

    /**
     * 设置进度条宽度
     */
    _setBar(id, percent) {
        const el = document.getElementById(id);
        if (el) el.style.width = Math.min(percent, 100) + '%';
    },

    /**
     * 格式化字节数
     */
    _formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    /**
     * 设置表单元素的值（支持 input, select, textarea）
     * @param {string} id - 元素 ID
     * @param {string|number} value - 要设置的值
     */
    _setValue(id, value) {
        const el = document.getElementById(id);
        if (el) el.value = value;
    },

    /**
     * 设置复选框的选中状态
     * @param {string} id - 复选框元素 ID
     * @param {boolean} checked - 是否选中
     */
    _setCheckbox(id, checked) {
        const el = document.getElementById(id);
        if (el) el.checked = !!checked;
    },

    /**
     * 设置复选框的选中状态（_setCheckbox 的别名）
     * @param {string} id - 复选框元素 ID
     * @param {boolean} checked - 是否选中
     */
    _setChecked(id, checked) {
        this._setCheckbox(id, checked);
    },

    /**
     * 显示/隐藏消息提示元素
     * @param {string} id - 元素 ID
     * @param {boolean} show - true 显示，false 隐藏
     */
    _showMessage(id, show) {
        const el = document.getElementById(id);
        if (el) el.style.display = show ? 'block' : 'none';
    },

    /**
     * 设置元素的文本内容（与 _setText 功能相同，提供兼容性别名）
     * @param {string} id - 元素 ID
     * @param {string} text - 文本内容
     */
    _setTextContent(id, text) {
        this._setText(id, text);
    }
};
