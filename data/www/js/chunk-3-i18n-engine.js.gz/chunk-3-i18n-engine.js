var i18n=typeof i18n!=='undefined'?i18n:(function (){
var _translations={};
var _currentLang='zh-CN';
var _zhLoaded=false;
var _enLoaded=false;
var _loading=false;
return {
currentLang:_currentLang,
_zhLoaded:false,
_enLoaded:false,
t:function (key){
if(!key)return '';
var langData=_translations[_currentLang];
if(langData&&langData[key]!==undefined){
return langData[key];
}
var zhData=_translations['zh-CN'];
if(zhData&&zhData[key]!==undefined){
return zhData[key];
}
return key;
},
addTranslations:function (lang,data){
if(!lang||!data)return ;
_translations[lang]=data;
if(lang==='zh-CN')this._zhLoaded=true;
if(lang==='en')this._enLoaded=true;
},
mergeTranslations:function (lang,data){
if(!lang||!data)return ;
if(!_translations[lang])_translations[lang]={};
var target=_translations[lang];
var keys=Object.keys(data);
for(var i=0;i<keys.length;i++){
target[keys[i]]=data[keys[i]];
}
},
isLanguageLoaded:function (lang){
if(lang==='zh-CN')return this._zhLoaded;
if(lang==='en')return this._enLoaded;
return !!_translations[lang];
},
isLanguageLoading:function (){
return _loading;
},
loadLanguagePack:function (lang,cb){
var self=this;
if(self.isLanguageLoaded(lang)){
if(cb)cb(true);
return ;
}
_loading=true;
var fileMap={'zh-CN':'i18n-zh-CN','en':'i18n-en'};
var fileName=fileMap[lang];
if(!fileName){
_loading=false;
if(cb)cb(false);
return ;
}
var script=document.createElement('script');
var basePath='./js/modules/'+fileName+'.js';
script.src=(typeof window.__fastbeeResolveAssetUrl==='function')
?window.__fastbeeResolveAssetUrl(basePath)
:basePath;
script.onload=function (){
_loading=false;
if(cb)cb(true);
};
script.onerror=function (){
_loading=false;
if(cb)cb(false);
};
document.head.appendChild(script);
},
setLanguage:function (lang,cb){
var self=this;
_currentLang=lang||'zh-CN';
self.currentLang=_currentLang;
localStorage.setItem('language',_currentLang);
if(self.isLanguageLoaded(_currentLang)){
self.updatePageText();
if(cb)cb(true);
return true;
}
self.loadLanguagePack(_currentLang,function (ok){
if(ok)self.updatePageText();
if(cb)cb(ok);
});
return true;
},
updatePageText:function (root){
var scope=root||document;
var elements=scope.querySelectorAll('[data-i18n]');
for(var i=0;i<elements.length;i++){
var el=elements[i];
var key=el.getAttribute('data-i18n');
if(!key)continue;
var translation=this.t(key);
if(translation!==key){
el.textContent=translation;
}
}
var placeholders=scope.querySelectorAll('[data-i18n-placeholder]');
for(var j=0;j<placeholders.length;j++){
var pel=placeholders[j];
var pkey=pel.getAttribute('data-i18n-placeholder');
if(!pkey)continue;
var ptrans=this.t(pkey);
if(ptrans!==pkey){
pel.placeholder=ptrans;
}
}
}
};
})();