(function (){
'use strict';
AppState._sseSource=null;
AppState._sseHandlers={};
AppState._sseReconnectTimer=null;
AppState._sseReconnectDelay=1000;
AppState.connectSSE=function (){
if(this._sseSource)return ;
try{
this._sseSource=new EventSource('/api/events');
this._sseReconnectDelay=1000;
this._sseSource.onopen=function (){};
this._sseSource.onerror=function (){
console.warn('[SSE] 连接错误，将自动重连');
this.disconnectSSE();
var hasHandlers=false;
var handlers=this._sseHandlers||{};
for(var key in handlers){
if(handlers.hasOwnProperty(key)&&handlers[key]&&handlers[key].length>0){
hasHandlers=true;
break;
}
}
if(!hasHandlers){
return ;
}
this._sseReconnectTimer=setTimeout(function (){
this.connectSSE();
}.bind(this),this._sseReconnectDelay);
this._sseReconnectDelay=Math.min (this._sseReconnectDelay*2,30000);
}.bind(this);
this._rebindSSEHandlers();
}catch(e){
console.error('[SSE] 创建 EventSource 失败:',e);
}
};
AppState.disconnectSSE=function (){
if(this._sseSource){
this._sseSource.close();
this._sseSource=null;
}
if(this._sseReconnectTimer){
clearTimeout(this._sseReconnectTimer);
this._sseReconnectTimer=null;
}
};
AppState.onSSEEvent=function (eventType,handler){
if(!this._sseHandlers[eventType]){
this._sseHandlers[eventType]=[];
}
this._sseHandlers[eventType].push(handler);
if(this._sseSource){
this._sseSource.addEventListener(eventType,handler);
}
};
AppState.offSSEEvent=function (eventType,handler){
if(this._sseHandlers[eventType]){
var idx=this._sseHandlers[eventType].indexOf(handler);
if(idx!==-1)this._sseHandlers[eventType].splice(idx,1);
}
if(this._sseSource){
this._sseSource.removeEventListener(eventType,handler);
}
};
AppState._rebindSSEHandlers=function (){
var self=this;
Object.keys(this._sseHandlers).forEach(function (eventType){
self._sseHandlers[eventType].forEach(function (handler){
self._sseSource.addEventListener(eventType,handler);
});
});
};
})();
(function (){
'use strict';
if(typeof AppState==='undefined'){
console.error('[state-ui] AppState not found');
return ;
}
AppState.getEl=function (ref){
if(!ref)return null;
return typeof ref==='string'?document.getElementById(ref):ref;
};
AppState.showElement=function (ref,displayValue){
var el=this.getEl(ref);
if(!el)return null;
el.classList.remove('is-hidden');
if(displayValue){
el.style.display=displayValue;
}else{
el.style.removeProperty('display');
}
return el;
};
AppState.hideElement=function (ref){
var el=this.getEl(ref);
if(!el)return null;
el.classList.add('is-hidden');
el.style.display='none';
return el;
};
AppState.toggleVisible=function (ref,show){
var el=this.getEl(ref);
if(!el)return null;
if(show){
return this.showElement(el);
}else{
return this.hideElement(el);
}
};
AppState.showModal=function (ref){
var el=this.showElement(ref,'flex');
if(el){
var self=this;
el._modalOverlayHandler=function (e){
if(e.target===el){
self.hideModal(ref);
}
};
el.addEventListener('click',el._modalOverlayHandler);
var closeBtn=el.querySelector('.modal-close, .modal-close-btn');
if(closeBtn){
closeBtn._modalCloseHandler=function (){
self.hideModal(ref);
};
closeBtn.addEventListener('click',closeBtn._modalCloseHandler);
}
}
return el;
};
AppState.hideModal=function (ref){
var el=this.getEl(ref);
if(!el)return null;
if(el._modalOverlayHandler){
el.removeEventListener('click',el._modalOverlayHandler);
el._modalOverlayHandler=null;
}
var closeBtn=el.querySelector('.modal-close, .modal-close-btn');
if(closeBtn&&closeBtn._modalCloseHandler){
closeBtn.removeEventListener('click',closeBtn._modalCloseHandler);
closeBtn._modalCloseHandler=null;
}
el.classList.add('is-hidden');
el.style.display='none';
return el;
};
AppState.showInlineError=function (ref,message){
var el=this.getEl(ref);
if(!el)return null;
el.textContent=message||'';
return this.showElement(el,'block');
};
AppState.clearInlineError=function (ref){
var el=this.getEl(ref);
if(!el)return null;
el.textContent='';
return this.hideElement(el);
};
AppState.renderEmptyTableRow=function (tbodyRef,colspan,text,className){
var tbody=this.getEl(tbodyRef);
if(!tbody)return null;
tbody.innerHTML='';
var row=document.createElement('tr');
var cell=document.createElement('td');
cell.colSpan=colspan;
cell.className=className||'u-empty-cell';
cell.textContent=text||'';
row.appendChild(cell);
tbody.appendChild(row);
return row;
};
AppState.renderPagination=function (containerRef,options){
var container=this.getEl(containerRef);
if(!container)return null;
var total=Math.max(0,Number(options&&options.total)||0);
var pageSize=Math.max(1,Number(options&&options.pageSize)||10);
var totalPages=Math.max(1,Math.ceil(total / pageSize));
var currentPage=Math.min (Math.max(1,Number(options&&options.page)||1),totalPages);
var maxVisiblePages=Math.max(3,Number(options&&options.maxVisiblePages)||5);
var summaryText=(options&&options.summaryText)||'';
var onPageChange=(options&&typeof options.onPageChange==='function')?options.onPageChange:null;
container.innerHTML='';
var wrap=document.createElement('div');
wrap.className='pagination u-pagination';
var appendButton=function (label,targetPage,disabled,active){
var button=document.createElement('button');
button.type='button';
button.className='fb-btn fb-btn-sm'+(active?' fb-btn-primary':'');
button.textContent=label;
button.disabled=!!disabled;
if(!button.disabled&&onPageChange){
(function (pg){
button.addEventListener('click',function (){onPageChange(pg);});
})(targetPage);
}
wrap.appendChild(button);
};
var appendEllipsis=function (){
var ellipsis=document.createElement('span');
ellipsis.className='u-pagination-ellipsis';
ellipsis.textContent='...';
wrap.appendChild(ellipsis);
};
var appendSummary=function (){
if(!summaryText)return ;
var summary=document.createElement('span');
summary.className='u-pagination-summary';
summary.textContent=summaryText;
wrap.appendChild(summary);
};
if(totalPages<=1){
appendSummary();
container.appendChild(wrap);
return wrap;
}
appendButton('«',currentPage-1,currentPage<=1,false);
var startPage=Math.max(1,currentPage-Math.floor(maxVisiblePages / 2));
var endPage=Math.min (totalPages,startPage+maxVisiblePages-1);
if(endPage-startPage+1<maxVisiblePages){
startPage=Math.max(1,endPage-maxVisiblePages+1);
}
if(startPage>1){
appendButton('1',1,false,false);
if(startPage>2)appendEllipsis();
}
for(var page=startPage;page<=endPage;page++){
appendButton(String(page),page,page===currentPage,page===currentPage);
}
if(endPage<totalPages){
if(endPage<totalPages-1)appendEllipsis();
appendButton(String(totalPages),totalPages,false,false);
}
appendButton('»',currentPage+1,currentPage>=totalPages,false);
appendSummary();
container.appendChild(wrap);
return wrap;
};
AppState.setLoading=function (ref,text){
var el=this.getEl(ref);
if(!el)return null;
if(!el.hasAttribute('data-original-text')){
el.setAttribute('data-original-text',el.textContent);
}
el.disabled=true;
el.textContent=text||(typeof i18n!=='undefined'?i18n.t('saving'):'保存中...');
el.classList.add('is-loading');
return el;
};
AppState.restoreButton=function (ref,text){
var el=this.getEl(ref);
if(!el)return null;
el.disabled=false;
el.textContent=text||el.getAttribute('data-original-text')||'';
el.classList.remove('is-loading');
el.removeAttribute('data-original-text');
return el;
};
AppState.renderBadge=function (type,text){
var span=document.createElement('span');
span.className='badge badge-'+(type||'info');
span.textContent=text||'';
return span;
};
AppState.setExclusiveActive=function (containerRef,selector,activeEl,className){
var container=this.getEl(containerRef);
if(!container)return ;
var activeClass=className||'is-active';
container.querySelectorAll(selector).forEach(function (el){
el.classList.toggle(activeClass,el===activeEl);
});
};
AppState.setupUserDropdown=function (){
var dropdownBtn=document.getElementById('user-dropdown-btn');
var dropdownMenu=document.getElementById('user-dropdown-menu');
if(!dropdownBtn||!dropdownMenu)return ;
dropdownBtn.addEventListener('click',function (e){
e.stopPropagation();
var dropdown=dropdownBtn.closest('.user-dropdown');
dropdown.classList.toggle('open');
});
document.addEventListener('click',function (e){
if(!dropdownBtn.contains(e.target)&&!dropdownMenu.contains(e.target)){
var dropdown=dropdownBtn.closest('.user-dropdown');
if(dropdown)dropdown.classList.remove('open');
}
});
dropdownMenu.querySelectorAll('.dropdown-item').forEach(function (item){
item.addEventListener('click',function (){
var dropdown=dropdownBtn.closest('.user-dropdown');
if(dropdown)dropdown.classList.remove('open');
});
});
};
AppState.toggleSection=function (bodyId){
var body=document.getElementById(bodyId);
var icon=document.getElementById(bodyId+'-icon');
if(!body)return ;
if(body.classList.contains('fb-hidden')){
body.classList.remove('fb-hidden');
body.style.display='';
if(icon)icon.innerHTML='&#9660;';
}else{
body.classList.add('fb-hidden');
body.style.display='';
if(icon)icon.innerHTML='&#9654;';
}
};
AppState.setupSidebarToggle=function (){
var self=this;
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.addEventListener('click',function (){self.toggleSidebar();});
if(localStorage.getItem('sidebarCollapsed')==='true')this.collapseSidebar();
};
AppState.toggleSidebar=function (){
var sidebar=document.getElementById('sidebar');
if(!sidebar)return ;
var isMobile=window.innerWidth<=768;
if(isMobile){
if(sidebar.classList.contains('expanded')){
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}else{
sidebar.classList.add('expanded');
this.sidebarCollapsed=false;
var btn2=document.getElementById('sidebar-toggle');
if(btn2)btn2.textContent='✕';
}
}else{
this.sidebarCollapsed?this.expandSidebar():this.collapseSidebar();
}
};
AppState.collapseSidebar=function (){
var sidebar=document.getElementById('sidebar');
if(sidebar){
sidebar.classList.add('collapsed');
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
localStorage.setItem('sidebarCollapsed','true');
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}
};
AppState.expandSidebar=function (){
var sidebar=document.getElementById('sidebar');
if(sidebar){
sidebar.classList.remove('collapsed');
this.sidebarCollapsed=false;
localStorage.setItem('sidebarCollapsed','false');
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='✕';
}
};
})();
function _loadScript(src,onSuccess,onFail){
var script=document.createElement('script');
script.src=src;
script.onload=onSuccess;
script.onerror=function (){
setTimeout(function (){
var retry=document.createElement('script');
retry.src=src;
retry.onload=onSuccess;
retry.onerror=function (){
console.error('[FastBee] Failed to load '+src+' after retry');
if(onFail)onFail();
};
document.head.appendChild(retry);
},1500);
};
document.head.appendChild(script);
}
function _bootApp(){
if(typeof i18n==='undefined'){
window.i18n={currentLang:'zh-CN',t:function (k){return k;},updatePageText:function (){}};
}
if(typeof Notification!=='undefined'&&Notification.init){
Notification.init();
}
if(typeof i18n!=='undefined'){
i18n.updatePageText();
}
var savedUsername=localStorage.getItem('username');
var savedPassword=localStorage.getItem('password');
var remember=localStorage.getItem('remember')==='true';
if(savedUsername&&savedPassword&&remember){
document.getElementById('username').value=savedUsername;
document.getElementById('password').value=savedPassword;
document.getElementById('remember').checked=true;
}
var langSelect=document.getElementById('language-select');
if(langSelect&&typeof i18n!=='undefined'){
langSelect.value=i18n.currentLang;
}
AppState.init();
window.app=AppState;
if(typeof i18n!=='undefined'&&i18n.currentLang==='en'){
_loadScript('./js/modules/i18n-en.js',function (){
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText();
}
});
}
}
document.addEventListener('DOMContentLoaded',function (){
if(typeof AppState!=='undefined'){
_bootApp();
}
});