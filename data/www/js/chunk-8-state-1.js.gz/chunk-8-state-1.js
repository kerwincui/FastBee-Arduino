var AppState=typeof AppState!=='undefined'?AppState:{
currentPage:'dashboard',
configTab:'modbus',
currentUser:{name:'',role:'',canManageFs:false},
sidebarCollapsed:false,
_logAutoRefreshTimer:null,
_pageMapping:{
'dashboard-page':'dashboard',
'protocol-page':'protocol',
'network-page':'network',
'device-page':'device',
'data-page':'admin',
'users-page':'admin',
'roles-page':'admin',
'logs-page':'admin',
'peripheral-page':'peripheral',
'periph-exec-page':'peripheral',
'device-control-page':'peripheral',
'rule-script-page':'rule-script'
},
loadPage(pageId){
return PageLoader.loadPage(pageId,this._pageMapping);
},
_loadModals(){
return PageLoader.loadModals();
},
registerModule(name,methods){
ModuleLoader.registerModule(name,methods,this);
},
_loadModule(name,callback){
ModuleLoader.loadModule(name,callback);
},
_handleUrlParams(){
var params=new URLSearchParams(window.location.search);
var targetPage=params.get('page');
var goFullscreen=params.get('fullscreen')==='1';
if(targetPage){
this._pendingUrlPage=targetPage;
this._pendingUrlFullscreen=goFullscreen;
var cleanUrl=window.location.pathname;
window.history.replaceState({},'',cleanUrl);
}
},
_applyUrlParams(){
if(!this._pendingUrlPage)return ;
var page=this._pendingUrlPage;
var goFullscreen=this._pendingUrlFullscreen;
delete this._pendingUrlPage;
delete this._pendingUrlFullscreen;
this.changePage(page);
if(goFullscreen&&page==='device-control'){
setTimeout(function (){
if(typeof AppState._dcToggleFullscreen==='function'){
AppState._dcToggleFullscreen();
}
},1500);
}
},
init(){
this.setupTheme();
this.setupUserDropdown();
this.setupSidebarToggle();
this.setupLanguage();
this.setupConfigTabs();
this.setupEventListeners();
this.setupGlobalEventDelegation();
this._handleUrlParams();
this.refreshPage();
},
setupGlobalEventDelegation(){
const self=this;
document.addEventListener('click',(e)=>{
var tab=e.target.closest('.config-tab');
if(tab){
if(tab.classList.contains('tab-disabled'))return ;
var pageEl=tab.closest('[id$="-page"]');
if(pageEl){
var tabId=tab.getAttribute('data-tab');
self.showConfigTab(pageEl.id,tabId);
}
return ;
}
const el=e.target.closest('[data-action]');
if(!el)return ;
const action=el.dataset.action;
const args=el.dataset.args?el.dataset.args.split(','):[];
if(typeof this[action]==='function'){
e.preventDefault();
this[action](...args);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
e.preventDefault();
window.app[action](...args);
}else{
e.preventDefault();
setTimeout(function (){
if(typeof self[action]==='function'){
self[action](...args);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
window.app[action](...args);
}
},800);
}
});
document.addEventListener('change',(e)=>{
const el=e.target.closest('[data-change-action]');
if(!el)return ;
const action=el.dataset.changeAction;
const value=el.value;
if(typeof this[action]==='function'){
this[action](value);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
window.app[action](value);
}
});
document.addEventListener('submit',(e)=>{
const form=e.target.closest('form');
if(!form)return ;
const protocolForms=['mqtt-form','modbus-rtu-form','modbus-tcp-form','http-form','coap-form','tcp-form'];
if(protocolForms.includes(form.id)){
e.preventDefault();
if(typeof self.saveProtocolConfig==='function'){
self.saveProtocolConfig(form.id);
}
}
});
['input','change'].forEach(function (eventType){
document.addEventListener(eventType,function (e){
const targetId=e.target.id;
if(targetId==='mqtt-client-id'||targetId==='mqtt-auth-type'){
var resultEl=document.getElementById('mqtt-test-result');
if(resultEl)resultEl.textContent='';
}
});
});
},
triggerOtaFileSelect(){
const fileInput=document.getElementById('ota-file');
if(fileInput)fileInput.click();
},
setupLanguage(){
i18n.updatePageText();
const loginLangSelect=document.getElementById('login-language-select');
if(loginLangSelect){
loginLangSelect.value=i18n.currentLang;
loginLangSelect.addEventListener('change',e=>{
i18n.setLanguage(e.target.value);
const mainSelect=document.getElementById('language-select');
if(mainSelect)mainSelect.value=e.target.value;
});
}
const langSelect=document.getElementById('language-select');
if(langSelect){
langSelect.value=i18n.currentLang;
langSelect.addEventListener('change',e=>{
i18n.setLanguage(e.target.value);
if(loginLangSelect)loginLangSelect.value=e.target.value;
this._refreshCurrentPageLocalizedContent();
});
}
},
_getPageModuleMap(){
return {
dashboard:'dashboard',
network:'network',
device:'device-config',
users:'users',
roles:'roles',
peripheral:'peripherals',
'periph-exec':'periph-exec',
protocol:'protocol',
'rule-script':'rule-script',
data:'files',
logs:'logs',
'device-control':'device-control'
};
},
_getPageLoaders(){
return {
dashboard:()=>{this.renderDashboard();this.loadSystemMonitor();},
network:()=>{this.loadNetworkConfig();},
device:()=>{this.loadDeviceConfig();},
users:()=>{this.loadUsers();},
roles:()=>{this.loadRoles();},
peripheral:()=>{this.loadPeripherals();},
'periph-exec':()=>{this.loadPeriphExecPage();},
protocol:()=>{this.loadProtocolConfig('mqtt');if(this._startMqttStatusPolling)this._startMqttStatusPolling();},
'rule-script':()=>{this.loadRuleScriptPage();},
data:()=>{if(typeof this.setupFilesEvents==='function'){this.setupFilesEvents();}this.loadFileTree(this._currentDir||'/');this.loadFileSystemInfo();},
logs:()=>{
if(!this._currentLogFile){
this._currentLogFile='system.log';
}
const currentSpan=document.getElementById('current-log-file');
if(currentSpan)currentSpan.textContent=i18n.t('log-current-file-prefix')+this._currentLogFile;
var self=this;
setTimeout(function (){
self.loadLogFileList();
self.loadLogs();
var autoRefresh=document.getElementById('log-auto-refresh');
if(autoRefresh&&autoRefresh.checked){
self.startLogAutoRefresh();
}
},500);
},
'device-control':()=>{
if(typeof this.loadDeviceControlPage==='function'){
this.loadDeviceControlPage();
}else{
console.warn('[changePage] loadDeviceControlPage not available, module may not be loaded');
var content=document.getElementById('dc-content');
if(content){
content.innerHTML='';
var loadDiv=document.createElement('div');
loadDiv.className='dc-empty';
loadDiv.textContent=i18n.t('loading');
content.appendChild(loadDiv);
var self=this;
setTimeout(function (){
if(typeof self.loadDeviceControlPage==='function'){
self.loadDeviceControlPage();
}else{
content.innerHTML='';
var errDiv=document.createElement('div');
errDiv.className='dc-empty u-text-danger';
errDiv.textContent=i18n.t('module-load-fail')||'模块加载失败，请刷新页面重试';
content.appendChild(errDiv);
}
},1000);
}else{
console.error('[changePage] dc-content element not found!');
}
}
}
};
},
_refreshCurrentPageLocalizedContent(){
const loader=this._getPageLoaders()[this.currentPage];
if(typeof loader==='function'){
loader();
}
},
setupConfigTabs(){
},
_getProtocolName(formId){
const map={'modbus-rtu':'Modbus RTU','modbus-tcp':'Modbus TCP',mqtt:'MQTT',http:'HTTP',coap:'CoAP'};
for(const key of Object.keys(map)){
if(formId.includes(key))return map[key];
}
return 'TCP';
},
showConfigTab(pageId,tabId){
const page=document.getElementById(pageId);
if(!page)return ;
page.querySelectorAll('.config-tab').forEach(t=>{
t.classList.toggle('active',t.getAttribute('data-tab')===tabId);
});
page.querySelectorAll('.config-content').forEach(c=>c.classList.remove('active'));
const target=page.querySelector(`#${tabId}`);
if(target)target.classList.add('active');
if(pageId==='protocol-page'){
if(typeof this.loadProtocolConfig==='function')this.loadProtocolConfig(tabId);
}
if(pageId==='dashboard-page'){
if(typeof this.loadNetworkStatus==='function')this.loadNetworkStatus();
}
if(pageId==='device-page'&&tabId==='dev-ntp'){
if(typeof this.loadDeviceTime==='function')this.loadDeviceTime();
}
if(pageId==='device-page'&&tabId==='dev-basic'){
if(typeof this._loadDeviceHardwareInfo==='function')this._loadDeviceHardwareInfo();
}
if(pageId==='device-page'&&tabId==='dev-ota'){
var selfOta=this;
PageLoader.loadFragment('dev-ota-fragment-container','device-ota',function (){
if(typeof selfOta.loadOtaStatus==='function')selfOta.loadOtaStatus();
});
}
},
setupEventListeners(){
const loginForm=document.getElementById('login-form');
if(loginForm)loginForm.addEventListener('submit',e=>{e.preventDefault();this.handleLogin ();});
document.querySelectorAll('.menu-item').forEach(item=>{
item.addEventListener('click',e=>{e.preventDefault();this.changePage(item.dataset.page);});
});
const changePwdBtn=document.getElementById('change-password-btn');
if(changePwdBtn)changePwdBtn.addEventListener('click',()=>this.showChangePasswordModal());
const logoutBtn=document.getElementById('logout-btn');
if(logoutBtn)logoutBtn.addEventListener('click',()=>this.logout());
const closeId=(id)=>{this.hideModal(id);};
['close-password-modal','cancel-password-btn'].forEach(id=>{
const el=document.getElementById(id);
if(el)el.addEventListener('click',()=>closeId('change-password-modal'));
});
const confirmPwd=document.getElementById('confirm-password-btn');
if(confirmPwd)confirmPwd.addEventListener('click',()=>this.changePassword());
document.querySelectorAll('.menu-item').forEach(item=>{
item.addEventListener('click',()=>{
const sidebar=document.getElementById('sidebar');
if(sidebar&&window.innerWidth<=768&&sidebar.classList.contains('expanded')){
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
const btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}
});
});
},
async changePage(page){
if(typeof window.apiAbortPageRequests==='function'){
window.apiAbortPageRequests();
}
const pageAlias={monitor:'dashboard'};
const normalizedPage=pageAlias[page]||page;
await this.loadPage(normalizedPage+'-page');
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText();
}
document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
const target=document.getElementById(normalizedPage+'-page');
if(!target){
console.warn('[changePage] target page not found:',page,'=>',normalizedPage);
return ;
}
target.classList.add('active');
document.querySelectorAll('.menu-item').forEach(item=>{
item.classList.toggle('active',item.dataset.page===normalizedPage);
});
const titleKey=`page-title-${normalizedPage}`;
const titleEl=document.getElementById('page-title');
if(titleEl)titleEl.textContent=i18n.t(titleKey);
this.currentPage=normalizedPage;
const pageModuleMap=this._getPageModuleMap();
const pageLoaders=this._getPageLoaders();
if(normalizedPage!=='logs'&&this._logAutoRefreshTimer){
clearInterval(this._logAutoRefreshTimer);
this._logAutoRefreshTimer=null;
}
if(normalizedPage!=='device-control'&&typeof this._dcStopAllAutoRefresh==='function'){
this._dcStopAllAutoRefresh();
}
if(normalizedPage!=='protocol'){
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
if(typeof this._stopMasterStatusRefresh==='function'){
this._stopMasterStatusRefresh();
}
if(this._coilAutoRefreshTimer){
clearInterval(this._coilAutoRefreshTimer);
this._coilAutoRefreshTimer=null;
}
if(typeof this._stopPidAutoRefresh==='function'){
this._stopPidAutoRefresh();
}
}
const moduleName=pageModuleMap[normalizedPage];
const loader=pageLoaders[normalizedPage];
if(moduleName&&loader){
this._loadModule(moduleName,loader);
}else if(loader){
loader();
}else{
console.warn('[changePage] no page loader mapped for:',normalizedPage);
}
},
closeAllOverlays(){
document.querySelectorAll('.modal').forEach(function (m){
if(m._modalOverlayHandler){
m.removeEventListener('click',m._modalOverlayHandler);
m._modalOverlayHandler=null;
}
const closeBtn=m.querySelector('.modal-close, .modal-close-btn');
if(closeBtn&&closeBtn._modalCloseHandler){
closeBtn.removeEventListener('click',closeBtn._modalCloseHandler);
closeBtn._modalCloseHandler=null;
}
m.style.display='none';
});
document.querySelectorAll('div[style*="position: fixed"][style*="z-index"]').forEach(function (el){
if(el.querySelector('.modal-content, [onclick*="remove"]')){
el.remove();
}
});
document.querySelectorAll('.user-dropdown.open').forEach(function (d){
d.classList.remove('open');
});
if(typeof this.stopLogAutoRefresh==='function')this.stopLogAutoRefresh();
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
},
getAuthHeader(){
const token=localStorage.getItem('auth_token');
return token?{'Authorization':`Bearer ${token}`}:{};
},
_setText(id,text){
const el=document.getElementById(id);
if(el)el.textContent=text;
},
_setHtml(id,html){
const el=document.getElementById(id);
if(el)el.innerHTML=html;
},
_setBar(id,percent){
const el=document.getElementById(id);
if(el)el.style.width=Math.min (percent,100)+'%';
},
_formatBytes(bytes){
return window.formatBytes(bytes);
},
_setValue(id,value){
const el=document.getElementById(id);
if(el)el.value=value;
},
_setCheckbox(id,checked){
const el=document.getElementById(id);
if(el)el.checked=!!checked;
},
_setChecked(id,checked){
this._setCheckbox(id,checked);
},
_showMessage(id,show){
const el=document.getElementById(id);
if(!el)return ;
el.classList.toggle('is-hidden',!show);
el.style.display=show?'':'none';
},
_setTextContent(id,text){
this._setText(id,text);
}
};
(function (){
'use strict';
AppState.setupTheme=function (){
const savedTheme=localStorage.getItem('theme');
const systemPrefersDark=window.matchMedia('(prefers-color-scheme: dark)').matches;
let theme;
if(savedTheme){
theme=savedTheme;
}else{
theme=systemPrefersDark?'dark':'light';
localStorage.setItem('theme-auto','true');
}
this.setTheme(theme,false);
this.updateThemeToggleIcon(theme);
const themeToggleItem=document.getElementById('theme-toggle-item');
if(themeToggleItem){
themeToggleItem.addEventListener('click',()=>this.toggleTheme());
}
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',(e)=>{
const isAutoMode=localStorage.getItem('theme-auto')==='true';
if(isAutoMode){
const newTheme=e.matches?'dark':'light';
this.setTheme(newTheme,false);
this.updateThemeToggleIcon(newTheme);
}
});
};
AppState.setTheme=function (theme,isManual){
if(typeof isManual==='undefined')isManual=true;
document.documentElement.setAttribute('data-theme',theme);
localStorage.setItem('theme',theme);
if(isManual){
localStorage.removeItem('theme-auto');
}
this.updateThemeToggleIcon(theme);
};
AppState.toggleTheme=function (){
const current=document.documentElement.getAttribute('data-theme');
const newTheme=current==='dark'?'light':'dark';
this.setTheme(newTheme,true);
};
AppState.updateThemeToggleIcon=function (theme){
const themeToggleItem=document.getElementById('theme-toggle-item');
if(themeToggleItem){
const iconSpan=themeToggleItem.querySelector('.item-icon');
const textSpan=themeToggleItem.querySelector('span:not(.item-icon)');
if(iconSpan){
iconSpan.textContent=theme==='dark'?'☀':'🌙';
}
if(textSpan){
const key=theme==='dark'?'theme-light':'theme-dark';
const translated=window.i18n?window.i18n.t(key):(theme==='dark'?'浅色模式':'深色模式');
textSpan.textContent=translated;
}
}
};
})();
(function (){
'use strict';
AppState.refreshPage=function (){
const token=localStorage.getItem('auth_token');
const savedRemember=localStorage.getItem('remember');
const savedUsername=localStorage.getItem('username');
const savedPassword=localStorage.getItem('password');
if(!token){
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
return ;
}
apiGet('/api/auth/session')
.then(res=>{
if(res&&res.success&&res.data&&res.data.sessionValid){
this.currentUser.name=res.data.username||'Admin';
this.currentUser.role=res.data.role||'VIEWER';
this.currentUser.canManageFs=res.data.canManageFs===true;
this._showAppPage();
this._loadModule('dashboard',()=>{
this.renderDashboard();
this.loadSystemMonitor();
});
}else{
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
}
})
.catch(()=>{
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
});
};
AppState._tryAutoLogin =function (remember,username,password){
if(remember==='true'&&username&&password){
apiPost('/api/auth/login',{username,password})
.then(res=>{
if(res&&res.success){
const sid=res.sessionId;
localStorage.setItem('auth_token',sid);
localStorage.setItem('sessionId',sid);
localStorage.setItem('remember','true');
localStorage.setItem('username',username);
localStorage.setItem('password',password);
this.currentUser.name=res.username||username;
sessionStorage.setItem('currentUsername',this.currentUser.name);
apiGet('/api/auth/session').then(sr=>{
if(sr&&sr.success&&sr.data){
this.currentUser.role=sr.data.role||'VIEWER';
this.currentUser.canManageFs=sr.data.canManageFs===true;
}
}).catch(()=>{});
this._showAppPage();
this._loadModule('dashboard',()=>{
this.renderDashboard();
this.loadSystemMonitor();
});
}else{
localStorage.removeItem('password');
localStorage.removeItem('remember');
this._showLoginPage();
}
})
.catch(()=>{
this._showLoginPage();
});
}else{
this._showLoginPage();
}
};
AppState._showLoginPage=function (){
document.getElementById('login-page').style.display='flex';
document.getElementById('app-container').classList.add('fb-hidden');
const savedUsername=localStorage.getItem('username');
const savedRemember=localStorage.getItem('remember');
const usernameInput=document.getElementById('username');
const rememberCheckbox=document.getElementById('remember');
if(usernameInput&&savedUsername)usernameInput.value=savedUsername;
if(rememberCheckbox&&savedRemember==='true')rememberCheckbox.checked=true;
};
AppState._showAppPage=async function (){
document.getElementById('login-page').style.display='none';
document.getElementById('app-container').classList.remove('fb-hidden');
if(location.pathname!=='/'||location.hash){
history.replaceState(null,'','/');
}
await Promise.all([
this._loadModals(),
this.loadPage('dashboard-page')
]);
var skeleton=document.getElementById('skeleton-screen');
if(skeleton)skeleton.remove();
if(typeof this._applyUrlParams==='function')this._applyUrlParams();
};
AppState.handleLogin =function (){
const username=(document.getElementById('username')||{}).value;
const password=(document.getElementById('password')||{}).value;
const remember=(document.getElementById('remember')||{}).checked;
if(!username||!password){
Notification.warning(i18n.t('login-empty-warning'),i18n.t('login-fail-title'));
return ;
}
const submitBtn=document.querySelector('#login-form button[type="submit"]');
const originalText=submitBtn?submitBtn.innerHTML:'';
if(submitBtn){submitBtn.innerHTML=i18n.t('login-logging-in-html');submitBtn.disabled=true;}
apiPost('/api/auth/login',{username,password})
.then(res=>{
if(res&&res.success){
const sid=res.sessionId;
localStorage.setItem('auth_token',sid);
if(remember){
localStorage.setItem('remember','true');
localStorage.setItem('username',username);
localStorage.setItem('password',password);
localStorage.setItem('sessionId',sid);
}else{
['remember','username','password','sessionId'].forEach(k=>localStorage.removeItem(k));
}
this.currentUser.name=res.username||username;
sessionStorage.setItem('currentUsername',this.currentUser.name);
apiGet('/api/auth/session').then(sr=>{
if(sr&&sr.success&&sr.data){
this.currentUser.role=sr.data.role||'VIEWER';
this.currentUser.canManageFs=sr.data.canManageFs===true;
}
}).catch(()=>{});
this._showAppPage();
this._loadModule('dashboard',()=>{
this.renderDashboard();
this.loadSystemMonitor();
});
Notification.success(i18n.t('login-success-msg'),i18n.t('login-welcome-title'));
}else{
Notification.error((res&&res.error)||i18n.t('login-fail-title'),i18n.t('login-fail-title'));
}
})
.catch((err)=>{
const errorMsg=(err&&err.data&&err.data.error)||i18n.t('login-fail-msg');
Notification.error(errorMsg,i18n.t('login-fail-title'));
})
.finally(()=>{
if(submitBtn){submitBtn.innerHTML=originalText;submitBtn.disabled=false;}
});
};
AppState.showChangePasswordModal=function (){
this.showModal('change-password-modal');
['current-password-input','new-password-input','confirm-password-input'].forEach(id=>{
const el=document.getElementById(id);if(el)el.value='';
});
this.clearInlineError('password-error');
};
AppState.changePassword=function (){
const oldPwd=(document.getElementById('current-password-input')||{}).value||'';
const newPwd=(document.getElementById('new-password-input')||{}).value||'';
const confirmPwd=(document.getElementById('confirm-password-input')||{}).value||'';
const showErr=(msg)=>{
this.showInlineError('password-error',msg);
Notification.error(msg,i18n.t('change-pwd-fail'));
};
if(!oldPwd||!newPwd||!confirmPwd)return showErr(i18n.t('validate-all-fields'));
if(newPwd!==confirmPwd)return showErr(i18n.t('password-error')||i18n.t('validate-new-pwd-mismatch'));
if(newPwd.length<6)return showErr(i18n.t('validate-new-pwd-len'));
this.clearInlineError('password-error');
const btn=document.getElementById('confirm-password-btn');
if(btn){btn.disabled=true;btn.textContent=i18n.t('change-pwd-submitting');}
apiPost('/api/auth/change-password',{oldPassword:oldPwd,newPassword:newPwd})
.then(res=>{
if(res&&res.success){
Notification.success(i18n.t('change-pwd-success-msg'),i18n.t('change-pwd-success-title'));
this.hideModal('change-password-modal');
setTimeout(()=>{
localStorage.removeItem('auth_token');
this._showLoginPage();
},1500);
}else{
showErr((res&&res.error)||i18n.t('change-pwd-fail-msg'));
}
})
.catch(()=>{})
.finally(()=>{if(btn){btn.disabled=false;btn.textContent=i18n.t('confirm-change-btn');}});
};
AppState.logout=function (){
if(!confirm(i18n.t('logout-confirm')||'确定要退出登录吗？'))return ;
this._showLoginPage();
document.getElementById('login-form')&&document.getElementById('login-form').reset();
apiPost('/api/auth/logout',{})
.then(()=>{})
.catch(()=>{})
.finally(()=>{
localStorage.removeItem('auth_token');
localStorage.removeItem('sessionId');
localStorage.removeItem('password');
sessionStorage.removeItem('savedPassword');
sessionStorage.removeItem('currentUsername');
Notification.success(i18n.t('logout-success'),i18n.t('logout-title'));
});
};
})();