var AppState=typeof AppState!=='undefined'?AppState:{
currentPage:'dashboard',
configTab:'modbus',
currentUser:{name:''},
developerModeEnabled:true,
sidebarCollapsed:false,
_pageNavSeq:0,
_pageMapping:{
'dashboard-page':'dashboard',
'protocol-page':'protocol',
'network-page':'network',
'device-page':'device',
'peripheral-page':'peripheral',
'periph-exec-page':'peripheral',
'device-control-page':'peripheral',
'logs-page':'logs',
'data-page':'admin',
'users-page':'admin',
'rule-script-page':'rule-script'
},
loadPage(pageId){
return PageLoader.loadPage(pageId,this._pageMapping);
},
_loadModals(){
var self=this;
return PageLoader.loadModals().then(function (){
var closeId=function (id){self.hideModal(id);};
['close-password-modal','cancel-password-btn'].forEach(function (id){
var el=document.getElementById(id);
if(el&&!el._modalBound){
el._modalBound=true;
el.addEventListener('click',function (){closeId('change-password-modal');});
}
});
var confirmPwd=document.getElementById('confirm-password-btn');
if(confirmPwd&&!confirmPwd._modalBound){
confirmPwd._modalBound=true;
confirmPwd.addEventListener('click',function (){self.changePassword();});
}
});
},
registerModule(name,methods){
ModuleLoader.registerModule(name,methods,this);
},
_loadModule(name,callback){
ModuleLoader.loadModule(name,callback);
},
isDeveloperModeEnabled(){
return this.developerModeEnabled!==false;
},
setDeveloperModeState(enabled){
this.developerModeEnabled=enabled!==false;
document.documentElement.classList.toggle('developer-mode-disabled',!this.developerModeEnabled);
this.applyDeveloperModeState();
},
_refreshDeveloperModeState(options){
options=options||{};
var getter;
if(options.silent&&options.noCache&&typeof apiGetSilentFresh==='function'){
getter=apiGetSilentFresh;
}else if(options.noCache&&typeof apiGetFresh==='function'){
getter=apiGetFresh;
}else if(options.silent&&typeof apiGetSilent==='function'){
getter=apiGetSilent;
}else{
getter=apiGet;
}
return getter('/api/device/config')
.then((res)=>{
if(res&&res.success&&res.data){
this.setDeveloperModeState(res.data.developerModeEnabled!==false);
}
return this.developerModeEnabled;
})
.catch((err)=>{
if(!options.silent)console.warn('[developer-mode] load failed:',err);
return this.developerModeEnabled;
});
},
getDeveloperModeDisabledText(){
return '开发环境已禁用，请到设备配置的高级配置中启用后再修改。';
},
guardDeveloperModeAction(){
if(this.isDeveloperModeEnabled())return true;
if(typeof Notification!=='undefined'){
Notification.warning(this.getDeveloperModeDisabledText(),'开发环境');
}
return false;
},
applyDeveloperModeState(root){
var scope=root&&root.querySelectorAll?root:document;
var disabled=!this.isDeveloperModeEnabled();
var tip=this.getDeveloperModeDisabledText();
[
'#add-peripheral-btn',
'#periph-exec-page-add-btn',
'[data-pe-action="edit"]',
'[data-pe-action="toggle"]',
'[data-pe-action="delete"]',
'[data-peripheral-action="edit"]',
'[data-peripheral-action="toggle"]',
'[data-peripheral-action="delete"]',
'[data-action="_showAddDeviceMenu"]',
'#modbus-rtu-form button[type="submit"]',
'[data-action="_saveEditModal"]',
'[data-action="_saveTaskEditModal"]',
'[data-action="saveMappingModal"]',
'[data-action="addMapping"]',
'.protocol-mapping-remove',
'.protocol-action-btn[data-protocol-action="edit-device"]',
'.protocol-action-btn[data-protocol-action="open-mapping"]',
'.protocol-action-btn[data-protocol-action="delete-device"]',
'.protocol-action-btn[data-protocol-action="open-edit-modal"]',
'.protocol-action-btn[data-protocol-action="remove-device"]'
].forEach(function (selector){
scope.querySelectorAll(selector).forEach(function (el){
var resourceLocked=el.getAttribute('data-resource-locked')==='true';
el.disabled=disabled||resourceLocked;
el.classList.toggle('dev-mode-locked',disabled);
if(disabled)el.title=tip;
else if(!resourceLocked)el.removeAttribute('title');
});
});
},
_handleUrlParams(){
var params=new URLSearchParams(window.location.search);
var targetPage=params.get('page');
var goFullscreen=params.get('fullscreen')==='1';
if(targetPage){
this._pendingUrlPage=targetPage;
this._pendingUrlFullscreen=goFullscreen;
var cleanUrl=window.location.pathname;
window.history.replaceState({},'',cleanUrl);
}
},
_applyUrlParams(){
if(!this._pendingUrlPage)return ;
var page=this._pendingUrlPage;
var goFullscreen=this._pendingUrlFullscreen;
delete this._pendingUrlPage;
delete this._pendingUrlFullscreen;
this.changePage(page);
if(goFullscreen&&page==='device-control'){
setTimeout(function (){
if(typeof AppState._dcToggleFullscreen==='function'){
AppState._dcToggleFullscreen();
}
},1500);
}
},
init(){
this.setupTheme();
this.setupUserDropdown();
this.setupSidebarToggle();
this.setupLanguage();
this.setupConfigTabs();
this.setupEventListeners();
this.setupGlobalEventDelegation();
this._handleUrlParams();
this.refreshPage();
},
setupGlobalEventDelegation(){
const self=this;
document.addEventListener('click',(e)=>{
var tab=e.target.closest('.config-tab');
if(tab){
if(tab.classList.contains('tab-disabled'))return ;
var pageEl=tab.closest('[id$="-page"]');
if(pageEl){
var tabId=tab.getAttribute('data-tab');
self.showConfigTab(pageEl.id,tabId);
}
return ;
}
const el=e.target.closest('[data-action]');
if(!el)return ;
const action=el.dataset.action;
const args=el.dataset.args?el.dataset.args.split(','):[];
if(typeof this[action]==='function'){
e.preventDefault();
this[action](...args);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
e.preventDefault();
window.app[action](...args);
}else{
e.preventDefault();
setTimeout(function (){
if(typeof self[action]==='function'){
self[action](...args);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
window.app[action](...args);
}
},800);
}
});
document.addEventListener('change',(e)=>{
const el=e.target.closest('[data-change-action]');
if(!el)return ;
const action=el.dataset.changeAction;
const value=el.value;
if(typeof this[action]==='function'){
this[action](value);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
window.app[action](value);
}
});
document.addEventListener('submit',(e)=>{
const form=e.target.closest('form');
if(!form)return ;
const protocolForms=['mqtt-form','modbus-rtu-form'];
if(protocolForms.includes(form.id)){
e.preventDefault();
if(typeof self.saveProtocolConfig==='function'){
self.saveProtocolConfig(form.id);
}
}
});
['input','change'].forEach(function (eventType){
document.addEventListener(eventType,function (e){
const targetId=e.target.id;
if(targetId==='mqtt-client-id'||targetId==='mqtt-auth-type'){
var resultEl=document.getElementById('mqtt-test-result');
if(resultEl)resultEl.textContent='';
}
});
});
},
setupLanguage(){
if(!localStorage.getItem('language')){
localStorage.setItem('language','zh-CN');
}
if(typeof i18n!=='undefined'){
i18n.currentLang=localStorage.getItem('language')||'zh-CN';
}
var self=this;
var getter=(typeof apiGetSilentFresh==='function')?apiGetSilentFresh
:(typeof apiGetFresh==='function'?apiGetFresh:(typeof apiGet==='function'?apiGet:null));
if(!getter)return ;
getter('/api/system/capabilities').then(function (res){
if(!res||!res.success||!res.data||!res.data.i18n)return ;
var langSelect=document.getElementById('language-select');
if(!langSelect)return ;
langSelect.classList.remove('fb-hidden');
var savedLang=localStorage.getItem('language')||'zh-CN';
langSelect.value=savedLang;
if(savedLang!=='zh-CN'&&typeof i18n!=='undefined'){
i18n.setLanguage(savedLang);
}
langSelect.addEventListener('change',function (){
var lang=langSelect.value;
if(typeof i18n!=='undefined'){
i18n.setLanguage(lang);
}
});
}).catch(function (){});
},
_getPageModuleMap(){
return {
dashboard:'dashboard',
network:'network',
device:'device-config',
peripheral:'peripherals',
'periph-exec':'periph-exec',
protocol:'protocol',
'device-control':'device-control',
logs:'logs',
data:'files',
users:'users',
'rule-script':'rule-script'
};
},
_getPageLoaders(){
return {
dashboard:()=>{
var self=this;
if(typeof this.bootDashboardPage==='function'){
this.bootDashboardPage();
}else{
this.renderDashboard();
setTimeout(function (){
self.loadSystemMonitor();
},120);
}
},
network:()=>{this.loadNetworkConfig();},
device:()=>{this.loadDeviceConfig({deferHardware:true});},
peripheral:()=>{this.loadPeripherals();},
'periph-exec':()=>{this.loadPeriphExecPage();},
protocol:()=>{this.loadProtocolConfig('mqtt');},
logs:()=>{this.loadLogsPage({noCache:true});},
data:()=>{this.loadFileSystemInfo({noCache:true});this.loadFileTree('/',{noCache:true});},
users:()=>{this.loadUsers({noCache:true});},
'rule-script':()=>{this.loadRuleScriptPage({noCache:true});},
'device-control':()=>{
if(typeof this.loadDeviceControlPage==='function'){
this.loadDeviceControlPage();
}else{
console.warn('[changePage] loadDeviceControlPage not available, module may not be loaded');
var content=document.getElementById('dc-content');
if(content){
content.innerHTML='';
var loadDiv=document.createElement('div');
loadDiv.className='dc-empty';
loadDiv.textContent='加载中...';
content.appendChild(loadDiv);
var self=this;
setTimeout(function (){
if(typeof self.loadDeviceControlPage==='function'){
self.loadDeviceControlPage();
}else{
content.innerHTML='';
var errDiv=document.createElement('div');
errDiv.className='dc-empty u-text-danger';
errDiv.textContent='模块加载失败，请刷新页面重试';
content.appendChild(errDiv);
}
},1000);
}else{
console.error('[changePage] dc-content element not found!');
}
}
}
};
},
setupConfigTabs(){
},
_getProtocolName(formId){
const map={'modbus-rtu':'Modbus RTU',mqtt:'MQTT'};
for(const key of Object.keys(map)){
if(formId.includes(key))return map[key];
}
return 'TCP';
},
showConfigTab(pageId,tabId){
const page=document.getElementById(pageId);
if(!page)return ;
page.querySelectorAll('.config-tab').forEach(t=>{
t.classList.toggle('active',t.getAttribute('data-tab')===tabId);
});
page.querySelectorAll('.config-content').forEach(c=>c.classList.remove('active'));
const target=page.querySelector(`#${tabId}`);
if(target)target.classList.add('active');
if(pageId==='protocol-page'){
if(typeof this.loadProtocolConfig==='function')this.loadProtocolConfig(tabId);
}
if(pageId==='dashboard-page'){
if(typeof this.loadNetworkStatus==='function')this.loadNetworkStatus({noCache:true});
}
if(pageId==='device-page'&&tabId==='dev-ntp'){
if(typeof this.loadDeviceTime==='function')this.loadDeviceTime({noCache:true});
}
if(pageId==='device-page'&&tabId==='dev-basic'){
if(typeof this._loadDeviceHardwareInfo==='function')this._loadDeviceHardwareInfo({noCache:true});
}
},
setupEventListeners(){
const loginForm=document.getElementById('login-form');
if(loginForm)loginForm.addEventListener('submit',e=>{e.preventDefault();this.handleLogin ();});
document.querySelectorAll('.menu-item').forEach(item=>{
item.addEventListener('click',e=>{e.preventDefault();this.changePage(item.dataset.page);});
});
const changePwdBtn=document.getElementById('change-password-btn');
if(changePwdBtn)changePwdBtn.addEventListener('click',()=>this.showChangePasswordModal());
const logoutBtn=document.getElementById('logout-btn');
if(logoutBtn)logoutBtn.addEventListener('click',()=>this.logout());
const closeId=(id)=>{this.hideModal(id);};
['close-password-modal','cancel-password-btn'].forEach(id=>{
const el=document.getElementById(id);
if(el)el.addEventListener('click',()=>closeId('change-password-modal'));
});
const confirmPwd=document.getElementById('confirm-password-btn');
if(confirmPwd)confirmPwd.addEventListener('click',()=>this.changePassword());
document.querySelectorAll('.menu-item').forEach(item=>{
item.addEventListener('click',()=>{
const sidebar=document.getElementById('sidebar');
if(sidebar&&window.innerWidth<=768&&sidebar.classList.contains('expanded')){
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
const btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}
});
});
},
async changePage(page){
const navSeq=(this._pageNavSeq||0)+1;
this._pageNavSeq=navSeq;
if(typeof window.apiAbortPageRequests==='function'){
window.apiAbortPageRequests();
}
const pageAlias={monitor:'dashboard'};
const normalizedPage=pageAlias[page]||page;
await this.loadPage(normalizedPage+'-page');
if(navSeq!==this._pageNavSeq)return ;
document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
const target=document.getElementById(normalizedPage+'-page');
if(!target){
console.warn('[changePage] target page not found:',page,'=>',normalizedPage);
return ;
}
target.classList.add('active');
document.querySelectorAll('.menu-item').forEach(item=>{
item.classList.toggle('active',item.dataset.page===normalizedPage);
});
const titleKey=`page-title-${normalizedPage}`;
const titleEl=document.getElementById('page-title');
var _pageTitleMap={
'page-title-dashboard':'设备监控仪表盘',
'page-title-protocol':'通信协议',
'page-title-network':'网络设置',
'page-title-device':'设备配置',
'page-title-data':'文件管理',
'page-title-system':'系统监控',
'page-title-logs':'设备日志',
'page-title-gpio':'GPIO配置',
'page-title-peripheral':'外设配置',
'page-title-periph-exec':'外设执行',
'page-title-users':'用户管理',
'page-title-device-control':'设备大屏'
};
if(titleEl)titleEl.textContent=_pageTitleMap[titleKey]||normalizedPage;
this.currentPage=normalizedPage;
const pageModuleMap=this._getPageModuleMap();
const pageLoaders=this._getPageLoaders();
if(normalizedPage!=='device-control'&&typeof this._dcStopAllAutoRefresh==='function'){
this._dcStopAllAutoRefresh();
}
if(normalizedPage!=='protocol'){
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
if(typeof this._stopMasterStatusRefresh==='function'){
this._stopMasterStatusRefresh();
}
if(this._coilAutoRefreshTimer){
clearInterval(this._coilAutoRefreshTimer);
this._coilAutoRefreshTimer=null;
}
if(typeof this._stopPidAutoRefresh==='function'){
this._stopPidAutoRefresh();
}
}
const moduleName=pageModuleMap[normalizedPage];
const loader=pageLoaders[normalizedPage];
const runLoader=()=>{
if(navSeq!==this._pageNavSeq||this.currentPage!==normalizedPage)return ;
loader();
};
if(moduleName&&loader){
this._loadModule(moduleName,runLoader);
}else if(loader){
runLoader();
}else{
console.warn('[changePage] no page loader mapped for:',normalizedPage);
}
},
closeAllOverlays(){
document.querySelectorAll('.modal').forEach(function (m){
if(m._modalOverlayHandler){
m.removeEventListener('click',m._modalOverlayHandler);
m._modalOverlayHandler=null;
}
const closeBtn=m.querySelector('.modal-close, .modal-close-btn');
if(closeBtn&&closeBtn._modalCloseHandler){
closeBtn.removeEventListener('click',closeBtn._modalCloseHandler);
closeBtn._modalCloseHandler=null;
}
m.style.display='none';
});
document.querySelectorAll('div[style*="position: fixed"][style*="z-index"]').forEach(function (el){
if(el.querySelector('.modal-content, [onclick*="remove"]')){
el.remove();
}
});
document.querySelectorAll('.user-dropdown.open').forEach(function (d){
d.classList.remove('open');
});
if(typeof this.stopLogAutoRefresh==='function')this.stopLogAutoRefresh();
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
},
getAuthHeader(){
const token=localStorage.getItem('auth_token');
return token?{'Authorization':`Bearer ${token}`}:{};
},
_setText(id,text){
const el=document.getElementById(id);
if(el)el.textContent=text;
},
_setHtml(id,html){
const el=document.getElementById(id);
if(el)el.innerHTML=html;
},
_setBar(id,percent){
const el=document.getElementById(id);
if(el)el.style.width=Math.min (percent,100)+'%';
},
_formatBytes(bytes){
return window.formatBytes(bytes);
},
_setValue(id,value){
const el=document.getElementById(id);
if(el)el.value=value;
},
_setCheckbox(id,checked){
const el=document.getElementById(id);
if(el)el.checked=!!checked;
},
_setChecked(id,checked){
this._setCheckbox(id,checked);
},
_showMessage(id,show){
const el=document.getElementById(id);
if(!el)return ;
el.classList.toggle('is-hidden',!show);
el.style.display=show?'':'none';
},
_setTextContent(id,text){
this._setText(id,text);
}
};
(function (){
'use strict';
AppState.setupTheme=function (){
const savedTheme=localStorage.getItem('theme');
const systemPrefersDark=window.matchMedia('(prefers-color-scheme: dark)').matches;
let theme;
if(savedTheme){
theme=savedTheme;
}else{
theme=systemPrefersDark?'dark':'light';
localStorage.setItem('theme-auto','true');
}
this.setTheme(theme,false);
this.updateThemeToggleIcon(theme);
const themeToggleItem=document.getElementById('theme-toggle-item');
if(themeToggleItem){
themeToggleItem.addEventListener('click',()=>this.toggleTheme());
}
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',(e)=>{
const isAutoMode=localStorage.getItem('theme-auto')==='true';
if(isAutoMode){
const newTheme=e.matches?'dark':'light';
this.setTheme(newTheme,false);
this.updateThemeToggleIcon(newTheme);
}
});
};
AppState.setTheme=function (theme,isManual){
if(typeof isManual==='undefined')isManual=true;
document.documentElement.setAttribute('data-theme',theme);
localStorage.setItem('theme',theme);
if(isManual){
localStorage.removeItem('theme-auto');
}
this.updateThemeToggleIcon(theme);
};
AppState.toggleTheme=function (){
const current=document.documentElement.getAttribute('data-theme');
const newTheme=current==='dark'?'light':'dark';
this.setTheme(newTheme,true);
};
AppState.updateThemeToggleIcon=function (theme){
const themeToggleItem=document.getElementById('theme-toggle-item');
if(themeToggleItem){
const iconSpan=themeToggleItem.querySelector('.item-icon');
const textSpan=themeToggleItem.querySelector('span:not(.item-icon)');
if(iconSpan){
iconSpan.textContent=theme==='dark'?'☀':'🌙';
}
if(textSpan){
const key=theme==='dark'?'theme-light':'theme-dark';
const translated=theme==='dark'?'浅色模式':'深色模式';
textSpan.textContent=translated;
}
}
};
})();
(function (){
'use strict';
AppState.refreshPage=function (){
const token=localStorage.getItem('auth_token');
const savedRemember=localStorage.getItem('remember');
const savedUsername=localStorage.getItem('username');
const savedPassword=localStorage.getItem('password');
if(!token){
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
return ;
}
apiGet('/api/auth/session')
.then(res=>{
if(res&&res.success&&res.data&&res.data.sessionValid){
this.currentUser.name=res.data.username||'Admin';
this._bootDashboardAfterAuth();
}else{
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
}
})
.catch(()=>{
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
});
};
AppState._tryAutoLogin =function (remember,username,password){
if(remember==='true'&&username&&password){
apiPost('/api/auth/login',{username,password})
.then(res=>{
if(res&&res.success){
const sid=res.sessionId;
localStorage.setItem('auth_token',sid);
localStorage.setItem('sessionId',sid);
localStorage.setItem('remember','true');
localStorage.setItem('username',username);
localStorage.setItem('password',password);
this.currentUser.name=res.username||username;
sessionStorage.setItem('currentUsername',this.currentUser.name);
this._bootDashboardAfterAuth();
}else{
localStorage.removeItem('password');
localStorage.removeItem('remember');
this._showLoginPage();
}
})
.catch(()=>{
this._showLoginPage();
});
}else{
this._showLoginPage();
}
};
AppState._showLoginPage=function (){
document.getElementById('login-page').style.display='flex';
document.getElementById('app-container').classList.add('fb-hidden');
var loginLangSelect=document.getElementById('login-language-select');
if(loginLangSelect&&!loginLangSelect._bound){
loginLangSelect._bound=true;
var savedLang=localStorage.getItem('language')||'zh-CN';
loginLangSelect.value=savedLang;
if(savedLang!=='zh-CN'&&typeof i18n!=='undefined'){
i18n.setLanguage(savedLang);
}
loginLangSelect.addEventListener('change',function (){
var lang=loginLangSelect.value;
localStorage.setItem('language',lang);
if(typeof i18n!=='undefined'){
i18n.setLanguage(lang);
}
});
}
const savedUsername=localStorage.getItem('username');
const savedRemember=localStorage.getItem('remember');
const usernameInput=document.getElementById('username');
const rememberCheckbox=document.getElementById('remember');
if(usernameInput&&savedUsername)usernameInput.value=savedUsername;
if(rememberCheckbox&&savedRemember==='true')rememberCheckbox.checked=true;
};
AppState._bootDashboardAfterAuth=async function (){
try{
await this._showAppPage();
}catch(e){
console.error('[Auth] Failed to prepare app shell:',e);
}
this._loadModule('dashboard',()=>{
var self=this;
if(typeof this.bootDashboardPage==='function'){
this.bootDashboardPage();
}else{
this.renderDashboard();
setTimeout(function (){
self.loadSystemMonitor();
},120);
}
setTimeout(function (){
if(typeof ApiPreloader!=='undefined'&&typeof ApiPreloader.preloadPageData==='function'){
ApiPreloader.preloadPageData('device');
}
if(typeof PageLoader!=='undefined'&&typeof PageLoader.preloadPages==='function'){
PageLoader.preloadPages([
'device-page',
'network-page',
'peripheral-page',
'protocol-page'
],self._pageMapping,{delayMs:800}).catch(function (){});
}
},5000);
});
var self=this;
setTimeout(function (){
self._loadModals();
},3000);
};
AppState._showAppPage=async function (){
document.getElementById('login-page').style.display='none';
document.getElementById('app-container').classList.remove('fb-hidden');
if(location.pathname!=='/'||location.hash){
history.replaceState(null,'','/');
}
await this.loadPage('dashboard-page');
if(typeof this._refreshDeveloperModeState==='function'){
this._refreshDeveloperModeState({silent:true,noCache:true});
}
var skeleton=document.getElementById('skeleton-screen');
if(skeleton)skeleton.remove();
setTimeout(function (){
var sidebarLogo=document.getElementById('sidebar-logo');
if(!sidebarLogo||sidebarLogo.getAttribute('src'))return ;
var lazySrc=sidebarLogo.getAttribute('data-lazy-src');
if(lazySrc)sidebarLogo.setAttribute('src',lazySrc);
},2000);
if(typeof this._applyUrlParams==='function')this._applyUrlParams();
};
AppState._loginErrorText=function (message){
var text=String(message||'');
if(!text)return '用户名或密码错误';
var lower=text.toLowerCase();
if(lower.indexOf('invalid username or password')!==-1||
lower.indexOf('invalid credentials')!==-1||
lower.indexOf('login failed')!==-1){
return '用户名或密码错误';
}
if(lower.indexOf('too many')!==-1&&lower.indexOf('attempt')!==-1){
return '登录失败次数过多，账号已锁定';
}
if(lower.indexOf('account')!==-1&&lower.indexOf('locked')!==-1){
return '账号已锁定，请稍后再试';
}
if(lower.indexOf('ip address not allowed')!==-1){
return '当前 IP 不允许登录';
}
return text;
};
AppState.handleLogin =function (){
const username=(document.getElementById('username')||{}).value;
const password=(document.getElementById('password')||{}).value;
const remember=(document.getElementById('remember')||{}).checked;
if(!username||!password){
Notification.warning('请输入用户名和密码','登录失败');
return ;
}
const submitBtn=document.querySelector('#login-form button[type="submit"]');
const originalText=submitBtn?submitBtn.innerHTML:'';
if(submitBtn){submitBtn.innerHTML='… 登录中...';submitBtn.disabled=true;}
apiPost('/api/auth/login',{username,password})
.then(res=>{
if(res&&res.success){
const sid=res.sessionId;
localStorage.setItem('auth_token',sid);
if(remember){
localStorage.setItem('remember','true');
localStorage.setItem('username',username);
localStorage.setItem('password',password);
localStorage.setItem('sessionId',sid);
}else{
['remember','username','password','sessionId'].forEach(k=>localStorage.removeItem(k));
}
this.currentUser.name=res.username||username;
sessionStorage.setItem('currentUsername',this.currentUser.name);
this._bootDashboardAfterAuth();
Notification.success('登录成功','欢迎');
}else{
Notification.error(this._loginErrorText(res&&res.error),'登录失败');
}
})
.catch((err)=>{
const errorMsg=this._loginErrorText(err&&err.data&&err.data.error);
Notification.error(errorMsg,'登录失败');
})
.finally(()=>{
if(submitBtn){submitBtn.innerHTML=originalText;submitBtn.disabled=false;}
});
};
AppState.showChangePasswordModal=function (){
this.showModal('change-password-modal');
['current-password-input','new-password-input','confirm-password-input'].forEach(id=>{
const el=document.getElementById(id);if(el)el.value='';
});
this.clearInlineError('password-error');
};
AppState.changePassword=function (){
const oldPwd=(document.getElementById('current-password-input')||{}).value||'';
const newPwd=(document.getElementById('new-password-input')||{}).value||'';
const confirmPwd=(document.getElementById('confirm-password-input')||{}).value||'';
const showErr=(msg)=>{
this.showInlineError('password-error',msg);
Notification.error(msg,'修改密码失败');
};
if(!oldPwd||!newPwd||!confirmPwd)return showErr('请填写所有字段！');
if(newPwd!==confirmPwd)return showErr('新密码与确认密码不一致！');
if(newPwd.length<6)return showErr('新密码长度至少6位！');
this.clearInlineError('password-error');
const btn=document.getElementById('confirm-password-btn');
if(btn){btn.disabled=true;btn.textContent='提交中...';}
apiPost('/api/auth/change-password',{oldPassword:oldPwd,newPassword:newPwd})
.then(res=>{
if(res&&res.success){
Notification.success('密码修改成功，请重新登录','修改成功');
this.hideModal('change-password-modal');
setTimeout(()=>{
localStorage.removeItem('auth_token');
this._showLoginPage();
},1500);
}else{
showErr((res&&res.error)||'密码修改失败，请检查原密码是否正确');
}
})
.catch(()=>{})
.finally(()=>{if(btn){btn.disabled=false;btn.textContent='确认修改';}});
};
AppState.logout=function (){
if(!confirm('确定要退出登录吗？'))return ;
this._showLoginPage();
document.getElementById('login-form')&&document.getElementById('login-form').reset();
apiPost('/api/auth/logout',{})
.then(()=>{})
.catch(()=>{})
.finally(()=>{
localStorage.removeItem('auth_token');
localStorage.removeItem('sessionId');
localStorage.removeItem('password');
sessionStorage.removeItem('savedPassword');
sessionStorage.removeItem('currentUsername');
Notification.success('已成功退出登录','退出登录');
});
};
})();