(function (){
'use strict';
window.escapeHtml=function (text){
if(text==null)return '';
var map={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};
return String(text).replace(/[&<>"']/g,function (m){return map[m];});
};
window.safeText=function (el,text){
if(el)el.textContent=text!=null?String(text):'';
};
window.safeHtml=function (el,html){
if(el)el.innerHTML=html;
};
window.formatBytes=function (bytes){
if(!bytes||bytes===0)return '0 B';
var k=1024;
var sizes=['B','KB','MB','GB'];
var i=Math.floor(Math.log(bytes)/ Math.log(k));
if(i>=sizes.length)i=sizes.length-1;
return parseFloat((bytes / Math.pow(k,i)).toFixed(2))+' '+sizes[i];
};
window.formatUptime=function (seconds){
if(seconds==null||seconds<0)return '--';
seconds=Math.floor(seconds);
var h=Math.floor(seconds / 3600);
var m=Math.floor((seconds % 3600)/ 60);
var s=seconds % 60;
if(h>0)return h+'h '+m+'m '+s+'s';
if(m>0)return m+'m '+s+'s';
return s+'s';
};
window.debounce=function (fn,delay){
var timer=null;
delay=delay||300;
return function (){
var ctx=this,args=arguments;
if(timer)clearTimeout(timer);
timer=setTimeout(function (){
fn.apply(ctx,args);
},delay);
};
};
window.clamp=function (value,min ,max){
return Math.max(min ,Math.min (max,value));
};
window.deepClone=function (obj){
if(obj==null||typeof obj!=='object')return obj;
return JSON.parse(JSON.stringify(obj));
};
})();
(function (){
'use strict';
var FB=window.FB||{};
FB.ui={
createButton:function (text,options){
options=options||{};
var btn=document.createElement('button');
btn.type=options.type||'button';
btn.className=options.className||'fb-btn fb-btn-primary';
btn.textContent=text;
if(options.onclick)btn.addEventListener('click',options.onclick);
if(options.disabled)btn.disabled=true;
if(options.dataset){
var keys=Object.keys(options.dataset);
for(var i=0;i<keys.length;i++){
btn.dataset[keys[i]]=options.dataset[keys[i]];
}
}
return btn;
},
createTableRow:function (cells,options){
options=options||{};
var tr=document.createElement('tr');
if(options.className)tr.className=options.className;
for(var i=0;i<cells.length;i++){
var cell=cells[i];
var td=document.createElement('td');
if(typeof cell==='string'){
td.textContent=cell;
}else if(cell instanceof Node){
td.appendChild(cell);
}else if(cell&&cell.html){
td.innerHTML=cell.html;
}else if(cell&&cell.className){
td.className=cell.className;
if(cell.text)td.textContent=cell.text;
}
if(options.cellClassNames&&options.cellClassNames[i]){
td.className=options.cellClassNames[i];
}
tr.appendChild(td);
}
return tr;
},
createNotification:function (type,message,duration){
duration=duration||3000;
var div=document.createElement('div');
div.className='notification notification-'+type;
div.textContent=message;
document.body.appendChild(div);
setTimeout(function (){div.remove();},duration);
return div;
},
createFragment:function (){
return document.createDocumentFragment();
},
replaceChildren:function (container,children){
var fragment=document.createDocumentFragment();
for(var i=0;i<children.length;i++){
fragment.appendChild(children[i]);
}
container.innerHTML='';
container.appendChild(fragment);
}
};
window.FB=FB;
})();
(function (){
'use strict';
const BASE_URL=(location.hostname==='localhost'||location.hostname==='127.0.0.1')
?'http://fastbee.local'
:(location.origin ||'http://fastbee.local');
const DEFAULT_TIMEOUT=15000;
const RESTART_TIMEOUT=15000;
function toUrlEncoded(data){
if(!data)return '';
return Object.keys(data).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(data[k]==null?'':data[k])).join ('&');
}
function fetchWithTimeout(url,options,timeoutMs){
const controller=new AbortController();
const timer=setTimeout(()=>controller.abort(),timeoutMs);
return fetch(url,Object.assign({signal:controller.signal},options)).finally(()=>clearTimeout(timer));
}
function buildUrl(path,params){
const url=new URL(path,BASE_URL);
if(params){Object.keys(params).forEach(k=>{if(params[k]!=null)url.searchParams.append(k,params[k]);});}
return url.toString();
}
function request(method,path,options,timeoutMs){
options=options||{};
var silent=options.silent||false;
const token=localStorage.getItem('auth_token');
const headers=Object.assign({},options.headers);
if(token){headers['Authorization']='Bearer '+token;}
const fetchOptions={method:method,headers:headers,credentials:'include',cache:'no-store'};
if(options.body){fetchOptions.body=options.body;}
const url=buildUrl(path,options.params);
const timeout=timeoutMs||DEFAULT_TIMEOUT;
return fetchWithTimeout(url,fetchOptions,timeout)
.then(function (response){
return response.json().catch(function (){return {};}).then(function (data){
if(response.ok)return data;
return Promise.reject({status:response.status,data:data,response:response});
});
})
.catch(function (err){
if(silent)return Promise.reject(err);
if(err&&err._pageAborted)return Promise.reject(err);
if(err&&err.status!==undefined){_handleHttpError(err.status,err.data);}
else if(err&&err.name==='AbortError'){err._handled=false;}
else if(err&&err.message&&err.message.includes('fetch')){err._handled=false;}
else{if(typeof Notification!=='undefined'){Notification.error('无法连接到设备，请检查网络连接','网络错误');}}
return Promise.reject(err);
});
}
function _handleHttpError(status,data){
if(typeof Notification==='undefined')return ;
const errMsg=(data&&data.error)?data.error:'请求失败';
switch(status){
case 400:Notification.warning(errMsg||'请求参数错误','参数错误');break;
case 401:
localStorage.removeItem('auth_token');localStorage.removeItem('sessionId');
if(!document.getElementById('login-page')||document.getElementById('login-page').style.display==='none'){
if(typeof AppState!=='undefined'&&AppState.closeAllOverlays){AppState.closeAllOverlays();}
Notification.warning('登录已过期，请重新登录','会话超时');
setTimeout(function (){
if(localStorage.getItem('auth_token'))return ;
var lp=document.getElementById('login-page');var ac=document.getElementById('app-container');
if(lp&&ac){ac.classList.add('fb-hidden');lp.style.display='flex';}
},1500);
}break;
case 403:Notification.warning('权限不足，无法执行此操作','权限拒绝');break;
case 404:Notification.warning('请求的资源不存在','未找到');break;
case 409:Notification.warning(errMsg||'资源冲突（可能已存在）','冲突');break;
case 429:Notification.warning('操作过于频繁，请稍后再试','请求限流');break;
case 500:Notification.error('服务器内部错误，请检查设备状态','服务器错误');break;
case 503:Notification.error('服务暂时不可用','服务不可用');break;
default:Notification.warning(errMsg,'请求失败('+status+')');
}
}
var Governor={
_queue:[],_inflight:0,MAX_CONCURRENT:2,
_cooldownUntil:0,_backoffMs:1000,_cooldownTimer:null,
_dedupMap:{},_pageGen:0,
_cache:{},
_cacheTTL:{
'/api/protocol/config':60000,'/api/system/info':30000,'/api/device/config':120000,
'/api/network/config':60000,'/api/device/info':60000,'/api/config':60000,
'/api/peripherals/types':120000,'/api/periph-exec/controls':60000,
'/api/periph-exec/events/static':120000,'/api/periph-exec/events/categories':120000,
'/api/periph-exec/trigger-types':120000,'/api/permissions':120000
},
enqueue:function (method,path,options,timeoutMs){
var self=this;
var fullUrl=buildUrl(path,options?options.params:undefined);
var body=options?(options.body||''):'';
var dedupKey=method+':'+fullUrl+(body?'#'+body:'');
var isSilent=!!(options&&options.silent);
if(method!=='GET'){delete this._cache[path];}
if(method==='GET'&&this._cacheTTL[path]){
var cached=this._cache[path];
if(cached&&(Date.now()-cached.ts<this._cacheTTL[path])){
return Promise.resolve(JSON.parse(JSON.stringify(cached.data)));
}
}
if(this._dedupMap[dedupKey]){return this._dedupMap[dedupKey];}
var resolve,reject;
var promise=new Promise(function (res,rej){resolve=res;reject=rej;});
this._queue.push({
method:method,path:path,options:options,timeoutMs:timeoutMs,
resolve:resolve,reject:reject,
priority:isSilent?0:1,dedupKey:dedupKey,pageGen:this._pageGen
});
this._dedupMap[dedupKey]=promise;
promise.then(function (){delete self._dedupMap[dedupKey];},function (){delete self._dedupMap[dedupKey];});
this._drain ();
return promise;
},
_drain :function (){
var self=this;
for(var i=this._queue.length-1;i>=0;i--){
if(this._queue[i].pageGen<this._pageGen){
var expired=this._queue.splice(i,1)[0];
delete this._dedupMap[expired.dedupKey];
var err=new Error('Request cancelled by page navigation');
err._pageAborted=true;
expired.reject(err);
}
}
var now=Date.now();
var hasPriority=false;
for(var k=0;k<this._queue.length;k++){
if(this._queue[k].priority>=2){hasPriority=true;break;}
}
if(!hasPriority&&now<this._cooldownUntil&&this._queue.length>0){
if(!this._cooldownTimer){
var delay=this._cooldownUntil-now;
this._cooldownTimer=setTimeout(function (){self._cooldownTimer=null;self._drain ();},delay);
}
return ;
}
while(this._inflight<this.MAX_CONCURRENT&&this._queue.length>0){
var bestIdx=0;
for(var j=1;j<this._queue.length;j++){
if(this._queue[j].priority>this._queue[bestIdx].priority){bestIdx=j;}
}
var entry=this._queue.splice(bestIdx,1)[0];
this._inflight++;
this._execute(entry);
}
},
_execute:function (entry){
var self=this;
request(entry.method,entry.path,entry.options,entry.timeoutMs)
.then(function (data){
self._backoffMs=1000;
if(entry.method==='GET'&&self._cacheTTL[entry.path]){
self._cache[entry.path]={data:data,ts:Date.now()};
}
entry.resolve(data);
})
.catch(function (err){
var isAuthEndpoint=entry.path.indexOf('/api/auth/')===0;
if(!isAuthEndpoint&&self._isCooldownError(err)){
self._cooldownUntil=Date.now()+self._backoffMs;
console.warn('[Governor] Cooldown '+self._backoffMs+'ms after overload');
self._backoffMs=Math.min (self._backoffMs*2,10000);
}
entry.reject(err);
})
.finally(function (){self._inflight--;self._drain ();});
},
_isCooldownError:function (err){
if(!err)return false;
if(err.status===503||err.status===429)return true;
if(err instanceof TypeError)return true;
return false;
},
abortPageRequests:function (){
this._pageGen++;
for(var i=this._queue.length-1;i>=0;i--){
if(this._queue[i].pageGen<this._pageGen){
var expired=this._queue.splice(i,1)[0];
delete this._dedupMap[expired.dedupKey];
var err=new Error('Request cancelled by page navigation');
err._pageAborted=true;
expired.reject(err);
}
}
},
enqueuePriority:function (method,path,options,timeoutMs){
var self=this;
var body=options?(options.body||''):'';
var fullUrl=buildUrl(path,options?options.params:undefined);
var dedupKey=method+':'+fullUrl+(body?'#'+body:'');
if(method!=='GET'){delete this._cache[path];}
if(this._dedupMap[dedupKey]){return this._dedupMap[dedupKey];}
var resolve,reject;
var promise=new Promise(function (res,rej){resolve=res;reject=rej;});
this._queue.unshift({
method:method,path:path,options:options,timeoutMs:timeoutMs,
resolve:resolve,reject:reject,
priority:2,dedupKey:dedupKey,pageGen:this._pageGen
});
this._dedupMap[dedupKey]=promise;
promise.then(function (){delete self._dedupMap[dedupKey];},function (){delete self._dedupMap[dedupKey];});
this._drain ();
return promise;
},
invalidateCache:function (urlPattern){
if(!urlPattern){this._cache={};return ;}
for(var key in this._cache){
if(this._cache.hasOwnProperty(key)&&key.indexOf(urlPattern)!==-1){delete this._cache[key];}
}
},
_batchQueue:[],
_batchTimer:null,
BATCH_WINDOW_MS:50,
batchGet:function (url,params){
var self=this;
if(this._cacheTTL[url]){
var cached=this._cache[url];
if(cached&&(Date.now()-cached.ts<this._cacheTTL[url])){
return Promise.resolve(JSON.parse(JSON.stringify(cached.data)));
}
}
return new Promise(function (resolve,reject){
self._batchQueue.push({url:url,params:params||{},resolve:resolve,reject:reject});
if(!self._batchTimer){
self._batchTimer=setTimeout(function (){self._flushBatch();},self.BATCH_WINDOW_MS);
}
});
},
_flushBatch:function (){
var queue=this._batchQueue;
this._batchQueue=[];
this._batchTimer=null;
var self=this;
if(queue.length===0)return ;
if(queue.length===1){
self.enqueue('GET',queue[0].url,{params:queue[0].params})
.then(queue[0].resolve).catch(queue[0].reject);
return ;
}
var requests=queue.map(function (q){
var r={url:q.url};
if(q.params&&Object.keys(q.params).length>0)r.params=q.params;
return r;
});
self.enqueue('POST','/api/batch',{
headers:{'Content-Type':'application/json'},
body:JSON.stringify({requests:requests})
}).then(function (resp){
var results=resp.results||resp;
if(!Array.isArray(results)){
queue.forEach(function (q){q.reject(new Error('Invalid batch response'));});
return ;
}
results.forEach(function (item,i){
if(i>=queue.length)return ;
if(item.success===false||item.error){
queue[i].reject(item.error||'Batch sub-request failed');
}else{
var url=queue[i].url;
if(self._cacheTTL[url]){
self._cache[url]={data:item.data||item,ts:Date.now()};
}
queue[i].resolve(item);
}
});
}).catch(function (err){
queue.forEach(function (q){q.reject(err);});
});
}
};
window.apiGet=function (url,params){return Governor.enqueue('GET',url,{params:params||{}});};
window.apiGetSilent=function (url,params){return Governor.enqueue('GET',url,{params:params||{},silent:true});};
window.apiPost=function (url,data,timeoutMs){return Governor.enqueue('POST',url,{headers:{'Content-Type':'application/x-www-form-urlencoded'},body:toUrlEncoded(data||{})},timeoutMs);};
window.apiPostSilent=function (url,data){return Governor.enqueue('POST',url,{headers:{'Content-Type':'application/x-www-form-urlencoded'},body:toUrlEncoded(data||{}),silent:true});};
window.apiPut=function (url,data){return Governor.enqueue('PUT',url,{headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})});};
window.apiPutForm=function (url,data){return Governor.enqueue('PUT',url,{headers:{'Content-Type':'application/x-www-form-urlencoded'},body:toUrlEncoded(data||{})});};
window.apiPostJson=function (url,data){return Governor.enqueue('POST',url,{headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})});};
window.apiDelete=function (url,params){return Governor.enqueue('DELETE',url,{params:params||{}});};
window.apiPostPriority=function (url,data,timeoutMs){return Governor.enqueuePriority('POST',url,{headers:{'Content-Type':'application/x-www-form-urlencoded'},body:toUrlEncoded(data||{})},timeoutMs);};
window.apiRestart=function (data){return request('POST','/api/system/restart',{headers:{'Content-Type':'application/x-www-form-urlencoded'},body:toUrlEncoded(data||{})},RESTART_TIMEOUT);};
window.apiFactoryReset=function (){return request('POST','/api/system/factory-reset',{},RESTART_TIMEOUT);};
const MQTT_TEST_TIMEOUT=30000;
window.apiMqttTest=function (data){return request('POST','/api/mqtt/test',{headers:{'Content-Type':'application/x-www-form-urlencoded'},body:toUrlEncoded(data||{}),silent:true},MQTT_TEST_TIMEOUT);};
window.apiBatchGet=function (url,params){return Governor.batchGet(url,params);};
window.apiAbortPageRequests=function (){Governor.abortPageRequests();};
window.apiInvalidateCache=function (urlPattern){Governor.invalidateCache(urlPattern);};
})();
const Notification={
container:null,notifications:[],
init(){
this.container=document.getElementById('notification-container');
if(!this.container){this.container=document.createElement('div');this.container.id='notification-container';this.container.className='notification-container';document.body.appendChild(this.container);}
},
show(options){
const id='notification-'+Date.now();const duration=options.duration||3000;
const notification=document.createElement('div');notification.id=id;
notification.className='notification notification-'+(options.type||'info');
const icons={primary:'✅',success:'✅',warning:'⚠️',error:'❌',info:'ℹ️'};
const header=document.createElement('div');
header.className='notification-header';
const title=document.createElement('div');
title.className='notification-title';
const icon=document.createElement('i');
icon.textContent=icons[options.type]||icons.info;
const titleText=document.createElement('span');
titleText.textContent=options.title||this.getDefaultTitle(options.type);
title.appendChild(icon);
title.appendChild(titleText);
const closeBtn=document.createElement('button');
closeBtn.type='button';
closeBtn.className='notification-close';
closeBtn.textContent='×';
closeBtn.addEventListener('click',()=>this.close(id));
header.appendChild(title);
header.appendChild(closeBtn);
const body=document.createElement('div');
body.className='notification-body';
if(options.html===true){body.innerHTML=options.message||'';}
else{body.textContent=options.message||'';}
const progress=document.createElement('div');
progress.className='notification-progress';
const progressBar=document.createElement('div');
progressBar.className='notification-progress-bar';
progressBar.style.setProperty('--notification-duration',duration+'ms');
progress.appendChild(progressBar);
notification.appendChild(header);
notification.appendChild(body);
notification.appendChild(progress);
this.container.appendChild(notification);
const notificationObj={id:id,element:notification,timeout:null};this.notifications.push(notificationObj);
if(options.autoClose!==false){notificationObj.timeout=setTimeout(()=>{this.close(id);},duration);}
return id;
},
close(id){
const notification=document.getElementById(id);
if(notification){notification.classList.add('hiding');
const notificationObj=this.notifications.find(n=>n.id===id);
if(notificationObj&&notificationObj.timeout){clearTimeout(notificationObj.timeout);}
setTimeout(()=>{if(notification.parentNode){notification.parentNode.removeChild(notification);}this.notifications=this.notifications.filter(n=>n.id!==id);},300);
}
},
closeAll(){this.notifications.forEach(n=>{this.close(n.id);});},
getDefaultTitle(type){const t={primary:'提示',success:'成功',warning:'警告',error:'错误',info:'信息'};return t[type]||'通知';},
primary(message,title){return this.show({type:'primary',title:title||'提示',message:message});},
success(message,title){return this.show({type:'success',title:title||'成功',message:message});},
warning(message,title){return this.show({type:'warning',title:title||'警告',message:message});},
error(message,title){return this.show({type:'error',title:title||'错误',message:message});},
info(message,title){return this.show({type:'info',title:title||'信息',message:message});}
};
var PageLoader={
_loadedPages:{},
async loadPage(pageId,pageMapping){
var moduleName=pageMapping[pageId];
if(!moduleName||this._loadedPages[moduleName])return ;
try{
var resp=await fetch('/pages/'+moduleName+'.html');
if(!resp.ok)throw new Error('HTTP '+resp.status);
var html=await resp.text();
var container=document.getElementById('content-area');
if(container){
var wrapper=document.createElement('div');
wrapper.innerHTML=html;
while(wrapper.firstChild){
container.appendChild(wrapper.firstChild);
}
}
this._loadedPages[moduleName]=true;
}catch(e){
console.error('[PageLoader] Failed to load:',moduleName,e);
}
},
async loadModals(){
if(this._loadedPages['modals'])return ;
try{
var resp=await fetch('/pages/modals.html');
if(!resp.ok)return ;
var html=await resp.text();
var wrapper=document.createElement('div');
wrapper.innerHTML=html;
while(wrapper.firstChild){
document.body.appendChild(wrapper.firstChild);
}
this._loadedPages['modals']=true;
}catch(e){
console.error('[PageLoader] Failed to load modals:',e);
}
},
async loadFragment(containerId,fragmentName,onLoaded){
var cacheKey='fragment:'+fragmentName;
if(this._loadedPages[cacheKey]){
if(typeof onLoaded==='function')onLoaded();
return ;
}
try{
var resp=await fetch('/pages/fragments/'+fragmentName+'.html');
if(!resp.ok)throw new Error('HTTP '+resp.status);
var html=await resp.text();
var container=document.getElementById(containerId);
if(container){
container.innerHTML=html;
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText(container);
}
}
this._loadedPages[cacheKey]=true;
if(typeof onLoaded==='function')onLoaded();
}catch(e){
console.error('[PageLoader] Failed to load fragment:',fragmentName,e);
var container=document.getElementById(containerId);
if(container){
container.innerHTML='<div class="message message-error" data-i18n="fragment-load-error">加载失败，请刷新重试</div>';
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText(container);
}
}
}
},
isLoaded(moduleName){
return !!this._loadedPages[moduleName];
}
};
var ModuleLoader={
_loadedModules:{},
_moduleCallbacks:{},
_loadedFiles:{},
_moduleLoadQueue:[],
_moduleLoadingCount:0,
_MAX_CONCURRENT_LOADS:4,
_bundleMap:{
'users':'admin-bundle',
'roles':'admin-bundle',
'files':'admin-bundle',
'logs':'admin-bundle',
'rule-script':'admin-bundle'
},
registerModule(name,methods,target){
var self=this;
var dest=target||(typeof AppState!=='undefined'?AppState:window);
Object.keys(methods).forEach(key=>{
dest[key]=typeof methods[key]==='function'?methods[key].bind(dest):methods[key];
});
self._loadedModules[name]=true;
if(self._moduleCallbacks[name]){
var cbs=self._moduleCallbacks[name];
delete self._moduleCallbacks[name];
setTimeout(function (){
cbs.forEach(function (cb){cb();});
},0);
}
},
loadModule(name,callback){
var self=this;
if(this._loadedModules[name]){
if(callback)callback();
return ;
}
if(callback){
if(!this._moduleCallbacks[name])this._moduleCallbacks[name]=[];
this._moduleCallbacks[name].push(callback);
}
if(this._moduleLoadQueue.some(function (item){return item.name===name;}))return ;
this._moduleLoadQueue.push({name:name,retries:0});
this._processQueue();
},
_processQueue(){
var self=this;
if(this._moduleLoadingCount>=this._MAX_CONCURRENT_LOADS||this._moduleLoadQueue.length===0)return ;
var item=null;
for(var i=0;i<this._moduleLoadQueue.length;i++){
if(!this._moduleLoadQueue[i].loading){
item=this._moduleLoadQueue[i];
break;
}
}
if(!item)return ;
if(this._loadedModules[item.name]){
this._moduleLoadQueue=this._moduleLoadQueue.filter(q=>q.name!==item.name);
this._processQueue();
return ;
}
var fileName=self._bundleMap[item.name]||item.name;
if(self._loadedFiles[fileName]){
item.loading=true;
self._moduleLoadQueue=self._moduleLoadQueue.filter(q=>q.name!==item.name);
self._processQueue();
return ;
}
item.loading=true;
this._moduleLoadingCount++;
self._loadedFiles[fileName]=true;
var oldScript=document.querySelector('script[data-module="'+fileName+'"]');
if(oldScript)oldScript.remove();
var script=document.createElement('script');
script.src='/js/modules/'+fileName+'.js';
script.dataset.module=fileName;
script.onload=function (){
self._moduleLoadingCount--;
self._moduleLoadQueue=self._moduleLoadQueue.filter(function (q){
return !self._loadedModules[q.name];
});
setTimeout(function (){self._processQueue();},10);
};
script.onerror=function (){
console.warn('[Module] Failed to load: '+fileName+' (attempt '+(item.retries+1)+'/3)');
script.remove();
self._moduleLoadingCount--;
item.loading=false;
delete self._loadedFiles[fileName];
if(item.retries<2){
item.retries++;
setTimeout(function (){self._processQueue();},1000);
}else{
console.error('[Module] Giving up loading: '+fileName);
self._moduleLoadQueue=self._moduleLoadQueue.filter(q=>q.name!==item.name);
setTimeout(function (){self._processQueue();},200);
}
};
document.head.appendChild(script);
this._processQueue();
},
isLoaded(name){
return !!this._loadedModules[name];
}
};
var i18n=typeof i18n!=='undefined'?i18n:{
currentLang:localStorage.getItem('language')||'zh-CN',
loadedLanguages:['zh-CN'],
loadingLanguages:[],
translations:{
'zh-CN':{},
'en':{}
},
t(key){
const translated=this.translations[this.currentLang]&&this.translations[this.currentLang][key];
if(!translated&&typeof console!=='undefined'&&console.warn){
if(window.DEBUG||location.hostname==='localhost'||location.hostname==='127.0.0.1'||location.hostname==='192.168.4.1'){
console.warn('[i18n] Missing key:',key,'in',this.currentLang||'unknown');
}
}
return translated||key;
},
addTranslations(lang,data){
if(!this.translations[lang]){
this.translations[lang]={};
}
Object.assign(this.translations[lang],data);
if(!this.loadedLanguages.includes(lang)){
this.loadedLanguages.push(lang);
}
const loadingIndex=this.loadingLanguages.indexOf(lang);
if(loadingIndex>-1){
this.loadingLanguages.splice(loadingIndex,1);
}
},
mergeTranslations(lang,data){
this.addTranslations(lang,data);
},
isLanguageLoaded(lang){
return this.loadedLanguages.includes(lang);
},
isLanguageLoading(lang){
return this.loadingLanguages.indexOf(lang)>-1;
},
loadLanguagePack(lang,callback){
if(this.isLanguageLoaded(lang)){
if(callback)callback(true);
return ;
}
if(this.isLanguageLoading(lang)){
let waitCount=0;
const waitInterval=setInterval(()=>{
waitCount++;
if(this.isLanguageLoaded(lang)){
clearInterval(waitInterval);
if(callback)callback(true);
}else if(waitCount>50){
clearInterval(waitInterval);
if(callback)callback(false);
}
},100);
return ;
}
this.loadingLanguages.push(lang);
const script=document.createElement('script');
script.src='./js/modules/i18n-'+lang+'.js';
script.onload=()=>{
if(callback)callback(true);
};
script.onerror=()=>{
const loadingIndex=this.loadingLanguages.indexOf(lang);
if(loadingIndex>-1){
this.loadingLanguages.splice(loadingIndex,1);
}
console.error('Failed to load language pack: '+lang);
if(callback)callback(false);
};
document.head.appendChild(script);
},
setLanguage(lang){
const doSwitch=()=>{
if(this.translations[lang]){
this.currentLang=lang;
localStorage.setItem('language',lang);
this.updatePageText();
if(typeof Notification!=='undefined'){
Notification.success(
lang==='zh-CN'?'语言已切换为中文':'Language switched to English',
lang==='zh-CN'?'成功':'Success'
);
}
return true;
}
return false;
};
if(!this.isLanguageLoaded(lang)&&lang!=='zh-CN'){
this.loadLanguagePack(lang,(success)=>{
if(success){
doSwitch();
}else{
if(typeof Notification!=='undefined'){
Notification.error(
lang==='zh-CN'?'语言包加载失败，已回退到中文':'Language pack load failed, fallback to Chinese',
lang==='zh-CN'?'错误':'Error'
);
}
this.setLanguage('zh-CN');
}
});
return false;
}
return doSwitch();
},
updatePageText(){
document.querySelectorAll('[data-i18n]').forEach(element=>{
const key=element.getAttribute('data-i18n');
const translation=this.t(key);
if(translation&&translation!==key){
if(element.tagName==='INPUT'||element.tagName==='TEXTAREA'){
if(element.type==='button'||element.type==='submit'){
element.value=translation;
}else{
element.placeholder=translation;
}
}else if(element.tagName==='SELECT'){
return ;
}else if(element.tagName==='OPTION'){
element.textContent=translation;
const select=element.parentElement;
if(select&&select.tagName==='SELECT'){
const idx=select.selectedIndex;
select.selectedIndex=idx;
}
}else{
element.textContent=translation;
}
}
});
document.querySelectorAll('[data-i18n-placeholder]').forEach(element=>{
const key=element.getAttribute('data-i18n-placeholder');
const translation=this.t(key);
if(translation&&translation!==key){
element.placeholder=translation;
}
});
document.querySelectorAll('[data-i18n-title]').forEach(element=>{
const key=element.getAttribute('data-i18n-title');
const translation=this.t(key);
if(translation&&translation!==key){
element.title=translation;
}
});
document.documentElement.lang=this.currentLang;
}
};
(function (){
if(typeof i18n==='undefined')return ;
var zhTranslations={
'login-title':'设备配置管理',
'username-label':'用户名',
'password-label':'密码',
'username-placeholder':'请输入用户名',
'password-placeholder':'请输入密码',
'remember-label':'记住密码',
'login-button':'登录系统',
'app-title':'设备管理系统',
'page-title-dashboard':'设备监控仪表盘',
'page-title-protocol':'通信协议',
'page-title-network':'网络设置',
'page-title-device':'设备配置',
'page-title-data':'文件管理',
'page-title-system':'系统监控',
'page-title-users':'用户管理',
'page-title-roles':'角色管理',
'page-title-logs':'设备日志',
'page-title-gpio':'GPIO配置',
'page-title-peripheral':'外设配置',
'page-title-periph-exec':'外设执行',
'menu-dashboard':'设备监控',
'menu-protocol':'通信协议',
'menu-network':'网络设置',
'menu-device':'设备配置',
'menu-data':'文件管理',
'menu-users':'用户管理',
'menu-roles':'角色管理',
'menu-logs':'设备日志',
'menu-gpio':'GPIO配置',
'menu-peripheral':'外设配置',
'menu-periph-exec':'外设执行',
'menu-rule-script':'规则脚本',
'menu-device-control':'设备大屏',
'page-title-device-control':'设备大屏',
'device-control-title':'设备大屏',
'device-control-empty':'暂无可控制的规则',
'device-control-data-section':'采集数据',
'device-control-action-section':'控制操作',
'device-control-monitor-section':'监测数据',
'device-control-visualization':'设备可视化',
'device-control-dashboard':'设备大屏',
'device-control-online':'在线',
'device-control-no-monitor':'暂无监测数据',
'device-control-no-action':'暂无控制操作',
'device-control-group-gpio':'GPIO 控制',
'device-control-group-modbus':'Modbus 控制',
'device-control-group-system':'系统操作',
'device-control-group-script':'脚本执行',
'device-control-group-sensor':'传感器读取',
'device-control-group-other':'其他',
'device-control-modbus-health-title':'Modbus 轮询健康',
'device-control-modbus-health-empty':'暂无 Modbus 轮询风险提示',
'device-control-reset-layout':'重置布局',
'dc-modbus-devices-title':'Modbus 子设备控制',
'dc-modbus-ctrl-relay':'继电器控制',
'dc-modbus-ctrl-pwm':'PWM 控制',
'dc-modbus-ctrl-pid':'PID调速',
'device-control-gpio':'开关控制',
'device-control-modbus':'数据采集',
'device-control-system':'系统控制',
'device-control-script':'脚本执行',
'device-control-sensor':'传感器',
'device-control-other':'其他控制',
'device-control-execute':'执行',
'device-control-executing':'执行中...',
'device-control-collect':'采集',
'device-control-confirm-system':'确认执行此系统操作？',
'device-control-exec-success':'执行成功',
'device-control-exec-fail':'执行失败',
'device-control-target':'目标外设',
'user-name':'管理员',
'change-password-btn':'修改密码',
'logout-btn':'退出登录',
'theme-toggle':'切换主题',
'theme-light':'浅色模式',
'theme-dark':'深色模式',
'cpu-label':'CPU使用率',
'memory-label':'内存使用率',
'storage-label':'存储使用率',
'temp-label':'设备温度',
'device-status-title':'设备状态',
'online-text':'在线',
'device-name-col':'设备名称',
'device-status-col':'状态',
'last-update-col':'最后更新',
'device-actions-col':'操作',
'status-online':'运行正常',
'status-warning':'警告',
'status-offline':'离线',
'view-details':'查看详情',
'dashboard-device-info':'设备信息',
'dashboard-uptime':'运行时间',
'dashboard-uptime-desc':'系统启动至今',
'dashboard-network':'网络状态',
'dashboard-resource-usage':'资源使用情况',
'dashboard-refresh':'刷新',
'dashboard-device-monitor':'设备监控',
'dashboard-fullscreen':'全屏',
'dashboard-exit-fullscreen':'退出全屏',
'dashboard-open-newtab':'新标签页全屏',
'dashboard-fullscreen-page-title':'设备监控',
'dashboard-exit-newtab':'关闭标签页',
'dashboard-auto-refresh':'自动刷新',
'dashboard-close-hint':'请手动关闭此标签页',
'dashboard-flash':'Flash 存储',
'dashboard-heap':'内存 (Heap)',
'dashboard-fs':'文件系统 (LittleFS)',
'dashboard-used':'已用',
'dashboard-free':'可用',
'dashboard-total':'总计',
'dashboard-firmware':'固件',
'dashboard-min-free':'最小可用',
'dashboard-user-stats':'用户统计',
'dashboard-total-users':'总用户数',
'dashboard-online-users':'在线用户',
'dashboard-active-sessions':'活跃会话',
'config-title':'通信协议配置',
'protocol-title':'通信协议配置',
'rtu-port-label':'串口端口',
'rtu-baudrate-label':'波特率',
'rtu-databits-label':'数据位',
'rtu-stopbits-label':'停止位',
'rtu-parity-label':'校验位',
'rtu-timeout-label':'超时时间(ms)',
'tcp-ip-label':'IP地址',
'tcp-port-label':'端口',
'tcp-slave-id-label':'从站ID',
'tcp-timeout-label':'超时时间(ms)',
'mqtt-broker-label':'MQTT Broker',
'mqtt-port-label':'端口',
'mqtt-client-id-label':'客户端ID',
'mqtt-alive-label':'心跳(秒)',
'mqtt-username-label':'用户名',
'mqtt-password-label':'密码',
'mqtt-publish-label':'发布主题',
'mqtt-subscribe-label':'订阅主题',
'mqtt-publish-qos-label':'发布QoS',
'mqtt-conn-timeout-label':'连接超时(毫秒)',
'mqtt-access-mode-label':'接入模式',
'mqtt-access-mode-direct':'MQTT直连',
'mqtt-access-mode-transparent':'MQTT透传',
'mqtt-auto-reconnect-label':'自动重连',
'mqtt-publish-retain-label':'保留消息',
'mqtt-publish-section-title':'发布主题配置',
'mqtt-add-topic-btn':'增加主题',
'mqtt-delete-topic-btn':'删除',
'mqtt-direct-connect-label':'MQTT直连',
'mqtt-publish-content-label':'发布内容',
'save-config-btn':'保存配置',
'modbus-rtu-save-ok':'Modbus RTU配置保存成功！',
'modbus-tcp-save-ok':'Modbus TCP配置保存成功！',
'mqtt-save-ok':'MQTT配置保存成功！',
'http-save-ok':'HTTP配置保存成功！',
'coap-save-ok':'CoAP配置保存成功！',
'tcp-save-ok':'TCP配置保存成功！',
'network-title':'网络设置',
'net-tab-basic':'基本配置',
'net-tab-ap':'热点配置',
'net-tab-advance':'高级配置',
'wifi-scan-btn':'选择Wifi网络',
'wifi-mode-label':'网络模式',
'wifi-mode-sta':'仅客户端模式 (STA)',
'wifi-mode-ap':'仅热点模式 (AP)',
'wifi-ssid-label':'SSID',
'wifi-security-label':'安全类型',
'wifi-security-none':'无',
'wifi-security-wpa':'WPA/WPA2',
'wifi-security-wpa3':'WPA3',
'wifi-device-name-label':'设备名称',
'wifi-password-label':'密码',
'wifi-save-ok':'WiFi配置保存成功！',
'wifi-save-fail':'WiFi配置保存失败！',
'wifi-mode-changed-title':'网络配置已保存',
'wifi-mode-sta-hint':'可通过域名 http://{domain} 访问Web服务',
'wifi-mode-ap-hint':'请先连接热点 [{ssid}]，然后访问 http://{ip}',
'wifi-restart-hint':'网络配置变更需要重启网络服务才能生效，请等待约10秒...',
'wifi-reconnect-hint':'如无法访问，请刷新页面或重新连接网络。',
'wifi-saving-mode':'网络模式切换中...',
'wifi-save-ready':'保存配置',
'wifi-mode-notice-title':'网络模式切换提醒：',
'wifi-mode-notice-ap':'切换到AP模式后，请连接热点 [{ssid}] 访问 http://{ip}',
'wifi-mode-notice-sta':'切换到STA模式后，可通过 http://{domain} 访问',
'wifi-mode-notice-countdown':'按钮将在 {seconds} 秒后恢复可用。',
'ap-config-title':'热点配置',
'ap-ssid-label':'热点名称',
'ap-channel-label':'信道',
'ap-password-label':'热点密码',
'ap-hidden-label':'隐藏热点',
'ap-hidden-no':'否',
'ap-hidden-yes':'是',
'ap-max-connections-label':'最大连接数',
'ap-save-ok':'热点配置保存成功！',
'static-ip-title':'静态IP配置',
'static-ip-label':'IP地址',
'subnet-label':'子网掩码',
'gateway-label':'网关',
'dns1-label':'首选DNS',
'dns2-label':'备用DNS',
'wifi-dhcp-label':'IP获取方式',
'wifi-mdns-label':'mDNS',
'wifi-enable':'启用',
'wifi-disable':'禁用',
'custom-domain-label':'自定义域名',
'domain-config-title':'域名配置',
'connection-settings-title':'连接设置',
'connect-timeout-label':'连接超时 (毫秒)',
'reconnect-interval-label':'重连间隔 (毫秒)',
'max-reconnect-label':'最大重连次数',
'conflict-detection-label':'IP冲突检测',
'advanced-save-ok':'高级配置保存成功！',
'device-config-title':'设备配置',
'dev-tab-basic':'基本信息',
'dev-tab-ntp':'NTP时间',
'dev-tab-ota':'OTA升级',
'dev-tab-advanced':'高级配置',
'dev-tab-system':'系统操作',
'dev-id-label':'设备编号',
'dev-id-placeholder':'留空则使用系统默认值(FBE+MAC)',
'dev-id-hint':'可自定义任意格式，留空自动生成',
'dev-product-number-label':'产品编号',
'dev-user-id-label':'用户ID',
'dev-cache-title':'缓存管理',
'dev-cache-duration-label':'缓存时间设置：',
'dev-cache-1h':'1小时',
'dev-cache-6h':'6小时',
'dev-cache-12h':'12小时',
'dev-cache-24h':'24小时',
'dev-cache-48h':'48小时',
'dev-cache-72h':'72小时',
'dev-cache-save-btn':'保存',
'dev-cache-save-ok':'缓存时间设置已保存',
'dev-cache-hint':'设置浏览器缓存JS/CSS资源的有效期，修改后新请求生效。',
'dev-cache-clear-btn':'清除浏览器缓存',
'dev-cache-clear-ok':'浏览器缓存已清除，即将刷新页面...',
'dev-name-label':'设备名称',
'dev-location-label':'安装位置',
'dev-description-label':'设备描述',
'dev-basic-save-btn':'保存信息',
'dev-basic-save-ok':'设备信息保存成功！',
'dev-time-title':'当前时间',
'dev-time-refresh':'刷新',
'dev-time-datetime-label':'日期时间',
'dev-time-synced-label':'NTP同步状态',
'dev-time-uptime-label':'设备运行时间',
'dev-ntp-enable-label':'NTP同步',
'dev-ntp-server1-label':'NTP服务器1',
'dev-ntp-server2-label':'NTP服务器2',
'dev-timezone-label':'时区',
'dev-sync-interval-label':'同步间隔 (秒)',
'dev-ntp-save-btn':'保存NTP配置',
'dev-ntp-save-ok':'NTP配置保存成功！',
'ap-clients-label':'连接客户数',
'dev-ota-progress-label':'升级进度',
'dev-ota-info-title':'固件信息',
'dev-ota-refresh':'刷新',
'dev-ota-version-label':'当前版本：',
'dev-ota-status-label':'状态：',
'dev-ota-flash-label':'Flash空间：',
'dev-ota-free-label':'可用空间：',
'dev-ota-progress':'升级进度',
'dev-ota-online-title':'在线升级',
'dev-ota-url-label':'固件下载地址',
'dev-ota-url-btn':'开始在线升级',
'dev-ota-upload-title':'本地上传升级',
'dev-ota-file-label':'选择固件文件 (.bin)',
'dev-ota-file-hint':'仅支持 .bin 格式的固件文件',
'dev-ota-upload-btn':'上传并升级',
'dev-ota-ready':'就绪',
'choose-file-btn':'选择文件',
'no-file-selected':'未选择任何文件',
'dev-sys-restart-title':'重启设备',
'dev-sys-restart-hint':'重启设备将会断开所有连接，配置数据将保留。',
'dev-sys-restart-delay':'延迟（秒）：',
'dev-sys-restart-btn':'立即重启',
'dev-sys-factory-title':'恢复出厂设置',
'dev-sys-factory-warning':'警告：此操作将清除所有用户配置和数据，恢复到出厂默认状态！',
'dev-sys-factory-hint':'设备将自动重启，所有配置将丢失，请谨慎操作。',
'dev-sys-factory-confirm-label':'输入"RESET"确认：',
'dev-sys-factory-btn':'恢复出厂设置',
'dev-sys-factory-confirm-error':'请输入 RESET 以确认操作',
'dev-sys-factory-success':'恢复出厂设置成功，设备正在重启...',
'dev-sys-factory-fail':'恢复出厂设置失败',
'dev-sys-factory-title-msg':'恢复出厂设置',
'dev-sys-factory-processing':'<i class="fas fa-spinner fa-spin"></i> 处理中...',
'dev-sys-factory-btn-html':'<i class="fas fa-undo"></i> 恢复出厂设置',
'dev-sys-hw-title':'硬件信息',
'dev-sys-chip-label':'芯片型号',
'dev-sys-cpu-label':'CPU频率',
'dev-sys-heap-label':'空闲堆栈',
'dev-sys-flash-label':'Flash大小',
'dev-sys-sdk-label':'SDK版本',
'dev-sys-fw-label':'固件版本',
'data-page-title':'文件管理',
'fs-refresh-btn':'刷新',
'fs-up-btn':'返回上级',
'fs-export-config':'导出配置',
'fs-import-config':'导入配置',
'fs-no-file-selected':'请先选择一个配置文件',
'fs-editor-empty':'文件内容为空',
'fs-invalid-json':'文件内容不是有效的JSON格式',
'fs-export-ok':'配置导出成功',
'fs-import-ok':'配置导入成功',
'fs-import-fail':'配置导入失败',
'fs-import-too-large':'文件过大，最大支持64KB',
'fs-import-not-object':'配置文件必须是JSON对象格式',
'fs-import-invalid-json':'文件内容不是有效的JSON格式',
'fs-import-confirm':'确定要用导入的文件覆盖当前配置吗？此操作不可撤销！',
'protocol-tab-coming-soon':'即将推出',
'fs-loading':'加载中...',
'fs-select-file':'请选择文件',
'fs-empty-dir':'空目录',
'fs-load-fail':'加载失败',
'fs-editor-placeholder':'选择文件后在此编辑...',
'sidebar-copyright':'FastBee物联网平台',
'sidebar-version':'v1.0.0',
'footer-copyright':'© 2026 FastBee物联网平台 | 官网: www.fastbee.cn',
'users-title':'用户管理',
'add-user':'添加用户',
'add-user-btn-text':'添加用户',
'user-username-col':'用户名',
'user-role-col':'角色',
'user-lastlogin-col':'最后登录',
'user-status-col':'状态',
'user-actions-col':'操作',
'user-status-active':'启用',
'user-status-inactive':'禁用',
'user-status-locked':'已锁定',
'edit-user':'编辑',
'disable-user':'禁用',
'enable-user':'启用',
'unlock-user':'解锁',
'delete-user':'删除',
'no-users':'暂无用户数据',
'change-password-title':'修改密码',
'current-password-label':'当前密码',
'new-password-label':'新密码',
'confirm-password-label':'确认新密码',
'cancel':'取消',
'confirm-change':'确认修改',
'password-changed':'密码修改成功！',
'password-error':'密码错误或新密码不匹配！',
'add-user-title':'添加用户',
'add-username-label':'用户名',
'add-password-label':'密码',
'add-confirm-password-label':'确认密码',
'add-role-label':'角色',
'add-user-confirm':'添加',
'user-added':'用户添加成功！',
'roles-title':'角色管理',
'add-role-btn-text':'新增角色',
'roles-admin-hint':'超级管理员(admin)角色不可编辑或删除，其他角色可进行管理操作。',
'role-id-col':'角色ID',
'role-name-col':'角色名称',
'role-desc-col':'描述',
'role-perm-count-col':'权限数',
'role-type-col':'类型',
'role-actions-col':'操作',
'role-type-super':'超级管理员',
'role-type-builtin':'内置角色',
'role-type-custom':'自定义',
'role-view-perms':'查看权限',
'role-edit':'编辑',
'role-delete':'删除',
'role-perm-detail-suffix':' - 权限详情',
'role-add-modal-title':'新增角色',
'role-edit-modal-title':'编辑角色',
'role-id-label':'角色ID',
'role-id-hint':'角色ID为唯一标识，创建后不可修改',
'role-name-label':'角色名称',
'role-desc-label':'角色描述',
'role-perms-label':'权限配置',
'role-save-btn':'保存',
'role-saving-btn':'保存中...',
'logs-title':'设备日志',
'log-auto-refresh-label':'自动刷新',
'log-refresh-btn':'刷新日志',
'log-clear-btn':'清空日志',
'log-loading':'正在加载日志...',
'log-empty':'日志文件为空',
'log-load-fail':'加载日志失败',
'log-truncated':' (部分显示)',
'log-clear-confirm':'确定要清空所有设备日志吗？此操作不可恢复。',
'log-clear-ok':'日志已清空',
'log-current-file-prefix':'当前日志：',
'gpio-title':'GPIO配置',
'add-gpio-btn-text':'新增GPIO',
'gpio-pin-col':'引脚号',
'gpio-name-col':'名称',
'gpio-mode-col':'模式',
'gpio-status-col':'当前状态',
'gpio-actions-col':'操作',
'gpio-loading':'加载中...',
'gpio-add-modal-title':'新增GPIO',
'gpio-edit-modal-title':'编辑GPIO',
'gpio-pin-label':'引脚号 (0-39)',
'gpio-name-label':'名称',
'gpio-mode-label':'模式',
'gpio-default-label':'初始值',
'gpio-mode-1':'数字输入',
'gpio-mode-2':'数字输出',
'gpio-mode-3':'数字输入(上拉)',
'gpio-mode-4':'数字输入(下拉)',
'gpio-mode-5':'模拟输入',
'gpio-mode-6':'模拟输出',
'gpio-mode-7':'PWM输出',
'gpio-default-low':'低电平 (LOW)',
'gpio-default-high':'高电平 (HIGH)',
'gpio-status-high':'高电平',
'gpio-status-low':'低电平',
'gpio-status-unknown':'未知',
'gpio-edit':'编辑',
'gpio-delete':'删除',
'gpio-toggle':'切换',
'logout':'退出登录',
'change-password':'修改密码',
'logout-confirm':'确定要退出登录吗？',
'user':'用户',
'admin':'管理员',
'operator':'操作员',
'viewer':'查看者',
'confirm-delete-user':'确定要删除用户',
'confirm-delete-role':'确定要删除角色',
'confirm-toggle-enable':'确定要启用用户',
'confirm-toggle-disable':'确定要禁用用户',
'confirm-unlock':'确定要解锁账户',
'confirm-restart':'确定要重启设备吗？',
'login-success':'登录成功',
'login-welcome':'欢迎',
'login-fail':'登录失败',
'login-input-empty':'请输入用户名和密码',
'login-logging-in':'登录中...',
'network-connected':'网络已连接 IP: ',
'network-disconnected':'网络未连接',
'operation-success':'操作成功',
'operation-fail':'操作失败',
'save-success':'保存成功',
'delete-success':'删除成功',
'loading':'加载中...',
'login-logging-in-html':'<i class="fas fa-spinner fa-spin"></i> 登录中...',
'login-success-msg':'登录成功',
'login-welcome-title':'欢迎',
'login-fail-title':'登录失败',
'login-fail-msg':'用户名或密码错误',
'login-empty-warning':'请输入用户名和密码',
'user-locked-badge':'已锁定',
'no-users-data':'暂无用户数据',
'confirm-delete-user-msg':'确定要删除用户',
'confirm-delete-user-suffix':'吗？',
'confirm-enable-user':'确定要启用用户',
'confirm-disable-user':'确定要禁用用户',
'confirm-unlock-user':'确定要解锁账户',
'confirm-suffix':'吗？',
'user-enabled-msg':'已启用',
'user-disabled-msg':'已禁用',
'user-unlocked-msg':'已解锁',
'user-deleted-msg':'已删除',
'user-status-update':'状态更新',
'unlock-success':'解锁成功',
'delete-user-title':'删除成功',
'add-user-modal-title':'添加用户',
'edit-user-modal-title':'编辑用户',
'confirm-add-btn':'确认添加',
'confirm-save-btn':'保存修改',
'adding-btn':'添加中...',
'saving-btn':'保存中...',
'add-user-success':'添加成功',
'edit-user-success':'编辑用户',
'add-user-fail':'添加用户失败',
'edit-user-fail':'编辑用户失败',
'add-user-fail-msg':'添加用户失败，用户名可能已存在',
'modify-user-fail-msg':'修改用户失败',
'validate-username-empty':'请输入用户名！',
'validate-username-len':'用户名长度3-32位！',
'validate-pwd-empty':'请输入密码！',
'validate-pwd-mismatch':'密码与确认密码不一致！',
'validate-pwd-len':'密码长度至少6位！',
'validate-all-fields':'请填写所有字段！',
'validate-new-pwd-mismatch':'新密码与确认密码不一致！',
'validate-new-pwd-len':'新密码长度至少6位！',
'change-pwd-title':'修改密码',
'change-pwd-fail':'修改密码失败',
'change-pwd-submitting':'提交中...',
'change-pwd-success-msg':'密码修改成功，请重新登录',
'change-pwd-success-title':'修改成功',
'change-pwd-fail-msg':'密码修改失败，请检查原密码是否正确',
'confirm-change-btn':'确认修改',
'role-not-exist':'角色不存在',
'error-title':'错误',
'role-add-title':'新增角色',
'role-edit-title':'编辑角色',
'role-saving-text':'保存中...',
'role-save-text':'保存',
'role-validate-id':'请输入角色ID！',
'role-validate-name':'请输入角色名称！',
'role-fail-add':'新增角色失败',
'role-fail-edit':'编辑角色失败',
'role-fail-create-msg':'创建角色失败',
'role-fail-update-msg':'更新角色失败',
'role-created':'创建',
'role-updated':'修改',
'role-success-suffix':'成功',
'role-mgmt-title':'角色管理',
'role-modal-not-found':'弹窗元素不存在',
'confirm-delete-role-msg':'确定要删除角色',
'confirm-delete-role-suffix':'吗？',
'role-deleted-msg':'已删除',
'role-detail-suffix':' - 权限详情',
'log-load-fail-html':'<div class="u-empty-state u-text-danger">加载日志失败</div>',
'log-empty-html':'<div class="u-empty-state u-text-muted">日志文件为空</div>',
'log-line-unit':' 行 | ',
'log-truncated-suffix':' (部分显示)',
'log-clear-confirm-msg':'确定要清空所有设备日志吗？此操作不可恢复。',
'log-clearing-html':'<i class="fas fa-spinner fa-spin"></i> 清空中...',
'log-clear-btn-html':'<i class="fas fa-trash"></i> 清空日志',
'log-cleared-msg':'日志已清空',
'log-op-title':'操作成功',
'log-op-fail':'操作失败',
'fs-loading-text':'<div class="u-text-muted">加载中...</div>',
'fs-load-fail-text':'<div class="u-text-danger">加载失败</div>',
'fs-empty-dir-html':'<div class="u-empty-state u-text-muted">空目录</div>',
'fs-file-type-unsupported':'此文件类型不支持编辑',
'fs-file-loading':'加载中...',
'fs-file-ready-prefix':'大小: ',
'fs-file-ready-suffix':' | 就绪',
'fs-file-load-fail':'加载失败',
'fs-file-load-fail-prefix':'加载失败: ',
'fs-file-unknown-error':'未知错误',
'fs-saving-text':'保存中...',
'fs-save-ok-text':'保存成功',
'fs-save-fail-prefix':'保存失败: ',
'fs-save-fail-text':'保存失败',
'fs-save-ok-msg':'文件保存成功',
'fs-mgmt-title':'文件管理',
'fs-no-perm-tip':'权限不足，无法保存文件（需要管理员权限）',
'fs-modified-confirm':'文件已修改，是否保存？',
'fs-select-file-text':'请选择文件',
'fs-space-prefix':'总空间: ',
'fs-space-used-prefix':' | 已用: ',
'monitor-connected':'已连接',
'monitor-disconnected':'未连接',
'net-load-fail':'加载网络配置失败',
'net-settings-title':'网络设置',
'net-save-ok':'网络配置保存成功',
'net-save-fail':'保存失败',
'net-saving-html':'<i class="fas fa-spinner fa-spin"></i> 保存中...',
'net-status-load-fail':'获取网络状态失败',
'net-status-title-msg':'网络状态',
'net-refreshing-html':'刷新中...',
'net-refresh-html':'刷新',
'net-status-connected':'已连接',
'net-status-disconnected':'未连接',
'net-status-connecting':'连接中...',
'net-status-ap':'AP模式',
'net-status-failed':'连接失败',
'net-mode-sta':'仅客户端 (STA)',
'net-mode-ap':'仅热点 (AP)',
'net-mdns-enabled':'已启用',
'net-mdns-disabled':'禁用',
'net-reconnect-unit':' 次',
'net-accessible':'可访问',
'net-inaccessible':'不可访问',
'net-conflict-yes':'已检测到冲突',
'net-no-conflict':'无冲突',
'net-ap-clients-unit':' 台',
'ns-conn-time-label':'连接时长',
'ns-reconnect-label':'重连次数',
'ns-internet-label':'互联网',
'ns-conflict-label':'IP 冲突',
'ns-uptime-label':'运行时间',
'ns-tx-count-label':'发送计数',
'ns-rx-count-label':'接收计数',
'net-count-unit':' 条',
'wifi-scanning-html':'<i class="fas fa-spinner fa-spin"></i> 扫描中...',
'wifi-scan-btn-html':'<i class="fas fa-wifi"></i> 选择Wifi网络',
'wifi-scanning-result':'<div class="wifi-scan-state"><i class="fas fa-spinner fa-spin wifi-scan-state-icon"></i><div class="wifi-scan-state-text">正在扫描...</div></div>',
'wifi-scan-fail':'<div class="wifi-scan-state is-error"><i class="fas fa-exclamation-circle wifi-scan-state-icon"></i><div class="wifi-scan-state-text">扫描失败</div></div>',
'wifi-scan-fail-msg':'扫描失败，请稍后重试',
'wifi-scan-busy':'<div class="wifi-scan-state is-warning"><i class="fas fa-spinner fa-spin wifi-scan-state-icon"></i><div class="wifi-scan-state-text">扫描正在进行中，请稍后再试</div></div>',
'wifi-no-network':'<div class="wifi-scan-state"><i class="fas fa-wifi wifi-scan-state-icon"></i><div class="wifi-scan-state-text">未找到WiFi网络</div></div>',
'wifi-selected-prefix':'已选择: ',
'wifi-scan-title':'WiFi',
'wifi-modal-title':'选择WiFi网络',
'wifi-encrypted':'加密',
'wifi-open':'开放',
'wifi-channel-prefix':'信道: ',
'dev-time-synced-html':'<span class="badge badge-success">已同步</span>',
'dev-time-not-synced-html':'<span class="badge badge-warning">未同步</span>',
'dev-time-no-network-html':'<span class="badge badge-warning">未同步</span>',
'dev-refresh-disabled-html':'<i class="fas fa-ban"></i> 没有网络',
'dev-time-no-network-tip':'没有网络连接，无法进行NTP同步',
'dev-time-uptime-unit':'时 ',
'dev-time-uptime-min':'分 ',
'dev-time-uptime-sec':'秒',
'dev-refreshing-html':'刷新中...',
'dev-refresh-html':'刷新',
'dev-save-basic-ok':'设备信息保存成功',
'dev-save-ntp-ok':'NTP配置保存成功',
'dev-save-fail':'保存失败',
'dev-config-title':'设备配置',
'dev-ntp-config-title':'NTP配置',
'dev-restart-confirm-prefix':'确定要重启设备？将在 ',
'dev-restart-confirm-suffix':' 秒后重启。',
'dev-restarting-html':'<i class="fas fa-spinner fa-spin"></i> 处理中...',
'dev-restart-btn-html':'<i class="fas fa-power-off"></i> 立即重启',
'dev-restart-msg-prefix':'设备将在 ',
'dev-restart-msg-suffix':' 秒后重启，请稍后刷新页面。',
'dev-restart-title':'设备重启',
'dev-restart-fail':'重启指令发送失败',
'dashboard-connected-prefix':'网络已连接 IP: ',
'dashboard-disconnected':'网络未连接',
'provision-active':'配网中',
'provision-inactive':'未启动',
'provision-save-ok':'AP配网配置保存成功',
'provision-title':'AP配网',
'provision-start-ok-prefix':'配网热点已启动: ',
'provision-start-fail':'启动失败',
'provision-starting-html':'<i class="fas fa-spinner fa-spin"></i> 启动中...',
'provision-start-html':'<i class="fas fa-play"></i> 启动配网',
'provision-stop-ok':'配网热点已停止',
'provision-stop-fail':'停止失败',
'provision-stopping-html':'<i class="fas fa-spinner fa-spin"></i> 停止中...',
'provision-stop-html':'<i class="fas fa-stop"></i> 停止配网',
'ble-active':'配网中',
'ble-inactive':'未启动',
'ble-remaining-unit':'秒',
'ble-save-ok':'蓝牙配网配置保存成功',
'ble-title':'蓝牙配网',
'ble-start-ok-prefix':'蓝牙配网已启动: ',
'ble-start-fail':'启动失败',
'ble-starting-html':'<i class="fas fa-spinner fa-spin"></i> 启动中...',
'ble-start-html':'<i class="fas fa-play"></i> 启动蓝牙配网',
'ble-stop-ok':'蓝牙配网已停止',
'ble-stop-fail':'停止失败',
'ble-stopping-html':'<i class="fas fa-spinner fa-spin"></i> 停止中...',
'ble-stop-html':'<i class="fas fa-stop"></i> 停止蓝牙配网',
'ota-ready':'就绪',
'ota-in-progress':'升级中',
'ota-done':'完成',
'ota-title':'OTA升级',
'ota-url-empty':'请输入固件下载地址',
'ota-url-invalid':'URL必须以http://或https://开头',
'ota-no-network-tip':'网络不可用，无法从URL下载固件',
'ota-no-network-msg':'网络不可用 - 请先连接WiFi',
'ota-start-ok':'开始从URL下载固件并升级',
'ota-start-fail':'启动失败',
'ota-downloading-html':'<i class="fas fa-spinner fa-spin"></i> 下载中...',
'ota-start-url-html':'<i class="fas fa-download"></i> 开始在线升级',
'ota-file-empty':'请选择固件文件',
'ota-file-invalid':'仅支持.bin格式的固件文件',
'ota-upload-ok':'固件上传成功，设备即将重启',
'ota-upload-ok2':'固件上传完成',
'ota-upload-fail-prefix':'上传失败: HTTP ',
'ota-uploading-html':'<i class="fas fa-spinner fa-spin"></i> 上传中...',
'ota-upload-btn-html':'<i class="fas fa-upload"></i> 上传并升级',
'ota-upload-network-fail':'上传失败: 网络错误',
'device-offline-error':'设备离线或不可达，请检查网络连接',
'ota-complete-msg':'固件升级完成，设备即将重启',
'ota-progress-fail':'获取OTA进度失败:',
'ota-upload-fail':'上传失败',
'gpio-empty':'暂无GPIO配置',
'gpio-loading-html':'<tr><td colspan="5" class="u-empty-cell">加载中...</td></tr>',
'gpio-fail-html':'<tr><td colspan="5" class="u-empty-cell u-text-danger">加载失败</td></tr>',
'gpio-empty-html':'<tr><td colspan="5" class="u-empty-cell">暂无GPIO配置</td></tr>',
'gpio-validate-pin-name':'请填写引脚号和名称',
'gpio-saving-text':'保存中...',
'gpio-add-ok':'GPIO添加成功',
'gpio-update-ok':'GPIO更新成功',
'gpio-save-fail':'保存失败，请检查连接',
'gpio-deleted-prefix':' 已删除',
'gpio-delete-fail':'删除失败，请检查连接',
'gpio-toggle-ok':'状态已切换',
'gpio-toggle-fail':'切换失败',
'gpio-config-title':'GPIO配置',
'gpio-state-high':'高电平',
'gpio-state-low':'低电平',
'gpio-confirm-delete':'确定要删除 GPIO ',
'gpio-confirm-suffix':' 吗？',
'peripheral-title':'外设配置',
'peripheral-filter-all':'全部外设',
'peripheral-filter-comm':'通信接口',
'peripheral-filter-gpio':'GPIO接口',
'peripheral-filter-analog':'模拟信号',
'peripheral-filter-debug':'调试接口',
'peripheral-filter-special':'专用外设',
'add-peripheral-btn-text':'新增外设',
'add-peripheral-btn':'新增外设',
'peripheral-id-col':'ID',
'peripheral-name-col':'名称',
'peripheral-type-col':'类型',
'peripheral-pins-col':'引脚',
'peripheral-status-col':'状态',
'peripheral-actions-col':'操作',
'peripheral-status-disabled':'已禁用',
'peripheral-status-enabled':'已启用',
'peripheral-status-initialized':'已初始化',
'peripheral-status-running':'运行中',
'peripheral-status-error':'错误',
'peripheral-status-unknown':'未知',
'peripheral-edit':'编辑',
'peripheral-delete':'删除',
'peripheral-enable':'启用',
'peripheral-disable':'禁用',
'peripheral-add-modal-title':'新增外设',
'peripheral-edit-modal-title':'编辑外设',
'peripheral-id-label':'外设ID',
'peripheral-name-label':'显示名称',
'peripheral-type-label':'外设类型',
'peripheral-enabled-label':'启用外设',
'peripheral-type-uart':'UART串口',
'peripheral-type-i2c':'I2C总线',
'peripheral-type-spi':'SPI总线',
'peripheral-type-can':'CAN总线',
'peripheral-type-usb':'USB接口',
'peripheral-type-gpio-in':'数字输入',
'peripheral-type-gpio-out':'数字输出',
'peripheral-type-gpio-in-pullup':'数字输入(上拉)',
'peripheral-type-gpio-in-pulldown':'数字输入(下拉)',
'peripheral-type-gpio-analog-in':'模拟输入',
'peripheral-type-gpio-analog-out':'模拟输出',
'peripheral-type-gpio-pwm':'PWM输出',
'peripheral-type-gpio-int-rising':'中断(上升沿)',
'peripheral-type-gpio-int-falling':'中断(下降沿)',
'peripheral-type-gpio-int-change':'中断(变化)',
'peripheral-type-gpio-touch':'触摸输入',
'peripheral-type-adc':'ADC转换',
'peripheral-type-dac':'DAC转换',
'peripheral-type-jtag':'JTAG调试',
'peripheral-type-swd':'SWD调试',
'peripheral-type-lcd':'LCD显示',
'peripheral-type-sdio':'SD卡接口',
'peripheral-type-sensor':'传感器',
'peripheral-type-camera':'摄像头',
'peripheral-type-ethernet':'以太网',
'uart-baudrate-label':'波特率',
'uart-databits-label':'数据位',
'uart-stopbits-label':'停止位',
'uart-parity-label':'校验位',
'uart-tx-pin-label':'TX引脚',
'uart-rx-pin-label':'RX引脚',
'uart-parity-none':'无校验',
'uart-parity-even':'偶校验',
'uart-parity-odd':'奇校验',
'i2c-freq-label':'时钟频率(Hz)',
'i2c-sda-pin-label':'SDA引脚',
'i2c-scl-pin-label':'SCL引脚',
'i2c-address-label':'从机地址(可选)',
'spi-freq-label':'时钟频率(Hz)',
'spi-mode-label':'SPI模式',
'spi-miso-pin-label':'MISO引脚',
'spi-mosi-pin-label':'MOSI引脚',
'spi-sck-pin-label':'SCK引脚',
'spi-cs-pin-label':'CS引脚',
'spi-mode-0':'模式0 (CPOL=0, CPHA=0)',
'spi-mode-1':'模式1 (CPOL=0, CPHA=1)',
'spi-mode-2':'模式2 (CPOL=1, CPHA=0)',
'spi-mode-3':'模式3 (CPOL=1, CPHA=1)',
'can-baudrate-label':'波特率',
'can-tx-pin-label':'TX引脚',
'can-rx-pin-label':'RX引脚',
'usb-vid-label':'Vendor ID',
'usb-pid-label':'Product ID',
'gpio-initial-label':'初始状态',
'gpio-pwm-channel-label':'PWM通道',
'gpio-pwm-resolution-label':'PWM分辨率(位)',
'gpio-initial-low':'低电平',
'gpio-initial-high':'高电平',
'adc-pin-label':'ADC引脚',
'adc-attenuation-label':'衰减系数',
'adc-resolution-label':'分辨率(位)',
'adc-atten-0db':'0dB (0-1.1V)',
'adc-atten-2.5db':'2.5dB (0-1.5V)',
'adc-atten-6db':'6dB (0-2.2V)',
'adc-atten-11db':'11dB (0-3.3V)',
'dac-channel-label':'DAC通道',
'dac-channel-1':'通道1 (GPIO25)',
'dac-channel-2':'通道2 (GPIO26)',
'debug-tck-pin-label':'TCK/SWCLK引脚',
'debug-tms-pin-label':'TMS/SWDIO引脚',
'debug-tdi-pin-label':'TDI引脚',
'debug-tdo-pin-label':'TDO引脚',
'debug-trst-pin-label':'TRST引脚(可选)',
'special-width-label':'数据宽度(位)',
'special-cs-pin-label':'片选引脚',
'special-dc-pin-label':'数据/命令引脚',
'special-rst-pin-label':'复位引脚',
'special-bl-pin-label':'背光引脚(可选)',
'peripheral-empty':'暂无外设配置',
'peripheral-loading':'加载中...',
'peripheral-load-fail':'加载失败',
'peripheral-loading-html':'<tr><td colspan="6" class="u-empty-cell">加载中...</td></tr>',
'peripheral-fail-html':'<tr><td colspan="6" class="u-empty-cell u-text-danger">加载失败</td></tr>',
'peripheral-empty-html':'<tr><td colspan="6" class="u-empty-cell">暂无外设配置</td></tr>',
'peripheral-validate-required':'请填写外设ID和名称',
'peripheral-validate-id-len':'外设ID长度应在2-32位之间',
'peripheral-saving-text':'保存中...',
'peripheral-add-ok':'外设添加成功',
'peripheral-update-ok':'外设更新成功',
'peripheral-save-fail':'保存失败，请检查连接',
'peripheral-deleted-prefix':' 已删除',
'peripheral-delete-fail':'删除失败，请检查连接',
'peripheral-enabled-msg':'外设已启用',
'peripheral-disabled-msg':'外设已禁用',
'peripheral-toggle-fail':'状态切换失败',
'peripheral-config-title':'外设配置',
'peripheral-confirm-delete':'确定要删除外设 ',
'peripheral-confirm-suffix':' 吗？',
'peripheral-confirm-enable':'确定要启用此外设吗？',
'peripheral-confirm-disable':'确定要禁用此外设吗？',
'peripheral-pin-conflict':'引脚冲突警告',
'peripheral-pin-conflict-msg':'以下引脚已被其他外设使用：',
'periph-exec-title':'外设执行',
'periph-exec-add-modal-title':'新增外设执行',
'periph-exec-edit-modal-title':'编辑外设执行',
'periph-exec-col-name':'名称',
'periph-exec-col-trigger':'触发方式',
'periph-exec-col-action':'动作',
'periph-exec-col-ops':'操作',
'periph-exec-name-label':'规则名称',
'periph-exec-name-hint':'例如: 温度过高报警',
'periph-exec-enabled-label':'启用',
'periph-exec-trigger-type-label':'触发类型',
'periph-exec-trigger-platform':'平台触发 (MQTT)',
'periph-exec-trigger-device':'设备触发',
'periph-exec-trigger-timer':'定时触发',
'periph-exec-trigger-system':'系统事件触发',
'periph-exec-trigger-button':'按键事件触发',
'periph-exec-trigger-receive':'数据接收触发',
'periph-exec-trigger-report':'数据上报触发',
'periph-exec-trigger-event':'事件触发',
'periph-exec-trigger-poll':'轮询触发 (本地数据)',
'periph-exec-poll-operator-label':'条件运算符',
'periph-exec-poll-compare-label':'条件值',
'periph-exec-poll-compare-hint':'如: 30 或 20,40 (区间用逗号分隔)',
'periph-exec-poll-interval-label':'轮询间隔 (秒)',
'periph-exec-poll-timeout-label':'响应超时 (ms)',
'periph-exec-poll-retries-label':'最大重试次数',
'periph-exec-poll-delay-label':'请求间隔 (ms)',
'periph-exec-risk-title':'当前组合会放大轮询和总线负载',
'periph-exec-risk-body':'轮询触发搭配 Modbus 采集动作时，规则执行、串口总线和 Web 服务会同时承压，频率过高时容易出现响应变慢。',
'periph-exec-risk-guard':'服务端已启用节流、自触发保护和参数钳制；建议轮询间隔保持在 5 秒及以上，超时不超过 3000ms，重试不超过 2 次，请求间隔不少于 100ms。',
'periph-exec-action-modbus-poll':'Modbus子设备',
'periph-exec-poll-tasks-label':'选择子设备',
'periph-exec-poll-tasks-help':'选择要执行的 Modbus 子设备',
'periph-exec-select-device':'选择子设备',
'periph-exec-select-channel':'选择通道',
'periph-exec-select-action':'子设备动作',
'periph-exec-match-channel':'匹配通道',
'periph-exec-match-action':'匹配动作',
'modbus-all-devices-title':'Modbus 子设备',
'modbus-no-devices':'暂无子设备',
'modbus-add-device':'+ 添加设备',
'modbus-add-sensor':'采集设备',
'modbus-add-control':'控制设备',
'modbus-task-type':'类型',
'modbus-task-type-holding':'保持寄存器',
'modbus-task-type-input':'输入寄存器',
'modbus-task-type-coil':'线圈状态',
'modbus-task-type-discrete':'离散输入',
'modbus-dev-name':'名称',
'modbus-dev-type':'类型',
'modbus-dev-addr':'从站地址',
'modbus-dev-info':'设备信息',
'modbus-dev-enabled':'启用',
'modbus-dev-actions':'操作',
'modbus-dev-mappings-suffix':'映射',
'modbus-type-sensor':'采集',
'modbus-type-relay':'继电器',
'modbus-type-pwm':'PWM',
'modbus-type-pid':'PID',
'modbus-type-motor':'电机',
'modbus-type-control':'控制设备',
'periph-exec-ctrl-on':'打开',
'periph-exec-ctrl-off':'关闭',
'periph-exec-ctrl-relay':'继电器',
'periph-exec-ctrl-pwm':'调速',
'periph-exec-ctrl-pid-label':'PID设置',
'periph-exec-ctrl-channel':'通道',
'periph-exec-ctrl-duty':'占空比',
'periph-exec-ctrl-value':'值',
'periph-exec-ctrl-pid-param':'参数',
'periph-exec-ctrl-forward':'正转',
'periph-exec-ctrl-reverse':'反转',
'periph-exec-ctrl-stop':'停止',
'periph-exec-op-eq':'等于 (=)',
'periph-exec-op-neq':'不等于 (!=)',
'periph-exec-op-gt':'大于 (>)',
'periph-exec-op-lt':'小于 (<)',
'periph-exec-op-gte':'大于等于 (>=)',
'periph-exec-op-lte':'小于等于 (<=)',
'periph-exec-op-between':'区间内 (a,b)',
'periph-exec-op-not-between':'区间外',
'periph-exec-op-contain':'包含',
'periph-exec-op-not-contain':'不包含',
'periph-exec-event-category-label':'事件分类',
'periph-exec-select-category':'-- 选择分类 --',
'periph-exec-event-label':'触发事件',
'periph-exec-select-event':'-- 选择事件 --',
'periph-exec-event-help':'当此事件发生时触发规则执行',
'periph-exec-source-periph-label':'触发源外设',
'periph-exec-select-source-periph':'-- 选择输入外设 --',
'periph-exec-source-periph-help':'监听此输入外设的状态变化',
'periph-exec-button-periph-label':'按键外设',
'periph-exec-select-button-periph':'-- 选择按键外设 --',
'periph-exec-button-periph-help':'仅支持上拉/下拉输入类型的外设',
'periph-exec-button-event-label':'按键事件',
'periph-exec-select-button-event':'-- 选择按键事件 --',
'periph-exec-button-event-help':'当此按键事件发生时触发规则执行',
'periph-exec-operator-label':'处理方式',
'periph-exec-compare-label':'匹配值',
'periph-exec-compare-hint':'如: 1 或 ON',
'periph-exec-handle-match':'匹配',
'periph-exec-handle-set':'设置',
'periph-exec-timer-mode-label':'定时模式',
'periph-exec-timer-interval':'间隔触发',
'periph-exec-timer-daily':'每日时间点',
'periph-exec-interval-label':'间隔 (秒)',
'periph-exec-timepoint-label':'执行时间 (HH:MM)',
'periph-exec-action-type-label':'执行动作',
'periph-exec-exec-mode-label':'执行模式',
'periph-exec-exec-mode-async':'异步执行',
'periph-exec-exec-mode-sync':'同步执行',
'periph-exec-exec-mode-help':'异步: 独立任务不阻塞, 同步: 阻塞主循环',
'periph-exec-action-cat-gpio':'GPIO操作',
'periph-exec-action-cat-analog':'模拟输出',
'periph-exec-action-cat-system':'系统功能',
'periph-exec-action-high':'设置高电平',
'periph-exec-action-low':'设置低电平',
'periph-exec-action-blink':'闪烁',
'periph-exec-action-breathe':'呼吸灯',
'periph-exec-action-high-inverted':'高电平反转',
'periph-exec-action-low-inverted':'低电平反转',
'periph-exec-action-pwm':'设置PWM',
'periph-exec-action-dac':'设置DAC',
'periph-exec-action-restart':'系统重启',
'periph-exec-action-factory':'恢复出厂',
'periph-exec-action-ntp':'NTP同步',
'periph-exec-action-ota':'OTA升级',
'periph-exec-action-ap':'AP配网',
'periph-exec-action-ble':'BLE配网',
'periph-exec-action-call-periph':'调用外设',
'periph-exec-action-cat-advanced':'高级功能',
'periph-exec-action-sensor-read':'传感器数据读取',
'periph-exec-sensor-category':'传感器类别',
'periph-exec-sensor-cat-analog':'模拟量 (ADC)',
'periph-exec-sensor-cat-digital':'数字量 (DI)',
'periph-exec-sensor-cat-pulse':'脉冲/频率',
'periph-exec-sensor-scale':'缩放系数',
'periph-exec-sensor-offset':'偏移量',
'periph-exec-sensor-decimals':'小数位数',
'periph-exec-sensor-label':'数据标签',
'periph-exec-sensor-unit':'单位',
'periph-exec-sensor-no-periph':'请选择传感器外设',
'periph-exec-action-script':'命令脚本',
'periph-exec-script-label':'脚本内容',
'periph-exec-script-placeholder':'每行一条命令，如:\nGPIO 2 HIGH\nDELAY 500\nGPIO 2 LOW\nLOG 执行完成',
'periph-exec-script-help':'可用: GPIO pin HIGH/LOW, DELAY ms, PWM pin duty, DAC pin val, LOG msg, PERIPH id 动作',
'periph-exec-script-empty':'脚本内容不能为空',
'periph-exec-script-too-long':'脚本超过最大长度限制(1024字节)',
'periph-exec-script-lines':'行',
'periph-exec-report-label':'是否上报数据',
'periph-exec-report-help':'动作执行成功后自动上报设备数据',
'periph-exec-report-yes':'上报数据',
'periph-exec-report-no':'不上报数据',
'periph-exec-target-periph-label':'执行外设',
'periph-exec-trigger-periph-label':'触发外设',
'periph-exec-datasource-group':'数据源',
'periph-exec-periph-group':'硬件外设',
'periph-exec-modbus-group':'Modbus 子设备',
'periph-exec-select-periph':'-- 选择外设 --',
'periph-exec-section-trigger':'触发配置',
'periph-exec-section-action':'执行动作配置',
'periph-exec-add-trigger':'添加触发',
'periph-exec-add-action':'添加动作',
'periph-exec-action-value-label':'动作参数',
'periph-exec-action-value-hint':'如: PWM值、闪烁间隔ms',
'periph-exec-action-value-help':'闪烁/呼吸灯填间隔ms, PWM填占空比, DAC填0-255',
'periph-exec-use-received-value':'使用接收值',
'periph-exec-use-received-label':'使用接收值',
'periph-exec-use-received-value-help':'勾选后动作参数将使用平台下发或触发源的值',
'periph-exec-sync-delay-label':'执行前延时(0-10000ms)',
'periph-exec-sync-delay-help':'此动作执行前等待的毫秒数(0-10000)',
'periph-exec-validate-name':'请输入规则名称',
'periph-exec-add-ok':'规则添加成功',
'periph-exec-update-ok':'规则更新成功',
'periph-exec-save-fail':'保存失败',
'periph-exec-delete-ok':'规则已删除',
'periph-exec-delete-fail':'删除失败',
'periph-exec-confirm-delete':'确定要删除此规则吗？',
'periph-exec-enable':'启用',
'periph-exec-disable':'禁用',
'periph-exec-toggle-fail':'状态切换失败',
'periph-exec-every':'每隔',
'periph-exec-daily':'每日',
'periph-exec-rules-title':'外设执行',
'periph-exec-save-first':'请先保存外设后再添加外设执行',
'periph-exec-no-rules':'该外设暂无关联的外设执行',
'periph-exec-add-btn':'新增规则',
'periph-exec-page-title':'外设执行管理',
'periph-exec-filter-all':'全部规则',
'periph-exec-no-data':'暂无外设执行',
'periph-exec-loading':'加载中...',
'periph-exec-col-status':'状态',
'periph-exec-col-target':'执行外设',
'periph-exec-col-stats':'统计',
'periph-exec-status-on':'已启用',
'periph-exec-status-off':'已禁用',
'periph-exec-stats-count':'触发次数',
'periph-exec-total':'共',
'periph-exec-run-once':'执行一次',
'periph-exec-run-ok':'规则执行成功',
'periph-exec-run-submitted':'执行已提交',
'periph-exec-run-fail':'规则执行失败',
'periph-exec-set-value-title':'输入执行值',
'periph-exec-set-value-label':'执行值',
'periph-exec-set-value-help':'请输入本次执行要设置的值，例如 PWM 占空比、PID 参数或通道值。',
'periph-exec-set-value-placeholder':'例如: 80、25.5、1,0,0.5',
'periph-exec-set-value-prompt':'请输入要设置的值 (如: PWM占空比、PID参数等):',
'periph-exec-set-value-required':'请输入要设置的值',
'event-wifi_connected':'WiFi连接成功',
'event-wifi_disconnected':'WiFi断开连接',
'event-wifi_conn_failed':'WiFi连接失败',
'event-mqtt_connected':'MQTT连接成功',
'event-mqtt_disconnected':'MQTT断开连接',
'event-mqtt_conn_failed':'MQTT连接失败',
'event-mqtt_enabled':'MQTT协议启用',
'event-net_mode_ap':'网络模式切换为AP',
'event-net_mode_sta':'网络模式切换为STA',
'event-modbus_rtu_enabled':'Modbus RTU启用',
'event-modbus_tcp_enabled':'Modbus TCP启用',
'event-tcp_enabled':'TCP协议启用',
'event-http_enabled':'HTTP协议启用',
'event-coap_enabled':'CoAP协议启用',
'event-ntp_synced':'NTP时间同步完成',
'event-ota_start':'OTA升级开始',
'event-ota_success':'OTA升级成功',
'event-ota_failed':'OTA升级失败',
'event-rule_exec_time':'规则脚本执行时间',
'event-rule_exec_error':'规则脚本执行错误',
'event-system_boot':'系统启动',
'event-system_ready':'系统就绪',
'event-system_error':'系统错误',
'event-factory_reset':'恢复出厂设置',
'event-button_click':'按键单击',
'event-button_double_click':'按键双击',
'event-button_long_press_2s':'按键长按2秒',
'event-button_long_press_5s':'按键长按5秒',
'event-button_long_press_10s':'按键长按 10 秒',
'event-button_press':'按键按下',
'event-button_release':'按键释放',
'event-periph_exec_completed':'外设执行完成',
'event-data_receive':'数据接收',
'event-data_report':'数据上报',
'event-cat-WiFi':'WiFi',
'event-cat-MQTT':'MQTT',
'event-cat-网络':'网络',
'event-cat-协议':'协议',
'event-cat-系统':'系统',
'event-cat-规则':'规则',
'event-cat-Modbus子设备':'Modbus子设备',
'event-cat-modbus-acquisition':'采集设备',
'event-cat-modbus-control':'控制设备',
'event-cat-按键':'按键',
'event-cat-外设执行':'外设执行',
'event-cat-数据':'数据',
'event-cat-数据源':'数据源',
'periph-exec-event-operator-label':'比较操作符',
'periph-exec-event-compare-label':'比较值',
'periph-exec-event-compare-hint':'如: 25.5 或 ON',
'page-title-rule-script':'规则脚本',
'rule-script-title':'规则脚本',
'rule-script-page-title':'规则脚本',
'rule-script-add-btn':'新增规则',
'rule-script-add-title':'新增规则脚本',
'rule-script-edit-title':'编辑规则脚本',
'rule-script-no-data':'暂无规则脚本',
'rule-script-loading':'加载中...',
'rule-script-col-name':'名称',
'rule-script-col-status':'状态',
'rule-script-col-trigger':'触发方式',
'rule-script-col-protocol':'协议类型',
'rule-script-col-stats':'统计',
'rule-script-col-ops':'操作',
'rule-script-name-label':'规则名称',
'rule-script-enabled-label':'启用',
'rule-script-trigger-type-label':'触发类型',
'rule-script-trigger-receive':'数据接收',
'rule-script-trigger-report':'数据上报',
'rule-script-protocol-type-label':'协议类型',
'rule-script-protocol-mqtt':'MQTT',
'rule-script-protocol-modbus-rtu':'Modbus RTU',
'rule-script-protocol-modbus-tcp':'Modbus TCP',
'rule-script-protocol-http':'HTTP',
'rule-script-protocol-coap':'CoAP',
'rule-script-protocol-tcp':'TCP',
'rule-script-content-label':'脚本内容',
'rule-script-content-help':'使用 ${key} 引用输入数据中的值，例如 ${temperature}',
'rule-script-add-ok':'规则脚本添加成功',
'rule-script-update-ok':'规则脚本更新成功',
'rule-script-delete-ok':'规则脚本已删除',
'rule-script-save-fail':'保存失败',
'logout-success':'已成功退出登录',
'logout-title':'退出登录',
'protocol-config-title':'通信协议',
'protocol-save-ok-suffix':'配置保存成功！',
'protocol-save-fail':'保存失败',
'protocol-export-btn':'导出配置',
'protocol-import-btn':'导入配置',
'protocol-export-ok':'协议配置导出成功',
'protocol-export-fail':'导出配置失败',
'protocol-import-ok':'协议配置导入成功',
'protocol-import-fail':'导入配置失败',
'protocol-import-invalid':'无效的JSON配置文件',
'protocol-import-confirm':'确定要导入此配置吗？当前配置将被覆盖。',
'protocol-enable-label':'启用此协议',
'mqtt-will-section-title':'遗嘱消息 (Last Will)',
'mqtt-will-topic-label':'遗嘱主题',
'mqtt-will-topic-hint':'设备异常断线时Broker发布的主题',
'mqtt-will-payload-label':'遗嘱内容',
'mqtt-will-qos-label':'遗嘱QoS',
'mqtt-will-retain-label':'遗嘱保留',
'mqtt-card-section-title':'高级配置',
'mqtt-longitude-label':'经度',
'mqtt-latitude-label':'纬度',
'mqtt-iccid-label':'ICCID',
'mqtt-card-platform-id-label':'卡平台编号',
'mqtt-summary-label':'摘要 (JSON)',
'mqtt-test-btn-text':'测试连接',
'mqtt-test-testing':'测试中...',
'mqtt-test-success':'连接成功！',
'mqtt-test-ok-real-fail':'凭证验证通过，但实际连接失败，请先点击保存配置后再测试',
'mqtt-test-fail-prefix':'连接失败: ',
'mqtt-test-error':'测试请求失败',
'mqtt-test-timeout':'测试超时，请检查Broker地址是否正确',
'mqtt-test-unauthorized':'会话已过期，请刷新页面后重试',
'mqtt-test-deferred':'MQTT 正在异步连接中，请关注状态变化...',
'mqtt-test-deferred-timeout':'异步连接超时，请检查配置或查看日志',
'mqtt-test-no-server':'请先填写Broker地址',
'mqtt-test-clientid-simple-prefix':"提示: FastBee平台简单认证模式下，客户端ID通常以'S&'开头（格式: S&设备编号&产品ID&用户ID）",
'mqtt-test-clientid-encrypted-prefix':"提示: FastBee平台加密认证模式下，客户端ID通常以'E&'开头（格式: E&设备编号&产品ID&用户ID）",
'mqtt-status-label':'连接状态',
'mqtt-status-server-label':'服务器',
'mqtt-status-client-label':'客户端ID',
'mqtt-status-reconnect-label':'重连次数',
'mqtt-status-connected':'已连接',
'mqtt-status-disconnected':'未连接',
'mqtt-status-uninit':'未初始化',
'mqtt-status-offline':'未连接',
'mqtt-reconnect-ok':'MQTT已重新连接',
'mqtt-reconnect-fail':'MQTT重连失败',
'mqtt-disconnect-btn':'断开连接',
'mqtt-disconnecting':'断开中...',
'mqtt-disconnect-ok':'MQTT已断开连接',
'mqtt-disconnect-fail':'MQTT断开失败',
'mqtt-ntp-sync-btn':'MQTT时间同步',
'mqtt-ntp-syncing':'同步中...',
'mqtt-ntp-sync-ok':'MQTT时间同步请求已发送',
'mqtt-ntp-sync-fail':'MQTT时间同步失败',
'mqtt-topic-type-label':'主题类型',
'mqtt-topic-type-data-report':'数据上报',
'mqtt-topic-type-data-command':'数据下发',
'mqtt-topic-type-device-info':'设备信息',
'mqtt-topic-type-realtime-mon':'实时监测',
'mqtt-topic-type-device-event':'设备事件',
'mqtt-topic-type-ota-upgrade':'OTA升级',
'mqtt-topic-type-ota-binary':'OTA二进制',
'mqtt-topic-type-ntp-sync':'NTP时间同步',
'mqtt-auto-prefix-label':'自动前缀',
'mqtt-topic-prefix-label':'主题前缀',
'mqtt-topic-enabled-label':'启用',
'mqtt-auth-type-label':'认证方式',
'mqtt-auth-simple':'简单认证',
'mqtt-auth-encrypted':'加密认证',
'mqtt-auth-code-label':'授权码',
'mqtt-device-num-label':'设备编号',
'mqtt-product-id-label':'产品ID',
'mqtt-user-id-label':'用户ID',
'mqtt-secret-label':'产品秘钥',
'mqtt-ntp-server-label':'NTP服务器',
'rtu-pins-section-title':'RS485 引脚配置',
'rtu-tx-pin-label':'TX引脚',
'rtu-rx-pin-label':'RX引脚',
'rtu-de-pin-label':'DE引脚',
'rtu-de-pin-hint':'RS485方向控制引脚，-1表示禁用DE引脚（自动收发模块无需配置）',
'rtu-slave-addr-label':'从站地址',
'rtu-peripheral-label':'外设配置选择',
'rtu-peripheral-hint':'关联已配置的外设，Modbus通信将使用该外设的串口参数（引脚、波特率等）',
'rtu-peripheral-placeholder':'-- 请选择UART外设 --',
'rtu-no-uart-peripherals':'未找到已启用的UART外设，请先在外设管理中配置',
'peripheral-uart-pin-hint':'引脚顺序: 引脚1=RX(接收/输入), 引脚2=TX(发送/输出)',
'http-auth-section-title':'HTTP 认证',
'http-auth-type-label':'认证类型',
'http-auth-type-none':'无认证',
'http-auth-type-basic':'Basic认证',
'http-auth-type-bearer':'Bearer Token',
'http-auth-user-label':'认证用户名',
'http-auth-token-label':'认证Token/密码',
'http-content-type-label':'Content-Type',
'coap-msg-type-label':'消息类型',
'coap-msg-type-con':'CON (需确认)',
'coap-msg-type-non':'NON (无需确认)',
'coap-retransmit-label':'重传次数',
'coap-timeout-label':'超时时间(ms)',
'tcp-mode-label':'工作模式',
'tcp-mode-client':'客户端 (Client)',
'tcp-mode-server':'服务端 (Server)',
'tcp-local-port-label':'本地端口',
'tcp-max-clients-label':'最大客户端数',
'tcp-heartbeat-msg-label':'心跳消息',
'tcp-idle-timeout-label':'空闲超时(秒)',
'mqtt-enabled-label':'启用MQTT',
'modbus-rtu-enabled-label':'启用Modbus RTU',
'modbus-tcp-enabled-label':'启用Modbus TCP',
'http-enabled-label':'启用HTTP',
'coap-enabled-label':'启用CoAP',
'tcp-enabled-label':'启用TCP',
'mqtt-test-conn-btn':'测试连接',
'http-auth-none':'无认证',
'http-auth-basic':'Basic认证',
'http-auth-bearer':'Bearer Token',
'modbus-mode-label':'工作模式',
'modbus-mode-slave':'从站模式 (Slave)',
'modbus-mode-master':'主站模式 (Master)',
'modbus-master-title':'Modbus 采集',
'modbus-master-poll-interval':'默认轮询间隔(秒)',
'modbus-master-response-timeout':'响应超时(ms)',
'modbus-master-max-retries':'最大重试次数',
'modbus-master-inter-poll-delay':'轮询间隔延迟(ms)',
'modbus-master-tasks-title':'轮询任务列表',
'modbus-master-add-task':'添加任务',
'modbus-master-slave-addr':'从站地址',
'modbus-master-fc':'功能码',
'modbus-master-start-addr':'起始地址',
'modbus-master-quantity':'寄存器数量',
'modbus-master-interval':'轮询间隔(秒)',
'modbus-master-label':'名称',
'modbus-master-enabled':'启用',
'modbus-master-actions':'操作',
'modbus-master-delete-task':'删除',
'modbus-task-edit-btn':'编辑',
'modbus-task-edit-title':'编辑子设备',
'modbus-task-add-title':'新建子设备',
'modbus-master-no-tasks':'暂无轮询任务',
'modbus-master-mappings':'映射',
'rtu-transfer-type-label':'传输类型',
'rtu-transfer-type-json':'JSON (结构化数据)',
'rtu-transfer-type-raw':'透传 (原始HEX帧)',
'rtu-transfer-type-hint':'JSON模式需配置寄存器映射，透传模式直接上报原始帧',
'modbus-mapping-title':'寄存器映射配置',
'modbus-mapping-offset':'寄存器偏移',
'modbus-mapping-datatype':'数据类型',
'modbus-mapping-scale':'缩放因子',
'modbus-mapping-decimals':'小数位',
'modbus-mapping-sensor-id':'传感器ID',
'modbus-mapping-unit':'单位',
'modbus-mapping-add':'添加映射',
'modbus-mapping-save':'确定',
'modbus-mapping-cancel':'取消',
'modbus-mapping-max':'每任务最多8个映射',
'modbus-mapping-btn':'映射',
'modbus-master-status-title':'主站运行状态',
'modbus-master-running-status-label':'运行状态',
'modbus-master-status-stopped':'已停止',
'modbus-master-status-unavailable':'无法获取状态',
'modbus-master-status-fetch-error':'获取失败，请检查连接',
'modbus-master-total-polls':'总轮询次数',
'modbus-master-success-polls':'成功次数',
'modbus-master-failed-polls':'失败次数',
'modbus-master-timeout-polls':'超时次数',
'modbus-master-risk-level':'风险等级',
'modbus-master-enabled-tasks':'启用任务',
'modbus-master-min-interval':'最小间隔',
'modbus-master-last-poll-age':'最近轮询',
'modbus-master-timeout-rate':'超时率',
'modbus-master-risk-low':'低',
'modbus-master-risk-medium':'中',
'modbus-master-risk-high':'高',
'modbus-master-task-ok':'正常',
'modbus-master-task-stale':'滞后',
'modbus-master-task-error':'异常',
'modbus-master-task-pending':'等待',
'modbus-master-task-disabled':'关闭',
'modbus-master-write-title':'手动写入寄存器',
'modbus-master-write-slave':'从站地址',
'modbus-master-write-reg':'寄存器地址',
'modbus-master-write-value':'写入值',
'modbus-master-write-btn':'写入',
'modbus-master-write-ok':'写入请求已排队',
'modbus-master-write-fail':'写入失败',
'modbus-master-fc1':'FC01 读线圈',
'modbus-master-fc2':'FC02 读离散输入',
'modbus-master-fc3':'FC03 读保持寄存器',
'modbus-master-fc4':'FC04 读输入寄存器',
'modbus-control-title':'Modbus 控制',
'modbus-ctrl-slave-addr':'从站地址',
'modbus-ctrl-channel-count':'通道数',
'modbus-ctrl-coil-base':'线圈基地址',
'modbus-ctrl-coil-base-hint':'线圈起始地址，默认0',
'modbus-ctrl-relay-mode':'控制协议',
'modbus-ctrl-relay-mode-coil':'线圈模式 (FC01/FC05)',
'modbus-ctrl-relay-mode-register':'寄存器模式 (FC03/FC06)',
'modbus-ctrl-relay-mode-hint':'线圈模式适用于标准继电器板，寄存器模式适用于M88等工控模块',
'modbus-ctrl-reg-base-hint':'寄存器起始地址，如M88继电器从0x0008开始',
'modbus-ctrl-auto-refresh':'自动刷新',
'modbus-ctrl-nc-mode':'NC常闭模式',
'modbus-ctrl-all-on':'全部开启',
'modbus-ctrl-all-off':'全部关闭',
'modbus-ctrl-all-toggle':'翻转',
'modbus-ctrl-refresh':'刷新状态',
'modbus-ctrl-status-on':'开',
'modbus-ctrl-status-off':'关',
'modbus-ctrl-delay-title':'延时断开',
'modbus-ctrl-delay-sec':'延时(秒)',
'modbus-ctrl-delay-start':'启动延时',
'modbus-ctrl-device-params':'设备参数配置',
'modbus-ctrl-device-name':'设备名称',
'modbus-ctrl-device-add':'添加设备',
'modbus-ctrl-device-save':'保存设备',
'modbus-ctrl-device-delete':'删除',
'modbus-ctrl-device-delete-confirm':'确定要删除该设备配置吗？',
'modbus-ctrl-device-saved':'设备配置已保存',
'modbus-ctrl-device-deleted':'设备已删除',
'modbus-ctrl-device-default-name':'设备',
'modbus-ctrl-success':'操作成功',
'modbus-ctrl-fail':'操作失败',
'modbus-ctrl-delay-ok':'延时断开指令已发送',
'modbus-ctrl-delay-unit':'x100ms',
'modbus-ctrl-delay-hint':'先打开继电器，延时后自动关闭 (1=100ms, 255=25.5s)',
'modbus-delay-title':'延时断开',
'modbus-delay-channel':'通道',
'modbus-delay-units':'延时值 (x100ms)',
'modbus-delay-start':'启动',
'modbus-delay-success':'延时已启动',
'modbus-delay-fail':'延时启动失败',
'modbus-debug-title':'调试日志',
'modbus-debug-clear':'清除',
'modbus-ctrl-channel':'通道',
'modbus-ctrl-type-label':'设备类型',
'modbus-ctrl-type-relay':'继电器',
'modbus-ctrl-type-pwm':'PWM 驱动',
'modbus-ctrl-default-preset-name':'继电器板',
'modbus-devices-title':'子设备列表',
'modbus-device-add':'添加设备',
'modbus-device-no-devices':'暂无子设备，点击"添加设备"创建',
'modbus-device-col-name':'名称',
'modbus-device-col-type':'类型',
'modbus-device-col-addr':'从站地址',
'modbus-device-col-ch':'通道',
'modbus-device-col-base':'基地址',
'modbus-device-col-protocol':'控制协议',
'modbus-device-col-nc':'NC模式',
'modbus-device-nc-closed':'NC常闭模式',
'modbus-device-nc-open':'NC常开模式',
'modbus-device-enabled-label':'启用',
'modbus-ctrl-protocol-coil':'线圈模式',
'modbus-ctrl-protocol-register':'寄存器模式',
'modbus-relay-batch-reg':'批量寄存器地址',
'modbus-relay-batch-reg-hint':'0=不使用，由前端逐通道控制',
'modbus-relay-batch-type':'批量寄存器类型',
'modbus-relay-batch-type-bitmap':'位图模式 - 每bit对应一路状态',
'modbus-relay-batch-type-command':'命令模式 - 只接收开/关指令',
'modbus-relay-batch-type-hint':'位图: 每bit=通道; 命令: 0=全关, 1=全开',
'modbus-device-select-btn':'控制',
'modbus-device-delete-confirm':'确定要删除此设备？',
'modbus-device-max-reached':'最多支持8个子设备',
'modbus-device-edit-btn':'编辑',
'modbus-device-edit-title':'编辑子设备',
'modbus-device-sensor-id':'子设备标识',
'modbus-device-sensor-id-hint':'MQTT上报标识，多通道自动生成 _chN 后缀',
'modbus-device-ctrl-title':'设备控制',
'modbus-device-nc-enabled':'启用',
'modbus-ctrl-pwm-reg-base':'寄存器基地址',
'modbus-ctrl-pwm-reg-base-hint':'PWM保持寄存器起始地址',
'modbus-ctrl-pwm-resolution':'分辨率',
'modbus-ctrl-pwm-set-all-max':'全部最大',
'modbus-ctrl-pwm-set-all-off':'全部关闭',
'modbus-ctrl-pwm-refresh':'刷新状态',
'modbus-ctrl-type-pid':'PID 控制器',
'modbus-ctrl-pid-pv-addr':'PV寄存器地址',
'modbus-ctrl-pid-sv-addr':'SV寄存器地址',
'modbus-ctrl-pid-out-addr':'输出寄存器地址',
'modbus-ctrl-pid-p-addr':'P参数地址',
'modbus-ctrl-pid-i-addr':'I参数地址',
'modbus-ctrl-pid-d-addr':'D参数地址',
'modbus-ctrl-pid-decimals':'小数位数',
'modbus-ctrl-pid-pv-label':'过程值 PV',
'modbus-ctrl-pid-sv-label':'设定值 SV',
'modbus-ctrl-pid-out-label':'输出 %',
'modbus-ctrl-pid-p-label':'P 比例',
'modbus-ctrl-pid-i-label':'I 积分',
'modbus-ctrl-pid-d-label':'D 微分',
'modbus-ctrl-pid-set':'设置',
'modbus-ctrl-pid-refresh':'刷新数据',
'modbus-ctrl-pid-auto-refresh':'自动刷新',
'net-status-title':'当前网络状态',
'net-status-refresh':'刷新',
'net-sta-info':'STA 连接信息',
'net-ap-info':'AP 热点信息',
'net-stats':'连接统计',
'net-sta-status-label':'状态',
'refresh-btn':'刷新',
'mqtt-direct-connect-text':'是否直连',
'mqtt-auto-reconnect-text':'自动重连',
'mqtt-subscribe-section-title':'订阅主题配置',
'mqtt-subscribe-topic-label':'订阅主题',
'mqtt-subscribe-topictype-label':'主题类型',
'mqtt-subscribe-qos-label':'订阅QoS',
'mqtt-add-subscribe-btn':'增加订阅',
'mqtt-save-success':'MQTT配置保存成功！',
'btn-save-config':'保存配置',
'http-url-label':'服务地址',
'http-method-label':'请求方法',
'http-timeout-label':'超时时间(秒)',
'http-port-label':'端口',
'http-interval-label':'上报间隔(秒)',
'http-retry-label':'重试次数',
'coap-server-label':'服务器地址',
'coap-method-label':'方法',
'coap-port-label':'端口',
'coap-path-label':'路径',
'tcp-server-label':'服务器地址',
'tcp-client-port-label':'端口',
'tcp-client-timeout-label':'连接超时(ms)',
'tcp-keepalive-label':'保活间隔(秒)',
'tcp-reconnect-label':'重连间隔(秒)',
'tcp-retry-label':'最大重试次数',
'rtu-parity-none':'无',
'rtu-parity-even':'偶校验',
'rtu-parity-odd':'奇校验',
'wifi-dhcp-auto':'DHCP (自动获取)',
'wifi-dhcp-static':'静态IP (手动配置)',
'conflict-detect-none':'不检测',
'conflict-detect-ping':'Ping检测',
'conflict-detect-arp':'ARP检测',
'conflict-detect-auto':'自动检测',
'tz-china':'中国标准时间 (UTC+8)',
'tz-utc':'UTC (UTC+0)',
'tz-japan':'日本标准时间 (UTC+9)',
'tz-us-east':'美国东部时间 (UTC-5)',
'tz-us-west':'美国西部时间 (UTC-8)',
'tz-europe':'中欧时间 (UTC+1)',
'role-admin':'管理员',
'role-operator':'操作员',
'role-viewer':'查看者',
'dev-ble-guide-title':'蓝牙配网说明',
'dev-ble-guide-1':'点击"启动蓝牙配网"按钮，设备将开始蓝牙广播',
'dev-ble-guide-2':'使用手机APP搜索并连接到蓝牙设备',
'dev-ble-guide-3':'在APP中输入要连接的WiFi名称和密码',
'dev-ble-guide-4':'设备收到配置后自动连接WiFi，配网成功后蓝牙连接断开',
'dev-ble-guide-tip':'提示：蓝牙配网适用于无法使用AP配网的场景，需要配合支持蓝牙的手机APP使用。',
'dev-ble-not-started':'未启动',
'dev-ota-notice-title':'升级注意事项',
'dev-ota-notice-1':'升级过程中请勿断开电源或关闭浏览器',
'dev-ota-notice-2':'确保固件版本与当前硬件兼容',
'dev-ota-notice-3':'升级成功后设备将自动重启',
'dev-ota-notice-4':'建议在升级前备份重要配置',
'peripheral-enabled-yes':'是',
'peripheral-enabled-no':'否',
'peripheral-cat-comm':'通信接口',
'peripheral-cat-gpio':'GPIO接口',
'peripheral-cat-analog':'模拟信号',
'peripheral-cat-debug':'调试接口',
'peripheral-cat-special':'专用外设',
'peripheral-pins-label':'引脚配置',
'peripheral-pins-hint':'例如: 2,4,5 (逗号分隔)',
'peripheral-pins-help':'多个引脚用逗号分隔，例如 21,22 (I2C SDA,SCL)',
'gpio-params-title':'GPIO参数',
'uart-params-title':'UART参数',
'uart-parity-param-none':'无',
'uart-parity-param-odd':'奇校验',
'uart-parity-param-even':'偶校验',
'i2c-params-title':'I2C参数',
'i2c-freq-100k':'100kHz (标准模式)',
'i2c-freq-400k':'400kHz (快速模式)',
'i2c-addr-label':'从机地址 (0=主机模式)',
'spi-params-title':'SPI参数',
'adc-params-title':'ADC参数',
'adc-res-label':'分辨率 (位)',
'adc-res-9':'9位 (0-511)',
'adc-res-10':'10位 (0-1023)',
'adc-res-11':'11位 (0-2047)',
'adc-res-12':'12位 (0-4095)',
'adc-att-label':'衰减系数',
'gpio-pwm-res-label':'PWM分辨率 (位)',
'save':'保存',
'periph-opt-digital-in':'数字输入',
'periph-opt-digital-out':'数字输出',
'periph-opt-digital-in-pu':'数字输入(上拉)',
'periph-opt-digital-in-pd':'数字输入(下拉)',
'periph-opt-analog-in':'模拟输入',
'periph-opt-analog-out':'模拟输出',
'periph-opt-pwm':'PWM输出',
'periph-opt-int-rising':'中断(上升沿)',
'periph-opt-int-falling':'中断(下降沿)',
'periph-opt-int-change':'中断(变化)',
'periph-opt-touch':'触摸',
'periph-opt-sensor':'传感器',
'periph-opt-camera':'摄像头',
'periph-opt-ethernet':'以太网',
'periph-opt-motor':'电机',
'periph-opt-encoder':'编码器',
'periph-opt-onewire':'单总线',
'perm-group-device':'设备',
'perm-group-network':'网络',
'perm-group-system':'系统',
'perm-group-user':'用户',
'perm-group-file':'文件',
'perm-group-protocol':'协议',
'perm-group-audit':'审计',
'perm-group-gpio':'GPIO',
'perm-group-peripheral':'外设',
'perm-device.view':'查看设备信息',
'perm-device.config':'修改设备配置',
'perm-device.restart':'重启设备',
'perm-device.control':'控制设备',
'perm-network.view':'查看网络配置',
'perm-network.config':'修改网络配置',
'perm-system.info':'查看系统信息',
'perm-system.restart':'重启系统',
'perm-user.view':'查看用户',
'perm-user.edit':'编辑用户',
'perm-user.admin':'管理用户',
'perm-user.create':'创建用户',
'perm-user.delete':'删除用户',
'perm-role.view':'查看角色',
'perm-role.create':'创建角色',
'perm-role.edit':'编辑角色',
'perm-role.delete':'删除角色',
'perm-config.view':'查看配置',
'perm-config.edit':'编辑配置',
'perm-fs.view':'查看文件',
'perm-fs.manage':'管理文件',
'perm-protocol.view':'查看协议配置',
'perm-protocol.config':'修改协议配置',
'perm-audit.view':'查看审计日志',
'perm-audit.clear':'清除审计日志',
'perm-gpio.view':'查看GPIO',
'perm-gpio.config':'配置GPIO',
'perm-peripheral.view':'查看外设',
'perm-peripheral.config':'配置外设',
'perm-ota.update':'OTA升级',
'modbus-motor-reg-forward':'正转寄存器',
'modbus-motor-reg-reverse':'反转寄存器',
'modbus-motor-reg-stop':'停止寄存器',
'modbus-motor-reg-speed':'速度寄存器',
'modbus-motor-reg-pulse':'脉冲数寄存器',
'modbus-motor-decimals':'小数位',
'modbus-motor-reg-hint':'寄存器地址参考设备说明书，默认值兼容YF-53步进电机控制器',
'modbus-motor-ctrl-speed':'速度',
'modbus-motor-ctrl-pulse':'脉冲数',
'modbus-motor-ctrl-status':'当前状态',
'modbus-motor-speed':'速度',
'modbus-motor-pulse':'脉冲数',
'modbus-motor-dir':'方向',
'modbus-motor-status':'状态',
'modbus-motor-status-run':'运行中',
'modbus-motor-status-stop':'停止',
'modbus-motor-direction':'方向',
'modbus-motor-dir-forward':'正转中',
'modbus-motor-dir-reverse':'反转中',
'modbus-motor-count':'计数',
'modbus-motor-unit-rpm':'转/分钟',
'modbus-motor-unit-pulse':'个',
'modbus-motor-ctrl-forward':'正转',
'modbus-motor-ctrl-reverse':'反转',
'modbus-motor-ctrl-stop':'停止',
'modbus-motor-ctrl-set-speed':'设置速度',
'modbus-motor-ctrl-set-pulse':'设置脉冲',
'modbus-motor-ctrl-forward-ok':'正转指令已发送',
'modbus-motor-ctrl-reverse-ok':'反转指令已发送',
'modbus-motor-ctrl-stop-ok':'停止指令已发送',
'modbus-motor-ctrl-speed-ok':'速度设置成功',
'modbus-motor-ctrl-pulse-ok':'脉冲数设置成功'
};
i18n.addTranslations('zh-CN',zhTranslations);
i18n._zhLoaded=true;
})();
var AppState=typeof AppState!=='undefined'?AppState:{
currentPage:'dashboard',
configTab:'modbus',
currentUser:{name:'',role:'',canManageFs:false},
sidebarCollapsed:false,
_logAutoRefreshTimer:null,
_pageMapping:{
'dashboard-page':'dashboard',
'protocol-page':'protocol',
'network-page':'network',
'device-page':'device',
'data-page':'admin',
'users-page':'admin',
'roles-page':'admin',
'logs-page':'admin',
'peripheral-page':'peripheral',
'periph-exec-page':'peripheral',
'device-control-page':'peripheral',
'rule-script-page':'rule-script'
},
loadPage(pageId){
return PageLoader.loadPage(pageId,this._pageMapping);
},
_loadModals(){
return PageLoader.loadModals();
},
registerModule(name,methods){
ModuleLoader.registerModule(name,methods,this);
},
_loadModule(name,callback){
ModuleLoader.loadModule(name,callback);
},
_handleUrlParams(){
var params=new URLSearchParams(window.location.search);
var targetPage=params.get('page');
var goFullscreen=params.get('fullscreen')==='1';
if(targetPage){
this._pendingUrlPage=targetPage;
this._pendingUrlFullscreen=goFullscreen;
var cleanUrl=window.location.pathname;
window.history.replaceState({},'',cleanUrl);
}
},
_applyUrlParams(){
if(!this._pendingUrlPage)return ;
var page=this._pendingUrlPage;
var goFullscreen=this._pendingUrlFullscreen;
delete this._pendingUrlPage;
delete this._pendingUrlFullscreen;
this.changePage(page);
if(goFullscreen&&page==='device-control'){
setTimeout(function (){
if(typeof AppState._dcToggleFullscreen==='function'){
AppState._dcToggleFullscreen();
}
},1500);
}
},
init(){
this.setupTheme();
this.setupUserDropdown();
this.setupSidebarToggle();
this.setupLanguage();
this.setupConfigTabs();
this.setupEventListeners();
this.setupGlobalEventDelegation();
this._handleUrlParams();
this.refreshPage();
},
setupGlobalEventDelegation(){
const self=this;
document.addEventListener('click',(e)=>{
var tab=e.target.closest('.config-tab');
if(tab){
if(tab.classList.contains('tab-disabled'))return ;
var pageEl=tab.closest('[id$="-page"]');
if(pageEl){
var tabId=tab.getAttribute('data-tab');
self.showConfigTab(pageEl.id,tabId);
}
return ;
}
const el=e.target.closest('[data-action]');
if(!el)return ;
const action=el.dataset.action;
const args=el.dataset.args?el.dataset.args.split(','):[];
if(typeof this[action]==='function'){
e.preventDefault();
this[action](...args);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
e.preventDefault();
window.app[action](...args);
}else{
e.preventDefault();
setTimeout(function (){
if(typeof self[action]==='function'){
self[action](...args);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
window.app[action](...args);
}
},800);
}
});
document.addEventListener('change',(e)=>{
const el=e.target.closest('[data-change-action]');
if(!el)return ;
const action=el.dataset.changeAction;
const value=el.value;
if(typeof this[action]==='function'){
this[action](value);
}else if(typeof window.app!=='undefined'&&typeof window.app[action]==='function'){
window.app[action](value);
}
});
document.addEventListener('submit',(e)=>{
const form=e.target.closest('form');
if(!form)return ;
const protocolForms=['mqtt-form','modbus-rtu-form','modbus-tcp-form','http-form','coap-form','tcp-form'];
if(protocolForms.includes(form.id)){
e.preventDefault();
if(typeof self.saveProtocolConfig==='function'){
self.saveProtocolConfig(form.id);
}
}
});
['input','change'].forEach(function (eventType){
document.addEventListener(eventType,function (e){
const targetId=e.target.id;
if(targetId==='mqtt-client-id'||targetId==='mqtt-auth-type'){
var resultEl=document.getElementById('mqtt-test-result');
if(resultEl)resultEl.textContent='';
}
});
});
},
triggerOtaFileSelect(){
const fileInput=document.getElementById('ota-file');
if(fileInput)fileInput.click();
},
setupLanguage(){
i18n.updatePageText();
const loginLangSelect=document.getElementById('login-language-select');
if(loginLangSelect){
loginLangSelect.value=i18n.currentLang;
loginLangSelect.addEventListener('change',e=>{
i18n.setLanguage(e.target.value);
const mainSelect=document.getElementById('language-select');
if(mainSelect)mainSelect.value=e.target.value;
});
}
const langSelect=document.getElementById('language-select');
if(langSelect){
langSelect.value=i18n.currentLang;
langSelect.addEventListener('change',e=>{
i18n.setLanguage(e.target.value);
if(loginLangSelect)loginLangSelect.value=e.target.value;
this._refreshCurrentPageLocalizedContent();
});
}
},
_getPageModuleMap(){
return {
dashboard:'dashboard',
network:'network',
device:'device-config',
users:'users',
roles:'roles',
peripheral:'peripherals',
'periph-exec':'periph-exec',
protocol:'protocol',
'rule-script':'rule-script',
data:'files',
logs:'logs',
'device-control':'device-control'
};
},
_getPageLoaders(){
return {
dashboard:()=>{this.renderDashboard();this.loadSystemMonitor();},
network:()=>{this.loadNetworkConfig();},
device:()=>{this.loadDeviceConfig();},
users:()=>{this.loadUsers();},
roles:()=>{this.loadRoles();},
peripheral:()=>{this.loadPeripherals();},
'periph-exec':()=>{this.loadPeriphExecPage();},
protocol:()=>{this.loadProtocolConfig('mqtt');if(this._startMqttStatusPolling)this._startMqttStatusPolling();},
'rule-script':()=>{this.loadRuleScriptPage();},
data:()=>{if(typeof this.setupFilesEvents==='function'&&!this._filesEventsBound){this.setupFilesEvents();this._filesEventsBound=true;}this.loadFileTree(this._currentDir||'/');this.loadFileSystemInfo();},
logs:()=>{
if(!this._currentLogFile){
this._currentLogFile='system.log';
}
const currentSpan=document.getElementById('current-log-file');
if(currentSpan)currentSpan.textContent=i18n.t('log-current-file-prefix')+this._currentLogFile;
var self=this;
setTimeout(function (){
self.loadLogFileList();
self.loadLogs();
var autoRefresh=document.getElementById('log-auto-refresh');
if(autoRefresh&&autoRefresh.checked){
self.startLogAutoRefresh();
}
},500);
},
'device-control':()=>{
if(typeof this.loadDeviceControlPage==='function'){
this.loadDeviceControlPage();
}else{
console.warn('[changePage] loadDeviceControlPage not available, module may not be loaded');
var content=document.getElementById('dc-content');
if(content){
content.innerHTML='';
var loadDiv=document.createElement('div');
loadDiv.className='dc-empty';
loadDiv.textContent=i18n.t('loading');
content.appendChild(loadDiv);
var self=this;
setTimeout(function (){
if(typeof self.loadDeviceControlPage==='function'){
self.loadDeviceControlPage();
}else{
content.innerHTML='';
var errDiv=document.createElement('div');
errDiv.className='dc-empty u-text-danger';
errDiv.textContent=i18n.t('module-load-fail')||'模块加载失败，请刷新页面重试';
content.appendChild(errDiv);
}
},1000);
}else{
console.error('[changePage] dc-content element not found!');
}
}
}
};
},
_refreshCurrentPageLocalizedContent(){
const loader=this._getPageLoaders()[this.currentPage];
if(typeof loader==='function'){
loader();
}
},
setupConfigTabs(){
},
_getProtocolName(formId){
const map={'modbus-rtu':'Modbus RTU','modbus-tcp':'Modbus TCP',mqtt:'MQTT',http:'HTTP',coap:'CoAP'};
for(const key of Object.keys(map)){
if(formId.includes(key))return map[key];
}
return 'TCP';
},
showConfigTab(pageId,tabId){
const page=document.getElementById(pageId);
if(!page)return ;
page.querySelectorAll('.config-tab').forEach(t=>{
t.classList.toggle('active',t.getAttribute('data-tab')===tabId);
});
page.querySelectorAll('.config-content').forEach(c=>c.classList.remove('active'));
const target=page.querySelector(`#${tabId}`);
if(target)target.classList.add('active');
if(pageId==='protocol-page'){
if(typeof this.loadProtocolConfig==='function')this.loadProtocolConfig(tabId);
}
if(pageId==='dashboard-page'){
if(typeof this.loadNetworkStatus==='function')this.loadNetworkStatus();
}
if(pageId==='device-page'&&tabId==='dev-ntp'){
if(typeof this.loadDeviceTime==='function')this.loadDeviceTime();
}
if(pageId==='device-page'&&tabId==='dev-basic'){
if(typeof this._loadDeviceHardwareInfo==='function')this._loadDeviceHardwareInfo();
}
if(pageId==='device-page'&&tabId==='dev-ota'){
var selfOta=this;
PageLoader.loadFragment('dev-ota-fragment-container','device-ota',function (){
if(typeof selfOta.loadOtaStatus==='function')selfOta.loadOtaStatus();
});
}
},
setupEventListeners(){
const loginForm=document.getElementById('login-form');
if(loginForm)loginForm.addEventListener('submit',e=>{e.preventDefault();this.handleLogin ();});
document.querySelectorAll('.menu-item').forEach(item=>{
item.addEventListener('click',e=>{e.preventDefault();this.changePage(item.dataset.page);});
});
const changePwdBtn=document.getElementById('change-password-btn');
if(changePwdBtn)changePwdBtn.addEventListener('click',()=>this.showChangePasswordModal());
const logoutBtn=document.getElementById('logout-btn');
if(logoutBtn)logoutBtn.addEventListener('click',()=>this.logout());
const closeId=(id)=>{this.hideModal(id);};
['close-password-modal','cancel-password-btn'].forEach(id=>{
const el=document.getElementById(id);
if(el)el.addEventListener('click',()=>closeId('change-password-modal'));
});
const confirmPwd=document.getElementById('confirm-password-btn');
if(confirmPwd)confirmPwd.addEventListener('click',()=>this.changePassword());
document.querySelectorAll('.menu-item').forEach(item=>{
item.addEventListener('click',()=>{
const sidebar=document.getElementById('sidebar');
if(sidebar&&window.innerWidth<=768&&sidebar.classList.contains('expanded')){
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
const btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}
});
});
},
async changePage(page){
if(typeof window.apiAbortPageRequests==='function'){
window.apiAbortPageRequests();
}
const pageAlias={monitor:'dashboard'};
const normalizedPage=pageAlias[page]||page;
await this.loadPage(normalizedPage+'-page');
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText();
}
document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
const target=document.getElementById(normalizedPage+'-page');
if(!target){
console.warn('[changePage] target page not found:',page,'=>',normalizedPage);
return ;
}
target.classList.add('active');
document.querySelectorAll('.menu-item').forEach(item=>{
item.classList.toggle('active',item.dataset.page===normalizedPage);
});
const titleKey=`page-title-${normalizedPage}`;
const titleEl=document.getElementById('page-title');
if(titleEl)titleEl.textContent=i18n.t(titleKey);
this.currentPage=normalizedPage;
const pageModuleMap=this._getPageModuleMap();
const pageLoaders=this._getPageLoaders();
if(normalizedPage!=='logs'&&this._logAutoRefreshTimer){
clearInterval(this._logAutoRefreshTimer);
this._logAutoRefreshTimer=null;
}
if(normalizedPage!=='device-control'&&typeof this._dcStopAllAutoRefresh==='function'){
this._dcStopAllAutoRefresh();
}
if(normalizedPage!=='protocol'){
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
if(typeof this._stopMasterStatusRefresh==='function'){
this._stopMasterStatusRefresh();
}
if(this._coilAutoRefreshTimer){
clearInterval(this._coilAutoRefreshTimer);
this._coilAutoRefreshTimer=null;
}
if(typeof this._stopPidAutoRefresh==='function'){
this._stopPidAutoRefresh();
}
}
const moduleName=pageModuleMap[normalizedPage];
const loader=pageLoaders[normalizedPage];
if(moduleName&&loader){
this._loadModule(moduleName,loader);
}else if(loader){
loader();
}else{
console.warn('[changePage] no page loader mapped for:',normalizedPage);
}
},
closeAllOverlays(){
document.querySelectorAll('.modal').forEach(function (m){
if(m._modalOverlayHandler){
m.removeEventListener('click',m._modalOverlayHandler);
m._modalOverlayHandler=null;
}
const closeBtn=m.querySelector('.modal-close, .modal-close-btn');
if(closeBtn&&closeBtn._modalCloseHandler){
closeBtn.removeEventListener('click',closeBtn._modalCloseHandler);
closeBtn._modalCloseHandler=null;
}
m.style.display='none';
});
document.querySelectorAll('div[style*="position: fixed"][style*="z-index"]').forEach(function (el){
if(el.querySelector('.modal-content, [onclick*="remove"]')){
el.remove();
}
});
document.querySelectorAll('.user-dropdown.open').forEach(function (d){
d.classList.remove('open');
});
if(typeof this.stopLogAutoRefresh==='function')this.stopLogAutoRefresh();
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
},
getAuthHeader(){
const token=localStorage.getItem('auth_token');
return token?{'Authorization':`Bearer ${token}`}:{};
},
_setText(id,text){
const el=document.getElementById(id);
if(el)el.textContent=text;
},
_setHtml(id,html){
const el=document.getElementById(id);
if(el)el.innerHTML=html;
},
_setBar(id,percent){
const el=document.getElementById(id);
if(el)el.style.width=Math.min (percent,100)+'%';
},
_formatBytes(bytes){
return window.formatBytes(bytes);
},
_setValue(id,value){
const el=document.getElementById(id);
if(el)el.value=value;
},
_setCheckbox(id,checked){
const el=document.getElementById(id);
if(el)el.checked=!!checked;
},
_setChecked(id,checked){
this._setCheckbox(id,checked);
},
_showMessage(id,show){
const el=document.getElementById(id);
if(!el)return ;
el.classList.toggle('is-hidden',!show);
el.style.display=show?'':'none';
},
_setTextContent(id,text){
this._setText(id,text);
}
};
(function (){
'use strict';
AppState.setupTheme=function (){
const savedTheme=localStorage.getItem('theme');
const systemPrefersDark=window.matchMedia('(prefers-color-scheme: dark)').matches;
let theme;
if(savedTheme){
theme=savedTheme;
}else{
theme=systemPrefersDark?'dark':'light';
localStorage.setItem('theme-auto','true');
}
this.setTheme(theme,false);
this.updateThemeToggleIcon(theme);
const themeToggleItem=document.getElementById('theme-toggle-item');
if(themeToggleItem){
themeToggleItem.addEventListener('click',()=>this.toggleTheme());
}
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',(e)=>{
const isAutoMode=localStorage.getItem('theme-auto')==='true';
if(isAutoMode){
const newTheme=e.matches?'dark':'light';
this.setTheme(newTheme,false);
this.updateThemeToggleIcon(newTheme);
}
});
};
AppState.setTheme=function (theme,isManual){
if(typeof isManual==='undefined')isManual=true;
document.documentElement.setAttribute('data-theme',theme);
localStorage.setItem('theme',theme);
if(isManual){
localStorage.removeItem('theme-auto');
}
this.updateThemeToggleIcon(theme);
};
AppState.toggleTheme=function (){
const current=document.documentElement.getAttribute('data-theme');
const newTheme=current==='dark'?'light':'dark';
this.setTheme(newTheme,true);
};
AppState.updateThemeToggleIcon=function (theme){
const themeToggleItem=document.getElementById('theme-toggle-item');
if(themeToggleItem){
const iconSpan=themeToggleItem.querySelector('.item-icon');
const textSpan=themeToggleItem.querySelector('span:not(.item-icon)');
if(iconSpan){
iconSpan.textContent=theme==='dark'?'☀':'🌙';
}
if(textSpan){
const key=theme==='dark'?'theme-light':'theme-dark';
const translated=window.i18n?window.i18n.t(key):(theme==='dark'?'浅色模式':'深色模式');
textSpan.textContent=translated;
}
}
};
})();
(function (){
'use strict';
AppState.refreshPage=function (){
const token=localStorage.getItem('auth_token');
const savedRemember=localStorage.getItem('remember');
const savedUsername=localStorage.getItem('username');
const savedPassword=localStorage.getItem('password');
if(!token){
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
return ;
}
apiGet('/api/auth/session')
.then(res=>{
if(res&&res.success&&res.data&&res.data.sessionValid){
this.currentUser.name=res.data.username||'Admin';
this.currentUser.role=res.data.role||'VIEWER';
this.currentUser.canManageFs=res.data.canManageFs===true;
this._showAppPage();
this._loadModule('dashboard',()=>{
this.renderDashboard();
this.loadSystemMonitor();
});
}else{
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
}
})
.catch(()=>{
this._tryAutoLogin (savedRemember,savedUsername,savedPassword);
});
};
AppState._tryAutoLogin =function (remember,username,password){
if(remember==='true'&&username&&password){
apiPost('/api/auth/login',{username,password})
.then(res=>{
if(res&&res.success){
const sid=res.sessionId;
localStorage.setItem('auth_token',sid);
localStorage.setItem('sessionId',sid);
localStorage.setItem('remember','true');
localStorage.setItem('username',username);
localStorage.setItem('password',password);
this.currentUser.name=res.username||username;
sessionStorage.setItem('currentUsername',this.currentUser.name);
apiGet('/api/auth/session').then(sr=>{
if(sr&&sr.success&&sr.data){
this.currentUser.role=sr.data.role||'VIEWER';
this.currentUser.canManageFs=sr.data.canManageFs===true;
}
}).catch(()=>{});
this._showAppPage();
this._loadModule('dashboard',()=>{
this.renderDashboard();
this.loadSystemMonitor();
});
}else{
localStorage.removeItem('password');
localStorage.removeItem('remember');
this._showLoginPage();
}
})
.catch(()=>{
this._showLoginPage();
});
}else{
this._showLoginPage();
}
};
AppState._showLoginPage=function (){
document.getElementById('login-page').style.display='flex';
document.getElementById('app-container').classList.add('fb-hidden');
const savedUsername=localStorage.getItem('username');
const savedRemember=localStorage.getItem('remember');
const usernameInput=document.getElementById('username');
const rememberCheckbox=document.getElementById('remember');
if(usernameInput&&savedUsername)usernameInput.value=savedUsername;
if(rememberCheckbox&&savedRemember==='true')rememberCheckbox.checked=true;
};
AppState._showAppPage=async function (){
document.getElementById('login-page').style.display='none';
document.getElementById('app-container').classList.remove('fb-hidden');
if(location.pathname!=='/'||location.hash){
history.replaceState(null,'','/');
}
await Promise.all([
this._loadModals(),
this.loadPage('dashboard-page')
]);
var skeleton=document.getElementById('skeleton-screen');
if(skeleton)skeleton.remove();
if(typeof this._applyUrlParams==='function')this._applyUrlParams();
};
AppState.handleLogin =function (){
const username=(document.getElementById('username')||{}).value;
const password=(document.getElementById('password')||{}).value;
const remember=(document.getElementById('remember')||{}).checked;
if(!username||!password){
Notification.warning(i18n.t('login-empty-warning'),i18n.t('login-fail-title'));
return ;
}
const submitBtn=document.querySelector('#login-form button[type="submit"]');
const originalText=submitBtn?submitBtn.innerHTML:'';
if(submitBtn){submitBtn.innerHTML=i18n.t('login-logging-in-html');submitBtn.disabled=true;}
apiPost('/api/auth/login',{username,password})
.then(res=>{
if(res&&res.success){
const sid=res.sessionId;
localStorage.setItem('auth_token',sid);
if(remember){
localStorage.setItem('remember','true');
localStorage.setItem('username',username);
localStorage.setItem('password',password);
localStorage.setItem('sessionId',sid);
}else{
['remember','username','password','sessionId'].forEach(k=>localStorage.removeItem(k));
}
this.currentUser.name=res.username||username;
sessionStorage.setItem('currentUsername',this.currentUser.name);
apiGet('/api/auth/session').then(sr=>{
if(sr&&sr.success&&sr.data){
this.currentUser.role=sr.data.role||'VIEWER';
this.currentUser.canManageFs=sr.data.canManageFs===true;
}
}).catch(()=>{});
this._showAppPage();
this._loadModule('dashboard',()=>{
this.renderDashboard();
this.loadSystemMonitor();
});
Notification.success(i18n.t('login-success-msg'),i18n.t('login-welcome-title'));
}else{
Notification.error((res&&res.error)||i18n.t('login-fail-title'),i18n.t('login-fail-title'));
}
})
.catch((err)=>{
const errorMsg=(err&&err.data&&err.data.error)||i18n.t('login-fail-msg');
Notification.error(errorMsg,i18n.t('login-fail-title'));
})
.finally(()=>{
if(submitBtn){submitBtn.innerHTML=originalText;submitBtn.disabled=false;}
});
};
AppState.showChangePasswordModal=function (){
this.showModal('change-password-modal');
['current-password-input','new-password-input','confirm-password-input'].forEach(id=>{
const el=document.getElementById(id);if(el)el.value='';
});
this.clearInlineError('password-error');
};
AppState.changePassword=function (){
const oldPwd=(document.getElementById('current-password-input')||{}).value||'';
const newPwd=(document.getElementById('new-password-input')||{}).value||'';
const confirmPwd=(document.getElementById('confirm-password-input')||{}).value||'';
const showErr=(msg)=>{
this.showInlineError('password-error',msg);
Notification.error(msg,i18n.t('change-pwd-fail'));
};
if(!oldPwd||!newPwd||!confirmPwd)return showErr(i18n.t('validate-all-fields'));
if(newPwd!==confirmPwd)return showErr(i18n.t('password-error')||i18n.t('validate-new-pwd-mismatch'));
if(newPwd.length<6)return showErr(i18n.t('validate-new-pwd-len'));
this.clearInlineError('password-error');
const btn=document.getElementById('confirm-password-btn');
if(btn){btn.disabled=true;btn.textContent=i18n.t('change-pwd-submitting');}
apiPost('/api/auth/change-password',{oldPassword:oldPwd,newPassword:newPwd})
.then(res=>{
if(res&&res.success){
Notification.success(i18n.t('change-pwd-success-msg'),i18n.t('change-pwd-success-title'));
this.hideModal('change-password-modal');
setTimeout(()=>{
localStorage.removeItem('auth_token');
this._showLoginPage();
},1500);
}else{
showErr((res&&res.error)||i18n.t('change-pwd-fail-msg'));
}
})
.catch(()=>{})
.finally(()=>{if(btn){btn.disabled=false;btn.textContent=i18n.t('confirm-change-btn');}});
};
AppState.logout=function (){
if(!confirm(i18n.t('logout-confirm')||'确定要退出登录吗？'))return ;
this._showLoginPage();
document.getElementById('login-form')&&document.getElementById('login-form').reset();
apiPost('/api/auth/logout',{})
.then(()=>{})
.catch(()=>{})
.finally(()=>{
localStorage.removeItem('auth_token');
localStorage.removeItem('sessionId');
localStorage.removeItem('password');
sessionStorage.removeItem('savedPassword');
sessionStorage.removeItem('currentUsername');
Notification.success(i18n.t('logout-success'),i18n.t('logout-title'));
});
};
})();
(function (){
'use strict';
AppState._sseSource=null;
AppState._sseHandlers={};
AppState._sseReconnectTimer=null;
AppState._sseReconnectDelay=1000;
AppState.connectSSE=function (){
if(this._sseSource)return ;
try{
this._sseSource=new EventSource('/api/events');
this._sseReconnectDelay=1000;
this._sseSource.onopen=function (){};
this._sseSource.onerror=function (){
console.warn('[SSE] 连接错误，将自动重连');
this.disconnectSSE();
var hasHandlers=false;
var handlers=this._sseHandlers||{};
for(var key in handlers){
if(handlers.hasOwnProperty(key)&&handlers[key]&&handlers[key].length>0){
hasHandlers=true;
break;
}
}
if(!hasHandlers){
return ;
}
this._sseReconnectTimer=setTimeout(function (){
this.connectSSE();
}.bind(this),this._sseReconnectDelay);
this._sseReconnectDelay=Math.min (this._sseReconnectDelay*2,30000);
}.bind(this);
this._rebindSSEHandlers();
}catch(e){
console.error('[SSE] 创建 EventSource 失败:',e);
}
};
AppState.disconnectSSE=function (){
if(this._sseSource){
this._sseSource.close();
this._sseSource=null;
}
if(this._sseReconnectTimer){
clearTimeout(this._sseReconnectTimer);
this._sseReconnectTimer=null;
}
};
AppState.onSSEEvent=function (eventType,handler){
if(!this._sseHandlers[eventType]){
this._sseHandlers[eventType]=[];
}
this._sseHandlers[eventType].push(handler);
if(this._sseSource){
this._sseSource.addEventListener(eventType,handler);
}
};
AppState.offSSEEvent=function (eventType,handler){
if(this._sseHandlers[eventType]){
var idx=this._sseHandlers[eventType].indexOf(handler);
if(idx!==-1)this._sseHandlers[eventType].splice(idx,1);
}
if(this._sseSource){
this._sseSource.removeEventListener(eventType,handler);
}
};
AppState._rebindSSEHandlers=function (){
var self=this;
Object.keys(this._sseHandlers).forEach(function (eventType){
self._sseHandlers[eventType].forEach(function (handler){
self._sseSource.addEventListener(eventType,handler);
});
});
};
})();
(function (){
'use strict';
if(typeof AppState==='undefined'){
console.error('[state-ui] AppState not found');
return ;
}
AppState.getEl=function (ref){
if(!ref)return null;
return typeof ref==='string'?document.getElementById(ref):ref;
};
AppState.showElement=function (ref,displayValue){
var el=this.getEl(ref);
if(!el)return null;
el.classList.remove('is-hidden');
if(displayValue){
el.style.display=displayValue;
}else{
el.style.removeProperty('display');
}
return el;
};
AppState.hideElement=function (ref){
var el=this.getEl(ref);
if(!el)return null;
el.classList.add('is-hidden');
el.style.display='none';
return el;
};
AppState.toggleVisible=function (ref,show){
var el=this.getEl(ref);
if(!el)return null;
if(show){
return this.showElement(el);
}else{
return this.hideElement(el);
}
};
AppState.showModal=function (ref){
var el=this.showElement(ref,'flex');
if(el){
var self=this;
el._modalOverlayHandler=function (e){
if(e.target===el){
self.hideModal(ref);
}
};
el.addEventListener('click',el._modalOverlayHandler);
var closeBtn=el.querySelector('.modal-close, .modal-close-btn');
if(closeBtn){
closeBtn._modalCloseHandler=function (){
self.hideModal(ref);
};
closeBtn.addEventListener('click',closeBtn._modalCloseHandler);
}
}
return el;
};
AppState.hideModal=function (ref){
var el=this.getEl(ref);
if(!el)return null;
if(el._modalOverlayHandler){
el.removeEventListener('click',el._modalOverlayHandler);
el._modalOverlayHandler=null;
}
var closeBtn=el.querySelector('.modal-close, .modal-close-btn');
if(closeBtn&&closeBtn._modalCloseHandler){
closeBtn.removeEventListener('click',closeBtn._modalCloseHandler);
closeBtn._modalCloseHandler=null;
}
el.classList.add('is-hidden');
el.style.display='none';
return el;
};
AppState.showInlineError=function (ref,message){
var el=this.getEl(ref);
if(!el)return null;
el.textContent=message||'';
return this.showElement(el,'block');
};
AppState.clearInlineError=function (ref){
var el=this.getEl(ref);
if(!el)return null;
el.textContent='';
return this.hideElement(el);
};
AppState.renderEmptyTableRow=function (tbodyRef,colspan,text,className){
var tbody=this.getEl(tbodyRef);
if(!tbody)return null;
tbody.innerHTML='';
var row=document.createElement('tr');
var cell=document.createElement('td');
cell.colSpan=colspan;
cell.className=className||'u-empty-cell';
cell.textContent=text||'';
row.appendChild(cell);
tbody.appendChild(row);
return row;
};
AppState.renderPagination=function (containerRef,options){
var container=this.getEl(containerRef);
if(!container)return null;
var total=Math.max(0,Number(options&&options.total)||0);
var pageSize=Math.max(1,Number(options&&options.pageSize)||10);
var totalPages=Math.max(1,Math.ceil(total / pageSize));
var currentPage=Math.min (Math.max(1,Number(options&&options.page)||1),totalPages);
var maxVisiblePages=Math.max(3,Number(options&&options.maxVisiblePages)||5);
var summaryText=(options&&options.summaryText)||'';
var onPageChange=(options&&typeof options.onPageChange==='function')?options.onPageChange:null;
container.innerHTML='';
var wrap=document.createElement('div');
wrap.className='pagination u-pagination';
var appendButton=function (label,targetPage,disabled,active){
var button=document.createElement('button');
button.type='button';
button.className='fb-btn fb-btn-sm'+(active?' fb-btn-primary':'');
button.textContent=label;
button.disabled=!!disabled;
if(!button.disabled&&onPageChange){
(function (pg){
button.addEventListener('click',function (){onPageChange(pg);});
})(targetPage);
}
wrap.appendChild(button);
};
var appendEllipsis=function (){
var ellipsis=document.createElement('span');
ellipsis.className='u-pagination-ellipsis';
ellipsis.textContent='...';
wrap.appendChild(ellipsis);
};
var appendSummary=function (){
if(!summaryText)return ;
var summary=document.createElement('span');
summary.className='u-pagination-summary';
summary.textContent=summaryText;
wrap.appendChild(summary);
};
if(totalPages<=1){
appendSummary();
container.appendChild(wrap);
return wrap;
}
appendButton('«',currentPage-1,currentPage<=1,false);
var startPage=Math.max(1,currentPage-Math.floor(maxVisiblePages / 2));
var endPage=Math.min (totalPages,startPage+maxVisiblePages-1);
if(endPage-startPage+1<maxVisiblePages){
startPage=Math.max(1,endPage-maxVisiblePages+1);
}
if(startPage>1){
appendButton('1',1,false,false);
if(startPage>2)appendEllipsis();
}
for(var page=startPage;page<=endPage;page++){
appendButton(String(page),page,page===currentPage,page===currentPage);
}
if(endPage<totalPages){
if(endPage<totalPages-1)appendEllipsis();
appendButton(String(totalPages),totalPages,false,false);
}
appendButton('»',currentPage+1,currentPage>=totalPages,false);
appendSummary();
container.appendChild(wrap);
return wrap;
};
AppState.setLoading=function (ref,text){
var el=this.getEl(ref);
if(!el)return null;
if(!el.hasAttribute('data-original-text')){
el.setAttribute('data-original-text',el.textContent);
}
el.disabled=true;
el.textContent=text||(typeof i18n!=='undefined'?i18n.t('saving'):'保存中...');
el.classList.add('is-loading');
return el;
};
AppState.restoreButton=function (ref,text){
var el=this.getEl(ref);
if(!el)return null;
el.disabled=false;
el.textContent=text||el.getAttribute('data-original-text')||'';
el.classList.remove('is-loading');
el.removeAttribute('data-original-text');
return el;
};
AppState.renderBadge=function (type,text){
var span=document.createElement('span');
span.className='badge badge-'+(type||'info');
span.textContent=text||'';
return span;
};
AppState.setExclusiveActive=function (containerRef,selector,activeEl,className){
var container=this.getEl(containerRef);
if(!container)return ;
var activeClass=className||'is-active';
container.querySelectorAll(selector).forEach(function (el){
el.classList.toggle(activeClass,el===activeEl);
});
};
AppState.setupUserDropdown=function (){
var dropdownBtn=document.getElementById('user-dropdown-btn');
var dropdownMenu=document.getElementById('user-dropdown-menu');
if(!dropdownBtn||!dropdownMenu)return ;
dropdownBtn.addEventListener('click',function (e){
e.stopPropagation();
var dropdown=dropdownBtn.closest('.user-dropdown');
dropdown.classList.toggle('open');
});
document.addEventListener('click',function (e){
if(!dropdownBtn.contains(e.target)&&!dropdownMenu.contains(e.target)){
var dropdown=dropdownBtn.closest('.user-dropdown');
if(dropdown)dropdown.classList.remove('open');
}
});
dropdownMenu.querySelectorAll('.dropdown-item').forEach(function (item){
item.addEventListener('click',function (){
var dropdown=dropdownBtn.closest('.user-dropdown');
if(dropdown)dropdown.classList.remove('open');
});
});
};
AppState.toggleSection=function (bodyId){
var body=document.getElementById(bodyId);
var icon=document.getElementById(bodyId+'-icon');
if(!body)return ;
if(body.classList.contains('fb-hidden')){
body.classList.remove('fb-hidden');
body.style.display='';
if(icon)icon.innerHTML='&#9660;';
}else{
body.classList.add('fb-hidden');
body.style.display='';
if(icon)icon.innerHTML='&#9654;';
}
};
AppState.setupSidebarToggle=function (){
var self=this;
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.addEventListener('click',function (){self.toggleSidebar();});
if(localStorage.getItem('sidebarCollapsed')==='true')this.collapseSidebar();
};
AppState.toggleSidebar=function (){
var sidebar=document.getElementById('sidebar');
if(!sidebar)return ;
var isMobile=window.innerWidth<=768;
if(isMobile){
if(sidebar.classList.contains('expanded')){
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}else{
sidebar.classList.add('expanded');
this.sidebarCollapsed=false;
var btn2=document.getElementById('sidebar-toggle');
if(btn2)btn2.textContent='✕';
}
}else{
this.sidebarCollapsed?this.expandSidebar():this.collapseSidebar();
}
};
AppState.collapseSidebar=function (){
var sidebar=document.getElementById('sidebar');
if(sidebar){
sidebar.classList.add('collapsed');
sidebar.classList.remove('expanded');
this.sidebarCollapsed=true;
localStorage.setItem('sidebarCollapsed','true');
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='☰';
}
};
AppState.expandSidebar=function (){
var sidebar=document.getElementById('sidebar');
if(sidebar){
sidebar.classList.remove('collapsed');
this.sidebarCollapsed=false;
localStorage.setItem('sidebarCollapsed','false');
var btn=document.getElementById('sidebar-toggle');
if(btn)btn.textContent='✕';
}
};
})();
function _loadScript(src,onSuccess,onFail){
var script=document.createElement('script');
script.src=src;
script.onload=onSuccess;
script.onerror=function (){
setTimeout(function (){
var retry=document.createElement('script');
retry.src=src;
retry.onload=onSuccess;
retry.onerror=function (){
console.error('[FastBee] Failed to load '+src+' after retry');
if(onFail)onFail();
};
document.head.appendChild(retry);
},1500);
};
document.head.appendChild(script);
}
function _bootApp(){
if(typeof i18n==='undefined'){
window.i18n={currentLang:'zh-CN',t:function (k){return k;},updatePageText:function (){}};
}
if(typeof Notification!=='undefined'&&Notification.init){
Notification.init();
}
if(typeof i18n!=='undefined'){
i18n.updatePageText();
}
var savedUsername=localStorage.getItem('username');
var savedPassword=localStorage.getItem('password');
var remember=localStorage.getItem('remember')==='true';
if(savedUsername&&savedPassword&&remember){
document.getElementById('username').value=savedUsername;
document.getElementById('password').value=savedPassword;
document.getElementById('remember').checked=true;
}
var langSelect=document.getElementById('language-select');
if(langSelect&&typeof i18n!=='undefined'){
langSelect.value=i18n.currentLang;
}
AppState.init();
window.app=AppState;
if(typeof i18n!=='undefined'&&i18n.currentLang==='en'){
_loadScript('./js/modules/i18n-en.js',function (){
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText();
}
});
}
}
document.addEventListener('DOMContentLoaded',function (){
if(typeof AppState!=='undefined'){
_bootApp();
}
});