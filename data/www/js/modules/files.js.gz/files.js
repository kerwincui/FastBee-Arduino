(function (){
AppState.registerModule('files',{
setupFilesEvents(){
var self=this;
const fsRefreshBtn=document.getElementById('fs-refresh-btn');
if(fsRefreshBtn)fsRefreshBtn.onclick=function (){
self.loadFileSystemInfo({noCache:true});
self.loadFileTree(self._currentDir||'/',{noCache:true});
};
const fsUpBtn=document.getElementById('fs-up-btn');
if(fsUpBtn)fsUpBtn.onclick=function (){self.navigateUp();};
const exportBtn=document.getElementById('fs-export-config-btn');
if(exportBtn)exportBtn.onclick=function (){
self.exportConfigFile();
};
const importBtn=document.getElementById('fs-import-config-btn');
if(importBtn)importBtn.onclick=function (){
self.importConfigFile();
};
},
loadFileSystemInfo(options){
var getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
getter('/api/filesystem')
.then(res=>{
if(res&&res.success){
const d=res.data||{};
const infoSpan=document.getElementById('fs-info');
if(infoSpan){
const total=d.totalBytes?(d.totalBytes / 1024 / 1024).toFixed(2)+' MB':'N/A';
const used=d.usedBytes?(d.usedBytes / 1024 / 1024).toFixed(2)+' MB':'N/A';
infoSpan.textContent=`总空间:${total}|已用:${used}`;
}
}
})
.catch(()=>{});
},
loadFileTree(path,options){
const treeContainer=document.getElementById('file-tree');
if(!treeContainer)return ;
this._currentDir=path;
const pathEl=document.getElementById('current-dir-path');
if(pathEl)pathEl.textContent=path;
treeContainer.innerHTML='<div class="u-text-muted">加载中...</div>';
var getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
getter('/api/files',{path:path})
.then(res=>{
if(!res||!res.success){
treeContainer.innerHTML='<div class="u-text-danger">加载失败</div>';
return ;
}
const data=res.data||{};
const dirs=data.dirs||[];
const files=data.files||[];
var fragment=document.createDocumentFragment();
dirs.forEach(dir=>{
var item=document.createElement('div');
item.className='file-tree-item';
item.dataset.path=path+dir.name+'/';
item.dataset.type='dir';
var icon=document.createElement('span');
icon.className='file-tree-icon-dir';
icon.textContent='📁';
item.appendChild(icon);
item.appendChild(document.createTextNode(' '+dir.name));
fragment.appendChild(item);
});
files.forEach(file=>{
const size=file.size<1024?`${file.size}B`:
file.size<1024*1024?`${(file.size / 1024).toFixed(1)}KB`:
`${(file.size / 1024 / 1024).toFixed(2)}MB`;
var item=document.createElement('div');
item.className='file-tree-item';
item.dataset.path=path+file.name;
item.dataset.type='file';
var icon=document.createElement('span');
icon.className='file-tree-icon-file';
icon.textContent='📄';
item.appendChild(icon);
item.appendChild(document.createTextNode(' '+file.name+' '));
var sizeSpan=document.createElement('span');
sizeSpan.className='file-tree-size';
sizeSpan.textContent='('+size+')';
item.appendChild(sizeSpan);
fragment.appendChild(item);
});
treeContainer.innerHTML='';
if(dirs.length===0&&files.length===0){
treeContainer.innerHTML='<div class="u-empty-state u-text-muted">空目录</div>';
}else{
treeContainer.appendChild(fragment);
}
treeContainer.querySelectorAll('.file-tree-item').forEach(item=>{
item.addEventListener('click',(e)=>{
const path=e.currentTarget.dataset.path;
const type=e.currentTarget.dataset.type;
treeContainer.querySelectorAll('.file-tree-item').forEach(i=>{
i.classList.remove('is-active');
});
e.currentTarget.classList.add('is-active');
if(type==='dir'){
this.loadFileTree(path);
}else{
this.openFile(path);
}
});
});
})
.catch(err=>{
console.error('Load file tree failed:',err);
treeContainer.innerHTML='<div class="u-text-danger">加载失败</div>';
});
},
openFile(path){
const editor=document.getElementById('file-editor');
const pathSpan=document.getElementById('current-file-path');
const statusDiv=document.getElementById('file-status');
if(!editor||!pathSpan)return ;
const editable=path.endsWith('.json')||path.endsWith('.txt')||path.endsWith('.log')||
path.endsWith('.html')||path.endsWith('.js')||path.endsWith('.css');
var isConfigJson=path.startsWith('/config/')&&path.endsWith('.json');
var exportBtn=document.getElementById('fs-export-config-btn');
var importBtn=document.getElementById('fs-import-config-btn');
if(exportBtn)exportBtn.classList.toggle('fb-hidden',!isConfigJson);
if(importBtn)importBtn.classList.toggle('fb-hidden',!isConfigJson);
pathSpan.textContent=path;
this._currentFilePath=path;
editor.value='';
editor.readOnly=true;
if(!editable){
statusDiv.textContent='此文件类型不支持编辑';
return ;
}
statusDiv.textContent='加载中...';
apiGet('/api/files/content',{path:path})
.then(res=>{
if(this._currentFilePath!==path)return ;
if(!res||!res.success){
var detail=(res&&res.message)?' ('+res.message+')'
:(res&&res.error)?' ('+res.error+')'
:'';
if(!detail){
detail=res&&typeof res==='object'&&Object.keys(res).length===0
?' (服务器响应为空，设备可能内存不足，请稍后重试)'
:' (未知错误)';
}
statusDiv.textContent='加载失败: '+detail;
return ;
}
const data=res.data||{};
editor.value=data.content||'';
editor.disabled=false;
editor.readOnly=true;
const size=data.size<1024?`${data.size}B`:
data.size<1024*1024?`${(data.size / 1024).toFixed(1)}KB`:
`${(data.size / 1024 / 1024).toFixed(2)}MB`;
statusDiv.textContent=`大小:${size}|就绪`;
})
.catch(err=>{
if(this._currentFilePath!==path)return ;
console.error('Open file failed:',err);
var msg='加载失败';
var detail='';
if(err&&err.data&&(err.data.message||err.data.error)){
detail=' ('+(err.data.message||err.data.error)+')';
}else if(err&&err.status){
detail=' (HTTP '+err.status+')';
}else if(err&&err.message){
detail=' ('+err.message+')';
}
statusDiv.textContent=msg+detail;
});
},
navigateUp(){
const currentPath=this._currentDir||'/';
if(currentPath==='/')return ;
let path=currentPath;
if(path.endsWith('/'))path=path.slice(0,-1);
const lastSlashIndex=path.lastIndexOf('/');
if(lastSlashIndex===0){
this.loadFileTree('/');
}else if(lastSlashIndex>0){
const parentPath=path.substring(0,lastSlashIndex+1);
this.loadFileTree(parentPath);
}else{
this.loadFileTree('/');
}
},
exportConfigFile(){
var self=this;
var filePath=this._currentFilePath;
if(!filePath){
Notification.warning('请先选择一个配置文件');
return ;
}
var rawUrl='/api/files/content?path='+encodeURIComponent(filePath)+'&raw=1';
var headers={};
try{
var token=localStorage.getItem('auth_token');
if(token)headers['Authorization']='Bearer '+token;
}catch(tokErr){}
fetch(rawUrl,{credentials:'include',headers:headers,cache:'no-store'})
.then(function (resp){
if(!resp.ok){
throw new Error('HTTP '+resp.status);
}
return resp.text();
})
.then(function (rawContent){
self._doExport(filePath,rawContent);
})
.catch(function (err){
console.warn('Raw export failed, falling back to editor content:',err);
var editor=document.getElementById('file-editor');
if(editor&&editor.value){
self._doExport(filePath,editor.value);
return ;
}
Notification.error(
'无法从设备获取配置内容'+
' ('+(err&&err.message?err.message:'unknown')+')'
);
});
},
_doExport(filePath,rawContent){
var parsed;
try{
parsed=JSON.parse(rawContent);
}catch(e){
Notification.error('文件内容不是有效的 JSON 格式');
return ;
}
try{
if(filePath==='/config/device.json'&&parsed&&typeof parsed==='object'){
if('deviceId' in parsed)parsed.deviceId='';
}
if(filePath==='/config/protocol.json'&&parsed&&typeof parsed==='object'){
if(parsed.mqtt&&typeof parsed.mqtt==='object'&&'clientId' in parsed.mqtt){
parsed.mqtt.clientId='';
}
}
}catch(sanitizeErr){
console.warn('Sanitize export content failed:',sanitizeErr);
}
var exportText=JSON.stringify(parsed,null,2);
var parts=filePath.split('/');
var fileName=parts[parts.length-1]||'config.json';
try{
var blob=new Blob([exportText],{type:'application/json;charset=utf-8'});
if(window.navigator&&typeof window.navigator.msSaveBlob==='function'){
window.navigator.msSaveBlob(blob,fileName);
Notification.success('配置导出成功');
return ;
}
var url=URL.createObjectURL(blob);
var a=document.createElement('a');
a.href=url;
a.download=fileName;
a.rel='noopener';
a.style.display='none';
document.body.appendChild(a);
a.click();
setTimeout(function (){
try{
if(a.parentNode)a.parentNode.removeChild(a);
URL.revokeObjectURL(url);
}catch(cleanupErr){
console.warn('Cleanup export anchor failed:',cleanupErr);
}
},250);
Notification.success('配置导出成功');
}catch(downloadErr){
console.error('Export download failed:',downloadErr);
Notification.error(
'配置导出失败'+
' ('+(downloadErr&&downloadErr.message?downloadErr.message:'unknown')+')'
);
}
},
importConfigFile(){
var self=this;
var filePath=this._currentFilePath;
if(!filePath){
Notification.warning('请先选择一个配置文件');
return ;
}
var input=document.createElement('input');
input.type='file';
input.accept='.json';
input.onchange=function (e){
var file=e.target.files[0];
if(!file)return ;
if(file.size>65536){
Notification.error('文件过大，最大支持 64KB');
return ;
}
var reader=new FileReader();
reader.onload=function (evt){
var content=evt.target.result;
try{
var parsed=JSON.parse(content);
if(typeof parsed!=='object'||parsed===null||Array.isArray(parsed)){
Notification.error('配置文件必须是 JSON 对象格式');
return ;
}
}catch(parseErr){
Notification.error('文件内容不是有效的 JSON 格式');
return ;
}
if(!confirm('确定要用导入的文件覆盖当前配置吗？此操作不可撤销！')){
return ;
}
apiPost('/api/files/save',{path:filePath,content:content})
.then(function (res){
if(res&&res.success){
Notification.success('配置导入成功');
self.openFile(filePath);
}else{
Notification.error(
(res&&res.message)||'配置导入失败'
);
}
})
.catch(function (err){
console.error('Import config failed:',err);
Notification.error('配置导入失败');
});
};
reader.readAsText(file);
};
input.click();
}
});
if(typeof AppState.setupFilesEvents==='function'){
AppState.setupFilesEvents();
}
})();