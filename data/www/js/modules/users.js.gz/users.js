(function (){
AppState.registerModule('users',{
setupUsersEvents(){
const addUserBtn=document.getElementById('add-user-btn');
if(addUserBtn)addUserBtn.addEventListener('click',()=>this.showAddUserModal());
const closeUserModal=()=>{
const modal=document.getElementById('add-user-modal');
if(modal){
AppState.hideModal(modal);
modal.dataset.editMode='add';
modal.dataset.editUsername='';
}
const usernameInput=document.getElementById('add-username-input');
if(usernameInput)usernameInput.disabled=false;
};
['close-add-user-modal','cancel-add-user-btn'].forEach(id=>{
const el=document.getElementById(id);
if(el)el.addEventListener('click',closeUserModal);
});
const confirmAdd=document.getElementById('confirm-add-user-btn');
if(confirmAdd)confirmAdd.addEventListener('click',()=>this.addUser());
const usersRefreshBtn=document.getElementById('users-refresh-btn');
if(usersRefreshBtn)usersRefreshBtn.addEventListener('click',()=>this._refreshUsersList());
},
_refreshUsersList(){
var btn=document.getElementById('users-refresh-btn');
if(btn&&btn.disabled)return ;
if(btn){btn.disabled=true;btn.textContent='加载中...';}
if(typeof window.apiInvalidateCache==='function'){
window.apiInvalidateCache('/api/users');
}
this.loadUsers({noCache:true});
setTimeout(function (){
if(btn){btn.disabled=false;btn.innerHTML='&#x21bb; 刷新';}
},2000);
},
loadUsers(options){
var getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
getter('/api/users',{page:1,limit:100})
.then(res=>{
if(!res||!res.success)return ;
const users=(res.data&&res.data.users)?res.data.users:[];
this._renderUsers(users);
})
.catch(()=>{});
},
_renderUsers(users){
const tbody=document.getElementById('users-table-body');
if(!tbody)return ;
tbody.innerHTML='';
if(!users||users.length===0){
this.renderEmptyTableRow(tbody,5,i18n.t('no-users-data'));
return ;
}
users.forEach(user=>{
const row=document.createElement('tr');
const td=(content)=>{
const cell=document.createElement('td');
if(typeof content==='string'||typeof content==='number'){
cell.textContent=content;
}else{
cell.appendChild(content);
}
return cell;
};
const roleMap={admin :i18n.t('admin'),operator:i18n.t('operator'),viewer:i18n.t('viewer')};
const roleText=roleMap[user.role]||user.role||'—';
const lastLogin =user.lastLogin ?new Date(user.lastLogin *1000).toLocaleString():'—';
const badge=document.createElement('span');
badge.className='badge';
if(user.isLocked){
badge.classList.add('badge-warning');
badge.textContent=i18n.t('user-locked-badge');
}else if(!user.enabled){
badge.classList.add('badge-danger');
badge.textContent=i18n.t('user-status-inactive');
}else{
badge.classList.add('badge-success');
badge.textContent=i18n.t('user-status-active');
}
const actionCell=document.createElement('td');
actionCell.className='u-toolbar-sm';
const editBtn=document.createElement('button');
editBtn.className='fb-btn fb-btn-sm fb-btn-primary fb-btn-action-edit';
editBtn.textContent=i18n.t('edit-user');
editBtn.addEventListener('click',()=>this.showEditUserModal(user));
actionCell.appendChild(editBtn);
const toggleBtn=document.createElement('button');
if(user.enabled&&!user.isLocked){
toggleBtn.className='fb-btn fb-btn-sm fb-btn-warning';
toggleBtn.textContent=i18n.t('disable-user');
toggleBtn.addEventListener('click',()=>this.toggleUserStatus(user.username,false));
}else{
toggleBtn.className='fb-btn fb-btn-sm fb-btn-success';
toggleBtn.textContent=i18n.t('enable-user');
toggleBtn.addEventListener('click',()=>this.toggleUserStatus(user.username,true));
}
actionCell.appendChild(toggleBtn);
if(user.isLocked){
const unlockBtn=document.createElement('button');
unlockBtn.className='fb-btn fb-btn-sm fb-btn-success';
unlockBtn.textContent=i18n.t('unlock-user');
unlockBtn.addEventListener('click',()=>this.unlockUser(user.username));
actionCell.appendChild(unlockBtn);
}
if(user.username!=='admin'){
const delBtn=document.createElement('button');
delBtn.className='fb-btn fb-btn-sm fb-btn-danger';
delBtn.textContent=i18n.t('delete-user');
delBtn.addEventListener('click',()=>{
if(confirm(`${i18n.t('confirm-delete-user-msg')}${user.username}${i18n.t('confirm-suffix')}`)){
this.deleteUser(user.username);
}
});
actionCell.appendChild(delBtn);
}
row.appendChild(td(user.username));
row.appendChild(td(roleText));
row.appendChild(td(lastLogin ));
row.appendChild(td(badge));
row.appendChild(actionCell);
tbody.appendChild(row);
});
},
showAddUserModal(){
const modal=document.getElementById('add-user-modal');
if(modal){
modal.dataset.editMode='add';
modal.dataset.editUsername='';
AppState.showModal(modal);
}
const title=document.getElementById('add-user-title');
if(title)title.textContent=i18n.t('add-user-modal-title');
const confirmBtn=document.getElementById('confirm-add-user-btn');
if(confirmBtn)confirmBtn.textContent=i18n.t('confirm-add-btn');
['add-username-input','add-password-input','add-confirm-password-input'].forEach(id=>{
const el=document.getElementById(id);if(el)el.value='';
});
const usernameInput=document.getElementById('add-username-input');
if(usernameInput)usernameInput.disabled=false;
const sel=document.getElementById('add-role-select');
if(sel)sel.value='operator';
AppState.clearInlineError('add-user-error');
},
addUser(){
const modal=document.getElementById('add-user-modal');
const isEditMode=modal&&modal.dataset.editMode==='edit';
const editUsername=modal?modal.dataset.editUsername:'';
const username=isEditMode?editUsername:((document.getElementById('add-username-input')||{}).value||'').trim();
const password=(document.getElementById('add-password-input')||{}).value||'';
const confirmPwd=(document.getElementById('add-confirm-password-input')||{}).value||'';
const role=(document.getElementById('add-role-select')||{}).value||'operator';
const errDiv=document.getElementById('add-user-error');
const showErr=(msg)=>{
AppState.showInlineError('add-user-error',msg);
Notification.error(msg,isEditMode?i18n.t('edit-user-fail'):i18n.t('add-user-fail'));
};
if(!username)return showErr(i18n.t('validate-username-empty'));
if(username.length<3||username.length>32)return showErr(i18n.t('validate-username-len'));
if(!password||!confirmPwd)return showErr(i18n.t('validate-pwd-empty'));
if(password!==confirmPwd)return showErr(i18n.t('validate-pwd-mismatch'));
if(password.length<6)return showErr(i18n.t('validate-pwd-len'));
AppState.clearInlineError('add-user-error');
const btn=document.getElementById('confirm-add-user-btn');
if(btn){btn.disabled=true;btn.textContent=isEditMode?i18n.t('saving-btn'):i18n.t('adding-btn');}
let apiCall;
if(isEditMode){
apiCall=apiPost('/api/users/update',{username,password,role,enabled:'true'});
}else{
apiCall=apiPost('/api/users',{username,password,role});
}
apiCall
.then(res=>{
if(res&&res.success){
Notification.success(`${username}${isEditMode?i18n.t('role-updated'):i18n.t('role-created')}${i18n.t('role-success-suffix')}`,isEditMode?i18n.t('edit-user-success'):i18n.t('add-user-success'));
if(modal){
AppState.hideModal(modal);
modal.dataset.editMode='add';
modal.dataset.editUsername='';
}
const usernameInput=document.getElementById('add-username-input');
if(usernameInput)usernameInput.disabled=false;
this.loadUsers({noCache:true});
}else{
showErr((res&&res.error)||(isEditMode?i18n.t('modify-user-fail-msg'):i18n.t('add-user-fail-msg')));
}
})
.catch(()=>{})
.finally(()=>{if(btn){btn.disabled=false;btn.textContent=i18n.t('confirm-add-btn');}});
},
showEditUserModal(user){
const modal=document.getElementById('add-user-modal');
if(!modal){
console.error('[showEditUserModal] Modal not found!');
Notification.info(`${i18n.t('edit-user-modal-title')}:${user.username}`,i18n.t('edit-user-modal-title'));
return ;
}
modal.dataset.editMode='edit';
modal.dataset.editUsername=user.username;
const title=document.getElementById('add-user-title');
if(title)title.textContent=i18n.t('edit-user-modal-title');
const usernameInput=document.getElementById('add-username-input');
if(usernameInput){
usernameInput.value=user.username;
usernameInput.disabled=true;
}
const pwdInput=document.getElementById('add-password-input');
const confirmInput=document.getElementById('add-confirm-password-input');
if(pwdInput)pwdInput.value='';
if(confirmInput)confirmInput.value='';
const roleSelect=document.getElementById('add-role-select');
if(roleSelect)roleSelect.value=user.role||'operator';
const confirmBtn=document.getElementById('confirm-add-user-btn');
if(confirmBtn)confirmBtn.textContent=i18n.t('confirm-save-btn');
AppState.showModal(modal);
AppState.clearInlineError('add-user-error');
},
toggleUserStatus(username,enable){
const action=enable?i18n.t('enable-user'):i18n.t('disable-user');
const confirmMsg=enable?i18n.t('confirm-enable-user'):i18n.t('confirm-disable-user');
if(!confirm(`${confirmMsg}${username}${i18n.t('confirm-suffix')}`))return ;
apiPost('/api/users/update',{username,enabled:enable?'true':'false'})
.then(res=>{
if(res&&res.success){
Notification.success(`${username}${enable?i18n.t('user-enabled-msg'):i18n.t('user-disabled-msg')}`,i18n.t('user-status-update'));
this.loadUsers({noCache:true});
}else{
Notification.error((res&&res.error)||i18n.t('operation-fail'),i18n.t('operation-fail'));
}
})
.catch(()=>{});
},
unlockUser(username){
if(!confirm(`${i18n.t('confirm-unlock-user')}${username}${i18n.t('confirm-suffix')}`))return ;
apiPost('/api/users/unlock-account',{username})
.then(res=>{
if(res&&res.success){
Notification.success(`${username}${i18n.t('user-unlocked-msg')}`,i18n.t('unlock-success'));
this.loadUsers({noCache:true});
}else{
Notification.error((res&&res.error)||i18n.t('operation-fail'),i18n.t('operation-fail'));
}
})
.catch(()=>{});
},
deleteUser(username){
if(!confirm(`${i18n.t('confirm-delete-user-msg')}${username}${i18n.t('confirm-suffix')}`))return ;
apiDelete('/api/users/'+encodeURIComponent(username))
.then(res=>{
if(res&&res.success){
Notification.success(`${username}${i18n.t('user-deleted-msg')}`,i18n.t('delete-success'));
this.loadUsers({noCache:true});
}else{
Notification.error((res&&res.error)||i18n.t('operation-fail'),i18n.t('operation-fail'));
}
})
.catch(()=>{});
}
});
if(typeof AppState.setupUsersEvents==='function'){
AppState.setupUsersEvents();
}
})();