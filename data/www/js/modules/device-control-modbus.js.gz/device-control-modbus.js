(function (){
'use strict';
Object.assign(AppState,{
_setupSSE:function (){
AppState.connectSSE();
var self=this;
this._sseModbusHandler=function (e){
try{
var data=JSON.parse(e.data);
self._handleSSEModbusData(data);
}catch(err){
console.warn('[SSE] 数据解析失败:',err);
}
};
this._sseSensorHandler=function (e){
try{
var data=JSON.parse(e.data);
self._handleSSESensorData(data);
}catch(err){
console.warn('[SSE] 传感器数据解析失败:',err);
}
};
AppState.onSSEEvent('modbus-data',this._sseModbusHandler);
AppState.onSSEEvent('sensor-data',this._sseSensorHandler);
},
_closeSSE:function (){
if(this._sseModbusHandler){
AppState.offSSEEvent('modbus-data',this._sseModbusHandler);
this._sseModbusHandler=null;
}
if(this._sseSensorHandler){
AppState.offSSEEvent('sensor-data',this._sseSensorHandler);
this._sseSensorHandler=null;
}
AppState.disconnectSSE();
if(this._sseDebounceTimer){
clearTimeout(this._sseDebounceTimer);
this._sseDebounceTimer=null;
}
},
_handleSSESensorData:function (data){
if(!data||!data.key)return ;
var card=document.querySelector('.dc-monitor-card[data-id="'+data.key+'"]');
if(card){
var valEl=card.querySelector('.dc-monitor-value');
var unitEl=card.querySelector('.dc-monitor-unit');
if(valEl)valEl.textContent=data.value||'--';
if(unitEl&&data.unit)unitEl.textContent=data.unit;
}
},
_findDevIdxBySlaveAddress:function (slaveAddress){
var devices=this._modbusDevices||[];
for(var i=0;i<devices.length;i++){
if(devices[i].slaveAddress===slaveAddress){
return i;
}
}
return -1;
},
_parseSensorId:function (sensorId){
if(!sensorId)return null;
var devices=this._modbusDevices||[];
for(var i=0;i<devices.length;i++){
if(!devices[i].sensorId)continue;
var prefix=devices[i].sensorId+'_ch';
if(sensorId.indexOf(prefix)===0&&sensorId.length>prefix.length){
var numPart=sensorId.substring(prefix.length);
if(numPart.length>0&&numPart.length<=3&&/^\d+$/.test(numPart)){
var channel=parseInt(numPart,10);
if(channel>=0){
return {
type:devices[i].deviceType||'relay',
devIdx:i,
channel:channel,
slaveAddress:devices[i].slaveAddress
};
}
}
}
}
for(var j=0;j<devices.length;j++){
if(devices[j].sensorId&&devices[j].sensorId===sensorId){
return {
type:devices[j].deviceType||'relay',
devIdx:j,
channel:0,
slaveAddress:devices[j].slaveAddress
};
}
}
return null;
},
_updateCoilUIFromSSE:function (devIdx,channel,value){
var dev=this._modbusDevices[devIdx];
if(!dev)return false;
var ncMode=dev.ncMode||false;
var numVal=parseInt(value,10)||0;
var boolVal=numVal!==0;
var isOn=ncMode?!boolVal:boolVal;
var onText='ON';
var offText='OFF';
var states=this._dcCoilStates[devIdx]||[];
if(channel>=0&&channel<(dev.channelCount||8)){
states[channel]=boolVal;
this._dcCoilStates[devIdx]=states;
}
var card=document.querySelector('.dc-coil-card[data-dev="'+devIdx+'"][data-ch="'+channel+'"]');
if(!card)return false;
card.classList.remove('dc-coil-on','dc-coil-off');
card.classList.add(isOn?'dc-coil-on':'dc-coil-off');
var stEl=card.querySelector('.dc-coil-st');
if(stEl){
stEl.textContent=isOn?onText:offText;
}
return true;
},
_updatePwmUIFromSSE:function (devIdx,channel,value){
var dev=this._modbusDevices[devIdx];
if(!dev)return false;
var resolution=dev.pwmResolution||8;
var maxValue=(1<<resolution)-1;
var numValue=parseInt(value,10);
if(isNaN(numValue))numValue=0;
numValue=Math.max(0,Math.min (numValue,maxValue));
var states=this._dcPwmStates[devIdx]||[];
if(channel>=0){
states[channel]=numValue;
this._dcPwmStates[devIdx]=states;
}
var grid=document.getElementById('dc-pwm-grid-'+devIdx);
if(!grid)return false;
var slider=grid.querySelector('.dc-pwm-slider[data-ch="'+channel+'"]');
if(slider)slider.value=numValue;
var numInput=grid.querySelector('.dc-pwm-num[data-ch="'+channel+'"]');
if(numInput)numInput.value=numValue;
var pctSpan=grid.querySelector('.dc-pwm-pct[data-ch="'+channel+'"]');
if(pctSpan){
var pct=maxValue>0?Math.round(numValue / maxValue*100):0;
pctSpan.textContent=pct+'%';
}
return true;
},
_updatePidUIFromSSE:function (devIdx,paramName,value){
var dev=this._modbusDevices[devIdx];
if(!dev)return false;
var decimals=dev.pidDecimals||1;
var scaleFactor=Math.pow(10,decimals);
var numValue=parseFloat(value);
if(isNaN(numValue))numValue=0;
var rawValue=Math.round(numValue*scaleFactor);
var values=this._dcPidValues[devIdx]||{};
values[paramName]=rawValue;
this._dcPidValues[devIdx]=values;
var grid=document.getElementById('dc-pid-grid-'+devIdx);
if(!grid)return false;
var cards=grid.querySelectorAll('.dc-pid-card');
for(var i=0;i<cards.length;i++){
var card=cards[i];
var labelEl=card.querySelector('.dc-pid-label');
if(!labelEl)continue;
var labelText=(labelEl.textContent||'').toLowerCase();
var paramLabels={
'pv':'过程值 PV',
'sv':'设定值 SV',
'out':'输出 %',
'p':'P 比例',
'i':'I 积分',
'd':'D 微分'
};
var expectedLabel=(paramLabels[paramName]||paramName).toLowerCase();
if(labelText.indexOf(expectedLabel)!==-1||labelText.indexOf(paramName)!==-1){
var valueEl=card.querySelector('.dc-pid-value');
if(valueEl){
valueEl.textContent=numValue.toFixed(decimals);
}
var inputEl=card.querySelector('.dc-pid-input');
if(inputEl){
inputEl.value=numValue.toFixed(decimals);
}
break;
}
}
return true;
},
_dcUpdateMotorUIFromSSE:function (devIdx,value){
var dev=this._modbusDevices[devIdx];
if(!dev)return false;
var elRun=document.getElementById('dc-motor-run-'+devIdx);
var elDir=document.getElementById('dc-motor-dir-'+devIdx);
if(!elRun&&!elDir)return false;
var v=String(value||'').toLowerCase().trim();
var dirText='--';
var badgeClass='motor-run-idle';
var runText='--';
if(v==='forward'||v==='1'||v==='正转'){
dirText='← 正转';
badgeClass='motor-run-forward';
runText='正转中';
}else if(v==='reverse'||v==='-1'||v==='反转'){
dirText='→ 反转';
badgeClass='motor-run-reverse';
runText='反转中';
}else if(v==='stop'||v==='0'||v==='停止'){
dirText='停止';
badgeClass='motor-run-stopped';
runText='停止';
}
if(elDir)elDir.textContent=dirText;
if(elRun){
elRun.className='motor-run-badge '+badgeClass;
elRun.textContent=runText;
}
return true;
},
_handleSSEModbusData:function (data){
var self=this;
var tasks=this._modbusStatus&&this._modbusStatus.tasks?this._modbusStatus.tasks:[];
var hasMonitorUpdate=false;
var needsFullRefresh=false;
if(!Array.isArray(data)||data.length===0){
return ;
}
for(var i=0;i<data.length;i++){
var item=data[i]||{};
var sensorId=item.sensorId||item.id;
var value=item.value;
var matched=false;
if(!sensorId){
continue;
}
var parsedInfo=this._parseSensorId(sensorId);
if(parsedInfo){
var devIdx=parsedInfo.devIdx;
if(devIdx>=0){
if(self._dcDeviceOnline&&self._dcDeviceOnline[devIdx]===false){
self._dcUpdatePanelOnlineState(devIdx,true);
}
var deviceType=parsedInfo.type;
if(deviceType==='relay'){
if(this._updateCoilUIFromSSE(devIdx,parsedInfo.channel,value)){
matched=true;
continue;
}
}else if(deviceType==='pwm'){
if(this._updatePwmUIFromSSE(devIdx,parsedInfo.channel,value)){
matched=true;
continue;
}
}else if(deviceType==='pid'){
var pidParams=['pv','sv','out','p','i','d'];
var paramName=pidParams[parsedInfo.channel]||'pv';
if(this._updatePidUIFromSSE(devIdx,paramName,value)){
matched=true;
continue;
}
}else if(deviceType==='motor'){
if(this._dcUpdateMotorUIFromSSE(devIdx,value)){
matched=true;
continue;
}
}
}
if(!matched){
needsFullRefresh=true;
continue;
}
}
for(var ti=0;ti<tasks.length;ti++){
var task=tasks[ti];
var mappings=task&&task.mappings?task.mappings:[];
for(var mi=0;mi<mappings.length;mi++){
var mapping=mappings[mi];
if(mapping&&mapping.sensorId===sensorId){
matched=true;
if(!task.cachedData){
task.cachedData={values:[]};
}else if(!Array.isArray(task.cachedData.values)){
task.cachedData.values=[];
}
var valueNum=Number(value);
var scaleFactor=Number(mapping.scaleFactor||1);
if(isFinite(valueNum)&&scaleFactor){
task.cachedData.values[mapping.regOffset]=valueNum / scaleFactor;
}
break;
}
}
if(matched){
break;
}
}
var valueEl=document.querySelector('.dc-monitor-card[data-id="'+sensorId+'"] .dc-monitor-value');
if(valueEl){
valueEl.textContent=value===undefined||value===null||value===''?'--':String(value);
hasMonitorUpdate=true;
matched=true;
}
if(!matched){
needsFullRefresh=true;
}
}
if(needsFullRefresh){
this._dcAutoRefreshTimers=this._dcAutoRefreshTimers||{};
if(this._dcAutoRefreshTimers.sseDebounce){
clearTimeout(this._dcAutoRefreshTimers.sseDebounce);
}
this._dcAutoRefreshTimers.sseDebounce=setTimeout(function (){
self._dcAutoRefreshTimers.sseDebounce=null;
if(self.currentPage!=='device-control'){
return ;
}
self._dcInitModbusDeviceStates();
},100);
}
if(!needsFullRefresh&&!hasMonitorUpdate){
console.warn('[SSE] 未匹配到可更新的设备数据');
}
}
});
})();
(function (){
'use strict';
Object.assign(AppState,{
_dcGetCoilParams:function (devIdx){
var dev=this._modbusDevices[devIdx]||{};
return {
slaveAddress:dev.slaveAddress||1,
channelCount:dev.channelCount||2,
coilBase:dev.coilBase||0,
ncMode:!!dev.ncMode,
relayMode:(dev.controlProtocol===1)?'register':'coil'
};
},
_dcRefreshCoilStatus:function (devIdx){
var self=this;
var p=this._dcGetCoilParams(devIdx);
return apiGetSilent('/api/modbus/coil/status',{
slaveAddress:p.slaveAddress,channelCount:p.channelCount,
coilBase:p.coilBase,mode:p.relayMode
}).then(function (res){
if(res&&res.success&&res.data&&res.data.states){
self._dcCoilStates[devIdx]=res.data.states;
self._dcUpdateAllCoilUI(devIdx);
self._dcUpdatePanelOnlineState(devIdx,true);
}else{
self._dcUpdatePanelOnlineState(devIdx,false);
}
}).catch(function (){
if(!self._dcCoilStates[devIdx]){
self._dcCoilStates[devIdx]=new Array(p.channelCount).fill(false);
self._dcRerenderCoilGrid(devIdx);
}
self._dcUpdatePanelOnlineState(devIdx,false);
});
},
_dcRerenderCoilGrid:function (devIdx){
var grid=document.getElementById('dc-coil-grid-'+devIdx);
if(!grid)return ;
var p=this._dcGetCoilParams(devIdx);
var states=this._dcCoilStates[devIdx]||[];
grid.outerHTML=this._renderDcCoilGrid(devIdx,p.channelCount,states,p.ncMode);
},
_dcUpdatePanelOnlineState:function (devIdx,online){
this._dcDeviceOnline[devIdx]=online;
var panel=document.querySelector('.dc-modbus-device-panel[data-dev-idx="'+devIdx+'"]');
if(!panel)return ;
if(online){
panel.classList.remove('dc-offline');
var badge=panel.querySelector('.dc-offline-badge');
if(badge)badge.remove();
}else{
panel.classList.add('dc-offline');
var header=panel.querySelector('.dc-card-header');
if(header&&!header.querySelector('.dc-offline-badge')){
var span=document.createElement('span');
span.className='dc-offline-badge';
span.textContent='离线';
header.appendChild(span);
}
}
},
_dcUpdateSingleCoilUI:function (devIdx,ch){
var dev=this._modbusDevices[devIdx];
if(!dev)return false;
var ncMode=dev.ncMode||false;
var states=this._dcCoilStates[devIdx]||[];
var coilState=ch<states.length?states[ch]:false;
var isOn=ncMode?!coilState:coilState;
var card=document.querySelector('.dc-coil-card[data-dev="'+devIdx+'"][data-ch="'+ch+'"]');
if(!card){this._dcRerenderCoilGrid(devIdx);return false;}
card.classList.remove('dc-coil-on','dc-coil-off');
card.classList.add(isOn?'dc-coil-on':'dc-coil-off');
var stEl=card.querySelector('.dc-coil-st');
if(stEl)stEl.textContent=isOn
?'ON'
:'OFF';
return true;
},
_dcUpdateAllCoilUI:function (devIdx){
var dev=this._modbusDevices[devIdx];
if(!dev)return ;
var count=dev.channelCount||8;
var grid=document.getElementById('dc-coil-grid-'+devIdx);
if(!grid){this._dcRerenderCoilGrid(devIdx);return ;}
for(var ch=0;ch<count;ch++){
this._dcUpdateSingleCoilUI(devIdx,ch);
}
},
_dcToggleCoil:function (devIdx,ch,cardEl){
this._dcCancelInit();
var self=this;
var p=this._dcGetCoilParams(devIdx);
var states=this._dcCoilStates[devIdx]||[];
var prevState=(ch<states.length)?states[ch]:false;
if(ch<states.length)states[ch]=!prevState;
this._dcCoilStates[devIdx]=states;
this._dcUpdateSingleCoilUI(devIdx,ch);
if(cardEl){
cardEl.style.pointerEvents='none';
}
apiPostPriority('/api/modbus/coil/control',{
slaveAddress:p.slaveAddress,channel:ch,coilBase:p.coilBase,
action:'toggle',mode:p.relayMode
}).then(function (res){
if(res&&res.success&&res.data){
var st=self._dcCoilStates[devIdx]||[];
if(ch<st.length&&st[ch]!==res.data.state){
st[ch]=res.data.state;
self._dcCoilStates[devIdx]=st;
self._dcUpdateSingleCoilUI(devIdx,ch);
}
}else{
var st=self._dcCoilStates[devIdx]||[];
if(ch<st.length)st[ch]=prevState;
self._dcCoilStates[devIdx]=st;
self._dcUpdateSingleCoilUI(devIdx,ch);
Notification.error((res&&res.error)||'操作失败');
}
if(cardEl)cardEl.style.pointerEvents='';
self._dcCoilPending[devIdx+'_'+ch]=false;
},function (){
var st=self._dcCoilStates[devIdx]||[];
if(ch<st.length)st[ch]=prevState;
self._dcCoilStates[devIdx]=st;
self._dcUpdateSingleCoilUI(devIdx,ch);
Notification.error('操作失败');
if(cardEl)cardEl.style.pointerEvents='';
self._dcCoilPending[devIdx+'_'+ch]=false;
});
},
_dcBatchCoil:function (devIdx,action,btnEl){
this._dcCancelInit();
var self=this;
var p=this._dcGetCoilParams(devIdx);
var modbusAction=action;
if(p.ncMode){
if(action==='allOn')modbusAction='allOff';
else if(action==='allOff')modbusAction='allOn';
}
var prevStates=(this._dcCoilStates[devIdx]||[]).slice();
var targetVal;
if(action==='allOn')targetVal=true;
else if(action==='allOff')targetVal=false;
else targetVal=null;
var optimistic=prevStates.map(function (s){
return targetVal!==null?targetVal:!s;
});
this._dcCoilStates[devIdx]=optimistic;
this._dcUpdateAllCoilUI(devIdx);
apiPostPriority('/api/modbus/coil/batch',{
slaveAddress:p.slaveAddress,channelCount:p.channelCount,
coilBase:p.coilBase,action:modbusAction,mode:p.relayMode
}).then(function (res){
if(res&&res.success&&res.data&&res.data.states){
self._dcCoilStates[devIdx]=res.data.states;
self._dcUpdateAllCoilUI(devIdx);
}else{
self._dcCoilStates[devIdx]=prevStates;
self._dcUpdateAllCoilUI(devIdx);
Notification.error((res&&res.error)||'操作失败');
}
if(btnEl)btnEl.disabled=false;
self._dcBatchPending=false;
},function (){
self._dcCoilStates[devIdx]=prevStates;
self._dcUpdateAllCoilUI(devIdx);
Notification.error('操作失败');
if(btnEl)btnEl.disabled=false;
self._dcBatchPending=false;
});
},
_dcStartCoilDelay:function (devIdx,channel,delayUnits){
this._dcCancelInit();
var self=this;
var p=this._dcGetCoilParams(devIdx);
var dev=this._modbusDevices[devIdx]||{};
var params={
slaveAddress:p.slaveAddress,
channel:channel,
delayBase:0x0200,
delayUnits:delayUnits,
ncMode:!!dev.ncMode,
coilBase:p.coilBase,
mode:p.relayMode
};
apiPostPriority('/api/modbus/coil/delay',params).then(function (res){
if(res&&res.success){
window.Notification&&Notification.success(
'延时已启动 CH'+channel+' '+(delayUnits*0.1).toFixed(1)+'s'
);
}else{
window.Notification&&Notification.error(
(res&&res.error)||'延时启动失败'
);
}
}).catch(function (){
window.Notification&&Notification.error('延时启动失败');
});
},
_dcGetPwmParams:function (devIdx){
var dev=this._modbusDevices[devIdx]||{};
var res=dev.pwmResolution||8;
return {
slaveAddress:dev.slaveAddress||1,
channelCount:dev.channelCount||4,
regBase:dev.pwmRegBase||0,
resolution:res,
maxValue:(1<<res)-1
};
},
_dcRefreshPwmStatus:function (devIdx){
var self=this;
var p=this._dcGetPwmParams(devIdx);
return apiGetSilent('/api/modbus/register/read',{
slaveAddress:p.slaveAddress,
startAddress:p.regBase,
quantity:p.channelCount,
functionCode:3
}).then(function (res){
if(res&&res.success&&res.data&&res.data.values){
self._dcPwmStates[devIdx]=res.data.values;
self._dcRerenderPwmGrid(devIdx);
self._dcUpdatePanelOnlineState(devIdx,true);
}else{
self._dcUpdatePanelOnlineState(devIdx,false);
}
}).catch(function (){
if(!self._dcPwmStates[devIdx]){
self._dcPwmStates[devIdx]=new Array(p.channelCount).fill(0);
self._dcRerenderPwmGrid(devIdx);
}
self._dcUpdatePanelOnlineState(devIdx,false);
});
},
_dcRerenderPwmGrid:function (devIdx){
var grid=document.getElementById('dc-pwm-grid-'+devIdx);
if(!grid)return ;
var p=this._dcGetPwmParams(devIdx);
var states=this._dcPwmStates[devIdx]||[];
grid.outerHTML=this._renderDcPwmGrid(devIdx,p.channelCount,states,p.maxValue);
},
_dcOnPwmSliderInput:function (devIdx,ch,val){
var grid=document.getElementById('dc-pwm-grid-'+devIdx);
if(!grid)return ;
var numInput=grid.querySelector('.dc-pwm-num[data-ch="'+ch+'"]');
var pctSpan=grid.querySelector('.dc-pwm-pct[data-ch="'+ch+'"]');
var p=this._dcGetPwmParams(devIdx);
if(numInput)numInput.value=val;
if(pctSpan)pctSpan.textContent=(p.maxValue>0?Math.round(val / p.maxValue*100):0)+'%';
},
_dcSetPwmChannel:function (devIdx,ch,value){
this._dcCancelInit();
var self=this;
var p=this._dcGetPwmParams(devIdx);
value=Math.max(0,Math.min (value,p.maxValue));
var states=(this._dcPwmStates[devIdx]||[]).slice();
var prevVal=ch<states.length?states[ch]:0;
if(ch<states.length)states[ch]=value;
this._dcPwmStates[devIdx]=states;
this._dcRerenderPwmGrid(devIdx);
apiPostPriority('/api/modbus/register/write',{
slaveAddress:p.slaveAddress,
registerAddress:p.regBase+ch,
value:value
}).then(function (res){
if(res&&res.success){
Notification.success('操作成功');
}else{
var s=(self._dcPwmStates[devIdx]||[]).slice();
if(ch<s.length)s[ch]=prevVal;
self._dcPwmStates[devIdx]=s;
self._dcRerenderPwmGrid(devIdx);
Notification.error((res&&res.error)||'操作失败');
}
}).catch(function (){
var s=(self._dcPwmStates[devIdx]||[]).slice();
if(ch<s.length)s[ch]=prevVal;
self._dcPwmStates[devIdx]=s;
self._dcRerenderPwmGrid(devIdx);
Notification.error('操作失败');
});
},
_dcBatchPwm:function (devIdx,action){
this._dcCancelInit();
var self=this;
var p=this._dcGetPwmParams(devIdx);
var prevStates=(this._dcPwmStates[devIdx]||[]).slice();
var values=[];
var fillVal=action==='max'?p.maxValue:0;
for(var i=0;i<p.channelCount;i++)values.push(fillVal);
this._dcPwmStates[devIdx]=values.slice();
this._dcRerenderPwmGrid(devIdx);
apiPostPriority('/api/modbus/register/batch-write',{
slaveAddress:p.slaveAddress,
startAddress:p.regBase,
values:JSON.stringify(values)
}).then(function (res){
if(res&&res.success){
Notification.success('操作成功');
}else{
self._dcPwmStates[devIdx]=prevStates;
self._dcRerenderPwmGrid(devIdx);
Notification.error((res&&res.error)||'操作失败');
}
}).catch(function (){
self._dcPwmStates[devIdx]=prevStates;
self._dcRerenderPwmGrid(devIdx);
Notification.error('操作失败');
});
},
_dcGetPidParams:function (devIdx){
var dev=this._modbusDevices[devIdx]||{};
var pidA=dev.pidAddrs||[0,1,2,3,4,5];
var decimals=dev.pidDecimals||1;
return {
slaveAddress:dev.slaveAddress||1,
pvAddr:pidA[0]||0,svAddr:pidA[1]||1,outAddr:pidA[2]||2,
pAddr:pidA[3]||3,iAddr:pidA[4]||4,dAddr:pidA[5]||5,
decimals:decimals,
scaleFactor:Math.pow(10,decimals)
};
},
_dcGetMotorParams:function (devIdx){
var dev=this._modbusDevices[devIdx]||{};
return {
slaveAddress:dev.slaveAddress||1,
motorRegs:dev.motorRegs||[0,1,2,5,7],
motorDecimals:dev.motorDecimals||0
};
},
_dcRefreshPidStatus:function (devIdx){
var self=this;
var p=this._dcGetPidParams(devIdx);
if(!p.slaveAddress)return Promise.resolve();
var addrs=[p.pvAddr,p.svAddr,p.outAddr,p.pAddr,p.iAddr,p.dAddr];
var minAddr=Math.min .apply(null,addrs);
var maxAddr=Math.max.apply(null,addrs);
var quantity=maxAddr-minAddr+1;
if(quantity>125)return Promise.resolve();
return apiGetSilent('/api/modbus/register/read',{
slaveAddress:p.slaveAddress,startAddress:minAddr,
quantity:quantity,functionCode:3
}).then(function (res){
if(res&&res.success&&res.data&&res.data.values){
var vals=res.data.values;
self._dcPidValues[devIdx]={
pv:vals[p.pvAddr-minAddr],sv:vals[p.svAddr-minAddr],
out:vals[p.outAddr-minAddr],p:vals[p.pAddr-minAddr],
i:vals[p.iAddr-minAddr],d:vals[p.dAddr-minAddr]
};
self._dcRerenderPidGrid(devIdx);
self._dcUpdatePanelOnlineState(devIdx,true);
}else{
self._dcUpdatePanelOnlineState(devIdx,false);
}
}).catch(function (){
if(!self._dcPidValues[devIdx]){
self._dcPidValues[devIdx]={pv:0,sv:0,out:0,p:0,i:0,d:0};
self._dcRerenderPidGrid(devIdx);
}
self._dcUpdatePanelOnlineState(devIdx,false);
});
},
_dcRerenderPidGrid:function (devIdx){
var grid=document.getElementById('dc-pid-grid-'+devIdx);
if(!grid)return ;
var p=this._dcGetPidParams(devIdx);
grid.outerHTML=this._renderDcPidGrid(devIdx,p.scaleFactor,p.decimals);
},
_dcSetPidParam:function (devIdx,paramName,displayValue){
this._dcCancelInit();
var self=this;
var p=this._dcGetPidParams(devIdx);
var addrMap={sv:p.svAddr,p:p.pAddr,i:p.iAddr,d:p.dAddr};
var addr=addrMap[paramName];
if(addr===undefined)return ;
var rawValue=Math.round(parseFloat(displayValue)*p.scaleFactor);
if(isNaN(rawValue))return ;
apiPostPriority('/api/modbus/register/write',{
slaveAddress:p.slaveAddress,registerAddress:addr,value:rawValue
}).then(function (res){
if(res&&res.success){
var v=self._dcPidValues[devIdx]||{};
v[paramName]=rawValue;
self._dcPidValues[devIdx]=v;
self._dcRerenderPidGrid(devIdx);
Notification.success('操作成功');
}else{
Notification.error((res&&res.error)||'操作失败');
}
}).catch(function (){
Notification.error('操作失败');
});
},
_dcRefreshMotorStatus:function (devIdx){
var self=this;
var p=this._dcGetMotorParams(devIdx);
return apiPostSilent('/api/modbus/motor/control',{
slaveAddress:p.slaveAddress,action:'readStatus'
}).then(function (res){
if(res&&res.success&&res.data){
self._dcUpdateMotorRunUI(devIdx,res.data,p.motorDecimals);
self._dcUpdatePanelOnlineState(devIdx,true);
}else{
self._dcUpdatePanelOnlineState(devIdx,false);
}
}).catch(function (){
self._dcUpdatePanelOnlineState(devIdx,false);
});
},
_dcUpdateMotorRunUI:function (devIdx,data,decimals){
var sf=Math.pow(10,decimals||0);
var elSpeed=document.getElementById('dc-motor-speed-'+devIdx);
var elPulse=document.getElementById('dc-motor-pulse-'+devIdx);
var elDir=document.getElementById('dc-motor-dir-'+devIdx);
var elCount=document.getElementById('dc-motor-count-'+devIdx);
var elRun=document.getElementById('dc-motor-run-'+devIdx);
if(data.speed!==undefined&&elSpeed)elSpeed.textContent=(data.speed / sf).toFixed(decimals||0);
if(data.pulse!==undefined&&elPulse)elPulse.textContent=data.pulse;
if(elDir){
if(data.direction==='forward'||data.direction===1){
elDir.textContent='← 正转';
}else if(data.direction==='reverse'||data.direction===-1){
elDir.textContent='→ 反转';
}else{
elDir.textContent='停止';
}
}
if(data.count!==undefined&&elCount)elCount.textContent=data.count+' 次';
if(elRun){
var dir=data.direction||'';
elRun.className='motor-run-badge '+(dir==='forward'||dir===1?'motor-run-forward':dir==='reverse'||dir===-1?'motor-run-reverse':'motor-run-stopped');
elRun.textContent=(dir==='forward'||dir===1)?'正转中':(dir==='reverse'||dir===-1)?'反转中':'停止';
}
},
_dcMotorAction:function (devIdx,action){
this._dcCancelInit();
var self=this;
var p=this._dcGetMotorParams(devIdx);
apiPostSilentPriority('/api/modbus/motor/control',{
slaveAddress:p.slaveAddress,action:action
}).then(function (res){
if(res&&res.success){
Notification.success(action==='forward'?'正转指令已发送':action==='reverse'?'反转指令已发送':'停止指令已发送');
var elDir=document.getElementById('dc-motor-dir-'+devIdx);
var elRun=document.getElementById('dc-motor-run-'+devIdx);
if(elDir){
if(action==='forward'){
elDir.textContent='← 正转';
}else if(action==='reverse'){
elDir.textContent='→ 反转';
}else{
elDir.textContent='停止';
}
}
if(elRun){
elRun.className='motor-run-badge '+(action==='forward'?'motor-run-forward':action==='reverse'?'motor-run-reverse':'motor-run-stopped');
elRun.textContent=(action==='forward'?'正转中':action==='reverse'?'反转中':'停止');
}
}else{
Notification.error((res&&res.error)||'操作失败');
}
}).catch(function (){
Notification.error('操作失败');
});
},
_dcMotorSet:function (devIdx,param){
this._dcCancelInit();
var self=this;
var p=this._dcGetMotorParams(devIdx);
var inputId='dc-motor-'+param+'-in-'+devIdx;
var input=document.getElementById(inputId);
var value=parseInt(input?input.value:0)||0;
var action=param==='speed'?'setSpeed':'setPulse';
apiPostSilentPriority('/api/modbus/motor/control',{
slaveAddress:p.slaveAddress,action:action,value:value
}).then(function (res){
if(res&&res.success){
Notification.success(param==='speed'?'速度设置成功':'脉冲数设置成功');
}else{
Notification.error((res&&res.error)||'操作失败');
}
}).catch(function (){
Notification.error('操作失败');
});
}
});
})();