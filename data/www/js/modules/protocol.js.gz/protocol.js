(function (){
var basePath='/js/modules/protocol';
var scripts=[
'common.js',
'mqtt-config.js',
'modbus-config.js',
'protocol-config.js',
'modbus-control.js',
'modbus-relay-motor.js'
];
function loadScript(src){
return new Promise(function (resolve,reject){
var s=document.createElement('script');
s.src=basePath+'/'+src;
s.onload=resolve;
s.onerror=function (){
console.error('[protocol] Failed to load: '+src);
reject(new Error('Failed to load '+src));
};
document.head.appendChild(s);
});
}
(async function (){
for(var i=0;i<scripts.length;i++){
await loadScript(scripts[i]);
}
if(AppState&&typeof AppState.registerModule==='function'){
AppState.registerModule('protocol',{});
}
if(typeof AppState.setupProtocolEvents==='function'){
AppState.setupProtocolEvents();
}
document.dispatchEvent(new CustomEvent('protocol-modules-loaded'));
})();
})();