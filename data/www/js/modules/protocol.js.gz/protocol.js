(function (){
Object.assign(AppState,{
_protocolConfig:null,
_masterTasks:[],
_modbusRtuLoaded:false,
_coilStates:[],
_coilAutoRefreshTimer:null,
_coilAutoRefreshErrors:0,
_modbusDevices:[],
_deviceCoilCache:{},
_devicePwmCache:{},
_pwmStates:[],
_pidValues:{},
_pidAutoRefreshTimer:null,
_pidAutoRefreshErrors:0,
_devicePidCache:{},
_activeDeviceIdx:-1,
_editingDeviceIdx:-1,
_editingTaskIdx:-1,
_currentMappingTaskIdx:-1,
_currentMappings:[],
_masterStatusTimer:null,
_uartPeripherals:[],
_mqttStatusTimer:null,
_modbusCtrlOffline:false,
_protocolEventsBound:false,
_modbusControlModuleLoading:false,
_modbusControlPendingIndex:-1,
_modbusControlPendingButton:null,
_modbusControlLoadTimer:null,
setupProtocolEvents(){
var boundAny=false;
var bindOnce=function (el,eventName,flagName,handler){
if(!el||el[flagName])return false;
el.addEventListener(eventName,handler);
el[flagName]=true;
return true;
};
var allDevicesBody=document.getElementById('all-devices-body');
var modbusDevicesBody=document.getElementById('modbus-devices-body');
if(false&&!allDevicesBody&&!modbusDevicesBody){
return ;
}
var publishTopics=document.getElementById('mqtt-publish-topics');
boundAny=bindOnce(publishTopics,'click','__fbProtocolPublishTopicClick',(event)=>this._handlePublishTopicClick(event))||boundAny;
var subscribeTopics=document.getElementById('mqtt-subscribe-topics');
boundAny=bindOnce(subscribeTopics,'click','__fbProtocolSubscribeTopicClick',(event)=>this._handleSubscribeTopicClick(event))||boundAny;
var mappingTableBody=document.getElementById('mapping-table-body');
boundAny=bindOnce(mappingTableBody,'click','__fbProtocolMappingClick',(event)=>this._handleMappingTableClick(event))||boundAny;
boundAny=bindOnce(allDevicesBody,'click','__fbProtocolActionClick',(event)=>this._handleProtocolActionClick(event))||boundAny;
boundAny=bindOnce(modbusDevicesBody,'click','__fbProtocolActionClick',(event)=>this._handleProtocolActionClick(event))||boundAny;
var pwmGrid=document.getElementById('pwm-channel-grid');
boundAny=bindOnce(pwmGrid,'input','__fbProtocolPwmInput',(event)=>this._handlePwmGridInput(event))||boundAny;
boundAny=bindOnce(pwmGrid,'change','__fbProtocolPwmChange',(event)=>this._handlePwmGridChange(event))||boundAny;
var pidGrid=document.getElementById('pid-data-grid');
boundAny=bindOnce(pidGrid,'click','__fbProtocolPidClick',(event)=>this._handlePidGridClick(event))||boundAny;
var coilGrid=document.getElementById('coil-status-grid');
boundAny=bindOnce(coilGrid,'click','__fbProtocolCoilClick',(event)=>this._handleCoilGridClick(event))||boundAny;
var mqttScheme=document.getElementById('mqtt-scheme');
boundAny=bindOnce(mqttScheme,'change','__fbMqttSchemeChange',(event)=>{
var portEl=document.getElementById('mqtt-port');
if(!portEl)return ;
var newScheme=event.target.value;
var currentPort=parseInt(portEl.value,10);
if(newScheme==='mqtts'&&(currentPort===1883||!portEl.value)){
portEl.value=8883;
}else if(newScheme==='mqtt'&&(currentPort===8883||!portEl.value)){
portEl.value=1883;
}
})||boundAny;
if(boundAny)this._protocolEventsBound=true;
},
_handlePublishTopicClick(event){
var deleteBtn=event.target.closest('.mqtt-topic-delete');
if(!deleteBtn)return ;
var info=this._getProtocolIndexedItem(deleteBtn,'.mqtt-topic-item');
if(info&&info.index>=0)this.deleteMqttPublishTopic(info.index);
},
_handleSubscribeTopicClick(event){
var deleteBtn=event.target.closest('.mqtt-topic-delete');
if(!deleteBtn)return ;
var info=this._getProtocolIndexedItem(deleteBtn,'.mqtt-topic-item');
if(info&&info.index>=0)this.deleteMqttSubscribeTopic(info.index);
},
_handleMappingTableClick(event){
var button=event.target.closest('.protocol-mapping-remove');
if(!button)return ;
var index=parseInt(button.getAttribute('data-index'),10);
if(!isNaN(index))this.removeMapping(index);
},
_handleProtocolActionClick(event){
var button=event.target.closest('.protocol-action-btn[data-protocol-action]');
if(!button)return ;
var index=parseInt(button.getAttribute('data-index'),10);
var action=button.getAttribute('data-protocol-action');
var source=button.getAttribute('data-source')||'';
if(isNaN(index)||!action)return ;
if(action!=='open-control-modal'&&!this.guardDeveloperModeAction())return ;
if(action==='edit-device')this._editDevice(source,index);
else if(action==='open-mapping')this.openMappingModal(index);
else if(action==='delete-device')this._deleteDevice(source,index);
else if(action==='open-edit-modal')this._openEditModal(index);
else if(action==='open-control-modal')this._openModbusControlModal(index,button);
else if(action==='remove-device')this._removeDevice(index);
},
_setProtocolActionLoading(button,loading){
if(!button)return ;
if(loading){
if(!button.dataset.fbOriginalText)button.dataset.fbOriginalText=button.textContent||'';
button.disabled=true;
button.textContent='加载中...';
return ;
}
if(button.dataset.fbOriginalText){
button.textContent=button.dataset.fbOriginalText;
delete button.dataset.fbOriginalText;
}
button.disabled=false;
},
_openModbusControlModal(index,button){
if(typeof this._openCtrlModal==='function'){
this._openCtrlModal(index);
return ;
}
if(typeof ModuleLoader==='undefined'||typeof ModuleLoader.loadModule!=='function'){
Notification.error('加载失败，请刷新重试');
return ;
}
if(this._modbusControlPendingButton&&this._modbusControlPendingButton!==button){
this._setProtocolActionLoading(this._modbusControlPendingButton,false);
}
this._modbusControlPendingIndex=index;
this._modbusControlPendingButton=button||this._modbusControlPendingButton;
this._setProtocolActionLoading(this._modbusControlPendingButton,true);
if(this._modbusControlModuleLoading)return ;
var self=this;
this._modbusControlModuleLoading=true;
if(this._modbusControlLoadTimer)clearTimeout(this._modbusControlLoadTimer);
this._modbusControlLoadTimer=setTimeout(function (){
if(!self._modbusControlModuleLoading)return ;
self._modbusControlModuleLoading=false;
self._setProtocolActionLoading(self._modbusControlPendingButton,false);
self._modbusControlPendingButton=null;
self._modbusControlPendingIndex=-1;
Notification.error('加载失败，请刷新重试');
},20000);
ModuleLoader.loadModule('protocol-modbus-control',function (){
var targetIndex=self._modbusControlPendingIndex;
var targetButton=self._modbusControlPendingButton;
self._modbusControlModuleLoading=false;
if(self._modbusControlLoadTimer){
clearTimeout(self._modbusControlLoadTimer);
self._modbusControlLoadTimer=null;
}
self._modbusControlPendingIndex=-1;
self._modbusControlPendingButton=null;
self._setProtocolActionLoading(targetButton,false);
if(typeof self.setupProtocolEvents==='function')self.setupProtocolEvents();
if(typeof self._openCtrlModal==='function'&&targetIndex>=0){
self._openCtrlModal(targetIndex);
}else{
Notification.error('加载失败，请刷新重试');
}
});
},
_handlePwmGridInput(event){
var target=event.target;
if(!target||!target.classList.contains('pwm-slider'))return ;
var ch=parseInt(target.getAttribute('data-ch'),10);
if(!isNaN(ch))this._onPwmSliderInput(ch,target.value);
},
_handlePwmGridChange(event){
var target=event.target;
if(!target)return ;
var ch=parseInt(target.getAttribute('data-ch'),10);
if(isNaN(ch))return ;
if(target.classList.contains('pwm-slider'))this._onPwmSliderChange(ch,target.value);
else if(target.classList.contains('pwm-num-input'))this._onPwmNumChange(ch,target.value);
},
_handlePidGridClick(event){
var button=event.target.closest('.pid-set-btn');
if(!button)return ;
var paramName=button.getAttribute('data-param');
var input=button.parentNode?button.parentNode.querySelector('.pid-input'):null;
if(paramName&&input)this._onPidInputChange(paramName,input.value);
},
_handleCoilGridClick(event){
if(typeof this._isCtrlModalOffline==='function'&&this._isCtrlModalOffline())return ;
var card=event.target.closest('.coil-card');
if(!card)return ;
var ch=parseInt(card.getAttribute('data-ch'),10);
if(!isNaN(ch))this.toggleCoil(ch);
},
_setProtocolFragmentLoading(tabId){
var fragInfo=this._protocolFragmentMap&&this._protocolFragmentMap[tabId];
if(!fragInfo)return ;
var container=document.getElementById(fragInfo.container);
if(!container||container.querySelector('form'))return ;
var title='加载中...';
container.innerHTML='<div class="fb-loading-placeholder protocol-loading-placeholder">'+
'<div class="fb-loading-placeholder-title">'+title+'</div>'+
'</div>';
},
_setProtocolFragmentError(tabId,message){
var fragInfo=this._protocolFragmentMap&&this._protocolFragmentMap[tabId];
if(!fragInfo)return ;
var container=document.getElementById(fragInfo.container);
if(!container||container.querySelector('form'))return ;
container.innerHTML='<div class="message message-error">'+
escapeHtml(message||'加载失败，请刷新重试')+
'</div>';
},
_renderProtocolEmptyRow(colspan,text){
return '<tr><td colspan="'+colspan+'" class="u-empty-cell">'+(text||'')+'</td></tr>';
},
_renderProtocolStatus(enabled){
const isEnabled=enabled!==false;
return '<span class="'+(isEnabled?'protocol-status-on':'protocol-status-off')+'">'+
(isEnabled?'ON':'OFF')+'</span>';
},
_getProtocolBadgeTone(type){
const tones={
sensor:'protocol-badge--sensor',
relay:'protocol-badge--relay',
pwm:'protocol-badge--pwm',
pid:'protocol-badge--pid'
};
return tones[type]||'protocol-badge--sensor';
},
_renderProtocolBadge(type,label){
return '<span class="protocol-badge '+this._getProtocolBadgeTone(type)+'">'+
(label||type||'-')+'</span>';
},
_renderProtocolActionButton(label,tone,action,index,source){
var attrs='data-protocol-action="'+action+'"';
if(index!==undefined&&index!==null)attrs+=' data-index="'+index+'"';
if(source)attrs+=' data-source="'+source+'"';
var locked=action!=='open-control-modal'&&!this.isDeveloperModeEnabled();
if(locked)attrs+=' disabled title="'+escapeHtml(this.getDeveloperModeDisabledText())+'"';
return '<button type="button" class="fb-btn fb-btn-sm protocol-action-btn protocol-action-btn--'+tone+
(locked?' dev-mode-locked':'')+'" '+attrs+'>'+label+'</button>';
},
_renderProtocolActionCell(buttons){
return '<td class="protocol-action-cell">'+buttons.join ('')+'</td>';
},
_getProtocolIndexedItem(ref,itemSelector){
if(!ref||typeof ref.closest!=='function')return null;
var item=ref.closest(itemSelector);
if(!item)return null;
var index=parseInt(item.dataset.index,10);
return {
item:item,
index:isNaN(index)?-1:index
};
},
_renderMqttQosOptions(selectedQos){
return [
'<option value="0"'+(selectedQos===0?' selected':'')+'>0</option>',
'<option value="1"'+(selectedQos===1?' selected':'')+'>1</option>',
'<option value="2"'+(selectedQos===2?' selected':'')+'>2</option>'
].join ('');
},
_getProtocolControlDeviceInfo(device){
var deviceType=device.deviceType||'relay';
var info=(device.channelCount||2)+'ch';
if(deviceType==='relay'){
info+=' '+(device.controlProtocol===1?'Reg':'Coil')+'@'+(device.coilBase||0);
}else if(deviceType==='pwm'){
info+=' Reg@'+(device.pwmRegBase||0)+' '+(device.pwmResolution||8)+'bit';
}else if(deviceType==='pid'){
info+=' PV@'+((device.pidAddrs&&device.pidAddrs[0])||0);
}
if(device.sensorId)info+=' id:'+device.sensorId;
return info;
},
_renderAllDeviceSensorRow(task,index,fcNames,typeLabels){
var label=task.name||task.label||('Slave '+(task.slaveAddress||1));
var info=(fcNames[task.functionCode]||'FC03')+' @'+(task.startAddress||0)+' x'+(task.quantity||10);
var mappingCount=(task.mappings&&task.mappings.length)||0;
if(mappingCount>0)info+=' ['+mappingCount+'映射]';
var actions=[
this._renderProtocolActionButton('编辑','primary','edit-device',index,'sensor'),
this._renderProtocolActionButton('映射','warning','open-mapping',index),
this._renderProtocolActionButton('删除','danger','delete-device',index,'sensor')
];
return '<tr>'+
'<td>'+escapeHtml(label)+'</td>'+
'<td>'+this._renderProtocolBadge('sensor',typeLabels.sensor)+'</td>'+
'<td>'+(task.slaveAddress||1)+'</td>'+
'<td><small>'+escapeHtml(info)+'</small></td>'+
'<td>'+this._renderProtocolStatus(task.enabled)+'</td>'+
this._renderProtocolActionCell(actions)+
'</tr>';
},
_renderAllDeviceControlRow(device,index,typeLabels){
var deviceType=device.deviceType||'relay';
return '<tr>'+
'<td>'+escapeHtml(device.name||'-')+'</td>'+
'<td>'+this._renderProtocolBadge(deviceType,typeLabels[deviceType]||deviceType)+'</td>'+
'<td>'+(device.slaveAddress||1)+'</td>'+
'<td><small>'+escapeHtml(this._getProtocolControlDeviceInfo(device))+'</small></td>'+
'<td>'+this._renderProtocolStatus(device.enabled)+'</td>'+
this._renderProtocolActionCell([
this._renderProtocolActionButton('编辑','primary','edit-device',index,'control'),
this._renderProtocolActionButton('控制','warning','open-control-modal',index),
this._renderProtocolActionButton('删除','danger','delete-device',index,'control')
])+
'</tr>';
},
_renderModbusDeviceRow(device,index,typeLabels,protocolLabels){
var deviceType=device.deviceType||'relay';
var controlProtocol=device.controlProtocol||0;
return '<tr>'+
'<td>'+escapeHtml(device.name||'-')+'</td>'+
'<td>'+this._renderProtocolBadge(deviceType,typeLabels[deviceType]||deviceType)+'</td>'+
'<td>'+(device.slaveAddress||1)+'</td>'+
'<td>'+(device.channelCount||2)+'</td>'+
'<td>'+(device.coilBase||0)+'</td>'+
'<td>'+(protocolLabels[controlProtocol]||'Coil')+'</td>'+
'<td>'+(device.ncMode?'ON':'-')+'</td>'+
this._renderProtocolActionCell([
this._renderProtocolActionButton('编辑','primary','open-edit-modal',index),
this._renderProtocolActionButton('控制','warning','open-control-modal',index),
this._renderProtocolActionButton('删除','danger','remove-device',index)
])+
'</tr>';
},
_getProtocolName(formId){
var map={
'modbus-rtu-form':'Modbus RTU',
'mqtt-form':'MQTT'
};
return map[formId]||'Protocol';
}
});
})();
(function (){
Object.assign(AppState,{
_mqttTopicTypeOptions(selected){
const types=[
{value:0,label:'数据上报'},
{value:1,label:'数据下发'},
{value:2,label:'设备信息'},
{value:3,label:'实时监测'},
{value:4,label:'设备事件'},
{value:5,label:'OTA升级'},
{value:6,label:'OTA二进制'},
{value:7,label:'NTP时间同步'}
];
return types.map(t=>
`<option value="${t.value}" ${Number(selected)===t.value?'selected':''}>${t.label}</option>`
).join ('');
},
_loadMqttPublishTopics(topics){
const container=document.getElementById('mqtt-publish-topics');
if(!container)return ;
container.innerHTML='';
if(!topics||topics.length===0){
topics=[{topic:'',qos:0,retain :false,enabled:true,autoPrefix:false,topicType:0}];
}
topics.forEach((topic,index)=>{
this._createMqttPublishTopicElement(topic,index);
});
},
_buildMqttTopicItemHtml(index,topicData,options){
const topicType=topicData.topicType??options.defaultTopicType;
const qos=topicData.qos??0;
const toggleHtml=options.toggles.map((toggle)=>{
const checked=toggle.checked?' checked':'';
return '<label class="fb-checkbox">'+
'<input type="checkbox" class="'+toggle.inputClass+'"'+checked+'> '+toggle.label+
'</label>';
}).join ('');
return `
<span class="${options.indexClass}">${index+1}</span>
<button type="button" class="mqtt-topic-delete">删除</button>
<div class="config-form-grid">
<div class="fb-form-group">
<label>${options.topicLabel}</label>
<input type="text" class="${options.topicInputClass}" value="${topicData.topic || ''}" placeholder="/topic/path">
</div>
<div class="fb-form-group">
<label>${options.topicTypeLabel}</label>
<select class="${options.topicTypeInputClass}">
${this._mqttTopicTypeOptions(topicType)}
</select>
</div>
<div class="fb-form-group">
<label>${options.qosLabel}</label>
<select class="${options.qosInputClass}">
${this._renderMqttQosOptions(qos)}
</select>
</div>
<div class="fb-form-group mqtt-topic-toggle-row">
${toggleHtml}
</div>
</div>
`;
},
_createMqttTopicElement(containerId,topicData,index,options){
const container=document.getElementById(containerId);
if(!container)return ;
const div=document.createElement('div');
div.className=options.itemClass;
div.dataset.index=index;
div.innerHTML=this._buildMqttTopicItemHtml(index,topicData,options);
container.appendChild(div);
},
_reindexMqttTopicItems(container){
const remainingItems=container.querySelectorAll('.mqtt-topic-item');
remainingItems.forEach((item,idx)=>{
item.dataset.index=idx;
const indexSpan=item.querySelector('.mqtt-topic-index');
if(indexSpan)indexSpan.textContent=idx+1;
});
return remainingItems.length;
},
_collectMqttTopics(containerId,options){
const container=document.getElementById(containerId);
if(!container)return [];
const topics=[];
const items=container.querySelectorAll('.mqtt-topic-item');
items.forEach((item)=>{
const topicInput=item.querySelector('.'+options.topicInputClass);
const qosInput=item.querySelector('.'+options.qosInputClass);
const enabledInput=item.querySelector('.'+options.enabledInputClass);
const autoPrefixInput=item.querySelector('.'+options.autoPrefixInputClass);
const topicTypeInput=item.querySelector('.'+options.topicTypeInputClass);
if(!topicInput)return ;
const topic={
topic:topicInput.value||'',
qos:parseInt(qosInput?.value||'0'),
enabled:enabledInput?.checked!==false,
autoPrefix:autoPrefixInput?.checked||false,
topicType:parseInt(topicTypeInput?.value||String(options.defaultTopicType))
};
if(options.retainInputClass){
topic.retain =item.querySelector('.'+options.retainInputClass)?.checked||false;
}
topics.push(topic);
});
return topics;
},
_getMqttPublishTopicOptions(topicData){
return {
itemClass:'mqtt-topic-item',
indexClass:'mqtt-topic-index',
topicLabel:'发布主题',
topicInputClass:'mqtt-topic-input',
topicTypeLabel:'主题类型',
topicTypeInputClass:'mqtt-topic-type-input',
qosLabel:'发布QoS',
qosInputClass:'mqtt-qos-input',
enabledInputClass:'mqtt-enabled-input',
autoPrefixInputClass:'mqtt-autoprefix-input',
retainInputClass:'mqtt-retain-input',
defaultTopicType:0,
toggles:[
{inputClass:'mqtt-retain-input',checked:topicData.retain ===true,label:'保留消息'},
{inputClass:'mqtt-enabled-input',checked:topicData.enabled!==false,label:'启用'},
{inputClass:'mqtt-autoprefix-input',checked:topicData.autoPrefix===true,label:'自动前缀'}
]
};
},
_getMqttSubscribeTopicOptions(topicData){
return {
itemClass:'mqtt-topic-item mqtt-topic-item-sub',
indexClass:'mqtt-topic-index mqtt-topic-index-sub',
topicLabel:'订阅主题',
topicInputClass:'mqtt-sub-topic-input',
topicTypeLabel:'主题类型',
topicTypeInputClass:'mqtt-sub-topic-type-input',
qosLabel:'订阅QoS',
qosInputClass:'mqtt-sub-qos-input',
enabledInputClass:'mqtt-sub-enabled-input',
autoPrefixInputClass:'mqtt-sub-autoprefix-input',
defaultTopicType:1,
toggles:[
{inputClass:'mqtt-sub-enabled-input',checked:topicData.enabled!==false,label:'启用'},
{inputClass:'mqtt-sub-autoprefix-input',checked:topicData.autoPrefix===true,label:'自动前缀'}
]
};
},
_createMqttPublishTopicElement(topicData,index){
this._createMqttTopicElement('mqtt-publish-topics',topicData,index,this._getMqttPublishTopicOptions(topicData));
},
addMqttPublishTopic(){
const container=document.getElementById('mqtt-publish-topics');
if(!container)return ;
const index=container.children.length;
this._createMqttPublishTopicElement({topic:'',qos:0,retain :false,enabled:true,autoPrefix:false,topicType:0},index);
},
deleteMqttPublishTopic(index){
const container=document.getElementById('mqtt-publish-topics');
if(!container)return ;
const items=container.querySelectorAll('.mqtt-topic-item');
if(items[index]){items[index].remove();}
if(this._reindexMqttTopicItems(container)===0){
this._createMqttPublishTopicElement({topic:'',qos:0,retain :false,enabled:true,autoPrefix:false,topicType:0},0);
}
},
_collectMqttPublishTopics(){
return this._collectMqttTopics('mqtt-publish-topics',this._getMqttPublishTopicOptions({}));
},
_loadMqttSubscribeTopics(topics){
const container=document.getElementById('mqtt-subscribe-topics');
if(!container)return ;
container.innerHTML='';
if(!topics||topics.length===0){
topics=[{topic:'',qos:0,enabled:true,autoPrefix:false,topicType:1}];
}
topics.forEach((topic,index)=>{
this._createMqttSubscribeTopicElement(topic,index);
});
},
_createMqttSubscribeTopicElement(topicData,index){
this._createMqttTopicElement('mqtt-subscribe-topics',topicData,index,this._getMqttSubscribeTopicOptions(topicData));
},
addMqttSubscribeTopic(){
const container=document.getElementById('mqtt-subscribe-topics');
if(!container)return ;
const index=container.children.length;
this._createMqttSubscribeTopicElement({topic:'',qos:0,enabled:true,autoPrefix:false,topicType:1},index);
},
deleteMqttSubscribeTopic(index){
const container=document.getElementById('mqtt-subscribe-topics');
if(!container)return ;
const items=container.querySelectorAll('.mqtt-topic-item');
if(items[index]){items[index].remove();}
if(this._reindexMqttTopicItems(container)===0){
this._createMqttSubscribeTopicElement({topic:'',qos:0,enabled:true,autoPrefix:false,topicType:1},0);
}
},
_collectMqttSubscribeTopics(){
return this._collectMqttTopics('mqtt-subscribe-topics',this._getMqttSubscribeTopicOptions({}));
},
testMqttConnection(){
const resultEl=document.getElementById('mqtt-test-result');
const btn=document.querySelector('#mqtt-form .mqtt-test-btn');
const server=document.getElementById('mqtt-broker')?.value||'';
const port=document.getElementById('mqtt-port')?.value||'1883';
const scheme=document.getElementById('mqtt-scheme')?.value||'mqtt';
const clientId=document.getElementById('mqtt-client-id')?.value||'';
const username=document.getElementById('mqtt-username')?.value||'';
const password=document.getElementById('mqtt-password')?.value||'';
const authCode=document.getElementById('mqtt-auth-code')?.value||'';
const mqttSecret=document.getElementById('mqtt-secret')?.value||'';
const authType=document.getElementById('mqtt-auth-type')?.value||'0';
if(!server){
if(resultEl){resultEl.textContent='请先填写Broker地址';resultEl.style.color='#f56c6c';}
return ;
}
this._clearMqttDeferredTestTimer();
if(clientId){
if(authType==='0'&&!clientId.startsWith('S&')){
if(resultEl){resultEl.textContent="提示: FastBee平台简单认证模式下，客户端ID通常以'S&'开头（格式: S&设备编号&产品ID&用户ID）";resultEl.style.color='#e6a23c';}
}
if(authType==='1'&&!clientId.startsWith('E&')){
if(resultEl){resultEl.textContent="提示: FastBee平台加密认证模式下，客户端ID通常以'E&'开头（格式: E&设备编号&产品ID&用户ID）";resultEl.style.color='#e6a23c';}
}
}
if(btn){btn.disabled=true;btn.textContent='测试中...';btn.classList.remove('mqtt-test-success','mqtt-test-fail');}
if(resultEl){resultEl.textContent='测试中...';resultEl.style.color='#909399';}
apiMqttTest({server,port,scheme,clientId,username,password,authCode,authType,mqttSecret})
.then(res=>{
if(res&&res.success&&res.data){
if(res.data.deferred){
if(resultEl){resultEl.textContent='MQTT 正在异步连接中，请关注状态变化...';resultEl.style.color='#e6a23c';}
if(btn)btn.classList.add('mqtt-test-success');
this._scheduleMqttDeferredStatusPoll(0,btn,resultEl);
return ;
}
if(res.data.connected){
if(res.data.alreadyConnected){
if(resultEl){resultEl.textContent='连接正常，无需重新测试';resultEl.style.color='#67c23a';}
if(btn)btn.classList.add('mqtt-test-success');
var badge=document.getElementById('mqtt-status-badge');
if(badge){badge.className='mqtt-status-badge mqtt-status-online';badge.textContent='已连接';}
}else if(res.data.realConnected){
if(resultEl){resultEl.textContent='凭证验证成功，MQTT 正在连接...';resultEl.style.color='#67c23a';}
if(btn)btn.classList.add('mqtt-test-success');
var badge=document.getElementById('mqtt-status-badge');
if(badge){badge.className='mqtt-status-badge mqtt-status-connecting';badge.textContent='连接中';}
this._startMqttStatusPolling({initialDelayMs:3000});
}else{
if(resultEl){resultEl.textContent='凭证验证通过，MQTT 将在后台自动连接';resultEl.style.color='#67c23a';}
if(btn)btn.classList.add('mqtt-test-success');
this._startMqttStatusPolling({initialDelayMs:3000});
}
}else{
const errCode=res.data.error||'Unknown';
let errMsg=this._mqttErrorCodeToText(errCode);
if(authType==='1'&&String(errCode)==='4'){
const hint='AES认证失败，请检查用户名、密码、产品密钥(mqttSecret)和授权码(authCode)是否与平台一致';
errMsg=errMsg+' - '+hint;
}
if(resultEl){resultEl.textContent='连接失败: '+errMsg;resultEl.style.color='#f56c6c';}
if(btn)btn.classList.add('mqtt-test-fail');
}
}else{
if(resultEl){resultEl.textContent='测试请求失败';resultEl.style.color='#f56c6c';}
if(btn)btn.classList.add('mqtt-test-fail');
}
})
.catch(err=>{
console.error('MQTT test failed:',err);
if(resultEl){
const isTimeout=err&&(err.name==='AbortError'||(err.message&&err.message.includes('abort')));
const isUnauthorized=err&&err.status===401;
const isOverload=err&&(err.status===503||err.status===429);
const isNetworkErr=err&&(err instanceof TypeError||(err.message&&err.message.includes('fetch')));
if(isOverload){resultEl.textContent='设备忙，请稍后再试';}
else if(isTimeout){resultEl.textContent='测试超时，请检查Broker地址是否正确';}
else if(isNetworkErr){resultEl.textContent='请求超时，设备可能MQTT连接中，请10秒后重试';}
else if(isUnauthorized){resultEl.textContent='测试请求失败，请稍后重试';}
else{
const errData=err&&err.data;
const errMsg=(errData&&errData.error)?errData.error:'测试请求失败';
resultEl.textContent=errMsg;
}
resultEl.style.color='#f56c6c';
}
if(btn)btn.classList.add('mqtt-test-fail');
})
.finally(()=>{
if(btn){btn.disabled=false;btn.textContent='测试连接';}
setTimeout(()=>this._loadMqttStatus(),2500);
setTimeout(()=>{if(btn)btn.classList.remove('mqtt-test-success','mqtt-test-fail');},3000);
});
},
disconnectMqtt(){
const btn=document.querySelector('#mqtt-form .mqtt-disconnect-btn');
if(btn){btn.disabled=true;btn.textContent='断开中...';}
this._clearMqttDeferredTestTimer();
this._stopMqttStatusPolling();
apiPostSilent('/api/mqtt/disconnect',{})
.then(res=>{
if(res&&res.success){
Notification.success('MQTT已断开连接','MQTT');
const badge=document.getElementById('mqtt-status-badge');
if(badge){badge.className='mqtt-status-badge mqtt-status-offline';badge.textContent='未连接';}
const resultEl=document.getElementById('mqtt-test-result');
if(resultEl){resultEl.textContent='MQTT已断开连接';resultEl.style.color='#909399';}
}else{
Notification.error('MQTT断开失败','MQTT');
this._startMqttStatusPolling();
}
})
.catch(err=>{
console.error('MQTT disconnect failed:',err);
Notification.error('MQTT断开失败','MQTT');
this._startMqttStatusPolling();
})
.finally(()=>{
if(btn){btn.disabled=false;btn.textContent='断开连接';}
setTimeout(()=>this._loadMqttStatus(),500);
});
},
mqttNtpSync(){
const btn=document.querySelector('#mqtt-form .mqtt-ntp-sync-btn');
const resultEl=document.getElementById('mqtt-test-result');
if(btn){btn.disabled=true;btn.textContent='同步中...';}
if(resultEl)resultEl.textContent='';
apiPost('/api/mqtt/ntp-sync',{})
.then(res=>{
if(res&&res.success){
Notification.success('MQTT时间同步请求已发送','MQTT');
if(resultEl){resultEl.style.color='#67c23a';resultEl.textContent='MQTT时间同步请求已发送';}
}else{
const errMsg=(res&&res.error)?res.error:'MQTT时间同步失败';
Notification.error(errMsg,'MQTT');
if(resultEl){resultEl.style.color='#f56c6c';resultEl.textContent=errMsg;}
}
})
.catch(err=>{
console.error('MQTT NTP sync failed:',err);
Notification.error('MQTT时间同步失败','MQTT');
if(resultEl){resultEl.style.color='#f56c6c';resultEl.textContent='MQTT时间同步失败';}
})
.finally(()=>{
if(btn){btn.disabled=false;btn.textContent='MQTT时间同步';}
setTimeout(()=>{if(resultEl)resultEl.textContent='';},3000);
});
},
_mqttErrorCodeToText(code){
const map={
'-4':'MQTT_CONNECTION_TIMEOUT','-3':'MQTT_CONNECTION_LOST',
'-2':'MQTT_CONNECT_FAILED','-1':'MQTT_DISCONNECTED',
'1':'MQTT_BAD_PROTOCOL','2':'MQTT_BAD_CLIENT_ID',
'3':'MQTT_UNAVAILABLE','4':'MQTT_BAD_CREDENTIALS','5':'MQTT_UNAUTHORIZED'
};
return map[String(code)]||('Error '+code);
},
_clearMqttDeferredTestTimer(){
if(this._mqttDeferredTestTimer){
clearTimeout(this._mqttDeferredTestTimer);
this._mqttDeferredTestTimer=null;
}
},
_getMqttDeferredPollIntervalMs(){
if(typeof apiGetPressureAwareInterval==='function'){
return apiGetPressureAwareInterval('mqttDeferred',2000);
}
return 2000;
},
_scheduleMqttDeferredStatusPoll(pollCount,btn,resultEl){
var self=this;
this._clearMqttDeferredTestTimer();
this._mqttDeferredTestTimer=setTimeout(function (){
self._mqttDeferredTestTimer=null;
var nextPollCount=pollCount+1;
self._loadMqttStatus();
const badge=document.getElementById('mqtt-status-badge');
if(badge&&badge.classList.contains('mqtt-status-online')){
if(resultEl){
resultEl.textContent='连接成功！';
resultEl.style.color='#67c23a';
}
return ;
}
if(self._mqttTestConnectedDetected){
self._mqttTestConnectedDetected=false;
if(resultEl){
resultEl.textContent='测试连接成功！';
resultEl.style.color='#67c23a';
}
return ;
}
if(nextPollCount>=15){
if(resultEl&&!resultEl.textContent.includes('连接成功')){
resultEl.textContent='异步连接超时，请检查配置或查看日志';
resultEl.style.color='#f56c6c';
if(btn){
btn.classList.remove('mqtt-test-success');
btn.classList.add('mqtt-test-fail');
}
}
return ;
}
self._scheduleMqttDeferredStatusPoll(nextPollCount,btn,resultEl);
},this._getMqttDeferredPollIntervalMs());
},
_startMqttStatusPolling(options){
options=options||{};
this._stopMqttStatusPolling();
var self=this;
this._ensureBadgeNotStuck();
var delayMs=options.initialDelayMs||1500;
this._mqttStatusTimer=setTimeout(function (){
self._mqttStatusTimer=null;
self._loadMqttStatus();
self._mqttPollInterval=setInterval(function (){
self._loadMqttStatus();
},5000);
},delayMs);
},
_stopMqttStatusPolling(){
this._mqttLitePollStopped=true;
if(this._mqttLitePollTimer){
clearTimeout(this._mqttLitePollTimer);
this._mqttLitePollTimer=null;
}
this._clearMqttDeferredTestTimer();
if(this._mqttStatusTimer){
clearTimeout(this._mqttStatusTimer);
this._mqttStatusTimer=null;
}
if(this._mqttPollInterval){
clearInterval(this._mqttPollInterval);
this._mqttPollInterval=null;
}
if(this._mqttRetryTimer){
clearTimeout(this._mqttRetryTimer);
this._mqttRetryTimer=null;
}
if(this._mqttAutoReconnPollTimer){
clearTimeout(this._mqttAutoReconnPollTimer);
this._mqttAutoReconnPollTimer=null;
}
},
_loadMqttStatus(){
this._mqttApiFailCount=this._mqttApiFailCount||0;
var self=this;
apiGetSilent('/api/mqtt/status')
.then(function (res){
if(!res||!res.success){
self._mqttApiFailCount++;
self._handleMqttApiFail();
if(self._mqttApiFailCount===1){
self._mqttRetryTimer=setTimeout(function (){
self._mqttRetryTimer=null;
self._loadMqttStatus();
},3000);
}
return ;
}
self._mqttApiFailCount=0;
self._updateMqttStatusUI(res.data||{});
})
.catch(function (err){
self._mqttApiFailCount++;
self._handleMqttApiFail();
if(self._mqttApiFailCount===1){
self._mqttRetryTimer=setTimeout(function (){
self._mqttRetryTimer=null;
self._loadMqttStatus();
},3000);
}
});
},
_handleMqttApiFail(){
const badge=document.getElementById('mqtt-status-badge');
if(!badge)return ;
if(badge.classList.contains('mqtt-status-detecting')){
badge.className='mqtt-status-badge mqtt-status-connecting';
badge.textContent='连接中';
return ;
}
if(this._mqttApiFailCount>=4&&badge.classList.contains('mqtt-status-connecting')){
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='连接超时';
}
},
_ensureBadgeNotStuck(){
const badge=document.getElementById('mqtt-status-badge');
if(!badge)return ;
if(badge.classList.contains('mqtt-status-detecting')){
badge.className='mqtt-status-badge mqtt-status-connecting';
badge.textContent='连接中';
}
},
_updateMqttStatusUI:function (data){
const d=data||{};
const badge=document.getElementById('mqtt-status-badge');
const serverEl=document.getElementById('mqtt-status-server');
const clientEl=document.getElementById('mqtt-status-clientid');
const reconnEl=document.getElementById('mqtt-status-reconnects');
if(badge){
const connecting=!!(d.connecting);
const autoStarted=!!(d.autoStartStarted);
const hasError=d.lastError&&d.lastError!==0;
if(!this._mqttAutoReconnectTriggered&&d.enabled!==false&&d.autoReconnect!==false){
this._mqttAutoReconnectTriggered=true;
if(!d.connected){
var self=this;
if(typeof apiPostSilent==='function'){
apiPostSilent('/api/mqtt/reconnect',{}).then(function (){
var pollCount=0;
var maxPolls=6;
function pollStatus(){
if(self._mqttLitePollStopped)return ;
pollCount++;
self._loadMqttStatus();
if(pollCount<maxPolls&&!self._mqttLitePollStopped){
self._mqttAutoReconnPollTimer=setTimeout(function (){
self._mqttAutoReconnPollTimer=null;
var badge=document.getElementById('mqtt-status-badge');
if(badge&&badge.classList.contains('mqtt-status-online'))return ;
pollStatus();
},5000);
}
}
self._mqttAutoReconnPollTimer=setTimeout(pollStatus,3000);
}).catch(function (){});
}
}
}
if(d.testConnected){
badge.className='mqtt-status-badge mqtt-status-online';
badge.textContent='测试成功';
this._mqttConnectingStartTime=0;
this._mqttTestConnectedDetected=true;
}else if(d.connected){
badge.className='mqtt-status-badge mqtt-status-online';
badge.textContent='已连接';
this._mqttConnectingStartTime=0;
}else if(d.internetAvailable===false&&d.enabled!==false){
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='网络未连接';
this._mqttConnectingStartTime=0;
}else if(connecting&&!hasError){
if(!this._mqttConnectingStartTime){
this._mqttConnectingStartTime=Date.now();
}
var connectingDuration=Date.now()-this._mqttConnectingStartTime;
if(connectingDuration>60000&&(d.reconnectCount===0||d.reconnectCount===undefined)){
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='连接超时';
}else{
badge.className='mqtt-status-badge mqtt-status-connecting';
badge.textContent='连接中';
}
}else if(connecting&&hasError){
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='连接失败';
this._mqttConnectingStartTime=0;
}else if(!d.enabled){
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='未连接';
this._mqttConnectingStartTime=0;
}else if(!d.initialized){
badge.className='mqtt-status-badge mqtt-status-connecting';
badge.textContent='初始化中';
}else{
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='未连接';
this._mqttConnectingStartTime=0;
}
}
if(serverEl)serverEl.textContent=d.server?(d.server+':'+d.port):'--';
if(clientEl)clientEl.textContent=d.clientId||'--';
if(reconnEl)reconnEl.textContent=d.reconnectCount??0;
},
_updateMqttStatusPanel(connected,server,port,clientId){
const badge=document.getElementById('mqtt-status-badge');
const serverEl=document.getElementById('mqtt-status-server');
const clientEl=document.getElementById('mqtt-status-clientid');
if(badge){
if(connected){badge.className='mqtt-status-badge mqtt-status-online';badge.textContent='已连接';}
else{badge.className='mqtt-status-badge mqtt-status-offline';badge.textContent='未连接';}
}
if(serverEl)serverEl.textContent=server?(server+':'+port):'--';
if(clientEl)clientEl.textContent=clientId||'--';
}
});
})();
(function (){
Object.assign(AppState,{
_protocolFragmentMap:{
'mqtt':{container:'mqtt-fragment-container',fragment:'protocol-mqtt'},
'modbus-rtu':{container:'modbus-rtu-fragment-container',fragment:'protocol-modbus-rtu'}
},
_loadFullProtocolConfig:function (tabId,options){
var self=this;
var liteLoader=this.loadProtocolConfig;
var sequence=tabId==='modbus-rtu'?'protocol-modbus-rtu':'protocol-full-config';
if(typeof this._setProtocolFragmentLoading==='function'){
this._setProtocolFragmentLoading(tabId);
}
if(typeof ModuleLoader!=='undefined'&&
ModuleLoader&&
typeof ModuleLoader.loadModule==='function'&&
(!ModuleLoader.isLoaded||!ModuleLoader.isLoaded(sequence))){
return new Promise(function (resolve,reject){
var timer=setTimeout(function (){
if(typeof self._setProtocolFragmentError==='function'){
self._setProtocolFragmentError(tabId);
}
reject(new Error('Protocol module load timeout'));
},30000);
ModuleLoader.loadModule(sequence,function (){
clearTimeout(timer);
if(self.loadProtocolConfig===liteLoader){
if(typeof self._setProtocolFragmentError==='function'){
self._setProtocolFragmentError(tabId);
}
reject(new Error('Protocol module did not register'));
return ;
}
Promise.resolve(self.loadProtocolConfig(tabId,options)).then(resolve,reject);
});
});
}
if(this.loadProtocolConfig!==liteLoader){
return this.loadProtocolConfig(tabId,options);
}
return Promise.reject(new Error('Protocol module loader unavailable'));
},
loadProtocolConfig:function (tabId,options){
if(tabId!=='mqtt'){
return this._loadFullProtocolConfig(tabId,options);
}
var self=this;
if(!this._protocolEventsBound){
this.setupProtocolEvents();
}
if(typeof this._stopMasterStatusRefresh==='function'){
this._stopMasterStatusRefresh();
}
if(this._coilAutoRefreshTimer){
clearInterval(this._coilAutoRefreshTimer);
this._coilAutoRefreshTimer=null;
}
var fragInfo=this._protocolFragmentMap[tabId];
if(fragInfo){
if(typeof this._setProtocolFragmentLoading==='function'){
this._setProtocolFragmentLoading(tabId);
}
return PageLoader.loadFragment(fragInfo.container,fragInfo.fragment).then(function (){
self.setupProtocolEvents();
return self._loadProtocolConfigData(tabId,options);
});
}
return this._loadProtocolConfigData(tabId,options);
},
_loadProtocolConfigData:function (tabId,options){
if(tabId!=='mqtt'){
return this._loadFullProtocolConfig(tabId,options);
}
if(options&&options.noCache===true){
this._protocolLiteConfig=null;
}
if(this._protocolLiteConfig){
this._fillProtocolForm(tabId,this._protocolLiteConfig,options);
return Promise.resolve(this._protocolLiteConfig);
}
var getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
return getter('/api/protocol/config',{compact:1,section:'mqtt'})
.then(res=>{
if(!res||!res.success)return null;
this._protocolLiteConfig=res.data||{};
this._fillProtocolForm(tabId,this._protocolLiteConfig,options);
return this._protocolLiteConfig;
})
.catch(err=>{
console.error('load MQTT protocol config failed:',err);
throw err;
});
},
_updateMqttsMemoryHint:function (tlsSupported,currentScheme){
var schemeEl=document.getElementById('mqtt-scheme');
if(!schemeEl)return ;
this._mqttTlsSupported=tlsSupported;
var hintEl=document.getElementById('mqtts-memory-hint');
if(hintEl){
if(tlsSupported===false&&currentScheme==='mqtts'){
hintEl.textContent='\u26a0\ufe0f \u6b64\u8bbe\u5907\u5185\u5b58\u6709\u9650\uff0cmqtts(TLS)\u8fde\u63a5\u53ef\u80fd\u56e0\u5185\u5b58\u4e0d\u8db3\u800c\u5931\u8d25\u3002\u5982\u679c\u8fde\u63a5\u5931\u8d25\uff0c\u5efa\u8bae\u5207\u6362\u4e3a mqtt\u3002';
hintEl.style.display='';
}else{
hintEl.style.display='none';
}
}
if(!this._mqttSchemeBound){
var self=this;
schemeEl.addEventListener('change',function (){
self._updateMqttsMemoryHint(self._mqttTlsSupported,this.value);
});
this._mqttSchemeBound=true;
}
},
_fillProtocolForm:function (tabId,config){
if(tabId!=='mqtt')return ;
var mqtt=config&&config.mqtt;
if(!mqtt)return ;
this._setCheckbox('mqtt-enabled',mqtt.enabled??true);
this._setValue('mqtt-scheme',mqtt.scheme||'mqtt');
var schemeEl=document.getElementById('mqtt-scheme');
if(schemeEl){
this._updateMqttsMemoryHint(mqtt.tlsSupported,schemeEl.value);
}
this._setValue('mqtt-broker',mqtt.server??'');
this._setValue('mqtt-port',mqtt.port||1883);
this._setValue('mqtt-client-id',mqtt.clientId??'');
this._setValue('mqtt-username',mqtt.username||'');
this._setValue('mqtt-password',mqtt.password||'');
this._setValue('mqtt-alive',mqtt.keepAlive||60);
this._setCheckbox('mqtt-auto-reconnect',mqtt.autoReconnect??true);
this._setValue('mqtt-will-topic',mqtt.willTopic||'');
this._setValue('mqtt-will-payload',mqtt.willPayload||'');
this._setValue('mqtt-will-qos',mqtt.willQos??0);
this._setCheckbox('mqtt-will-retain',mqtt.willRetain ??false);
this._setValue('mqtt-longitude',mqtt.longitude??0);
this._setValue('mqtt-latitude',mqtt.latitude??0);
this._setValue('mqtt-iccid',mqtt.iccid||'');
this._setValue('mqtt-card-platform-id',mqtt.cardPlatformId??0);
this._setValue('mqtt-summary',mqtt.summary??'{"name":"fastbee","chip":"ESP32"}');
this._setValue('mqtt-auth-type',mqtt.authType??0);
this._setValue('mqtt-secret',mqtt.mqttSecret??'');
this._setValue('mqtt-auth-code',mqtt.authCode||'');
this._loadMqttPublishTopics(mqtt.publishTopics||[]);
this._loadMqttSubscribeTopics(mqtt.subscribeTopics||[]);
this._mqttAutoReconnectTriggered=false;
if(mqtt.enabled!==false&&typeof this._loadMqttStatus==='function'){
var self=this;
self._mqttLitePollCount=0;
self._mqttConnectingStartTime=0;
var mqttMaxPolls=10;
function mqttPollOnce(){
if(self._mqttLitePollStopped)return ;
var badge=document.getElementById('mqtt-status-badge');
if(badge&&badge.classList.contains('mqtt-status-online')){
return ;
}
self._loadMqttStatus();
self._mqttLitePollCount++;
if(self._mqttLitePollCount<mqttMaxPolls&&!self._mqttLitePollStopped){
self._mqttLitePollTimer=setTimeout(mqttPollOnce,5000);
}else if(self._mqttLitePollCount>=mqttMaxPolls){
self._mqttLitePollTimer=setTimeout(function (){
if(self._mqttLitePollStopped)return ;
var finalBadge=document.getElementById('mqtt-status-badge');
if(finalBadge&&!finalBadge.classList.contains('mqtt-status-online')){
if(finalBadge.classList.contains('mqtt-status-connecting')){
finalBadge.className='mqtt-status-badge mqtt-status-offline';
finalBadge.textContent='连接超时';
}
}
},3000);
}
}
self._mqttLitePollStopped=false;
self._mqttLitePollTimer=setTimeout(mqttPollOnce,3000);
}else if(mqtt.enabled===false){
if(typeof this._stopMqttStatusPolling==='function'){
this._stopMqttStatusPolling();
}
var badge=document.getElementById('mqtt-status-badge');
if(badge){
badge.className='mqtt-status-badge mqtt-status-offline';
badge.textContent='未连接';
}
}
},
saveProtocolConfig:function (formId){
var self=this;
var snapshot={};
var form=document.getElementById('mqtt-form');
if(form){
var inputs=form.querySelectorAll('input, select, textarea');
for(var i=0;i<inputs.length;i++){
var el=inputs[i];
var key=el.id||el.className;
if(!key)continue;
if(el.type==='checkbox'){
snapshot[key]={type:'checkbox',checked:el.checked};
}else{
snapshot[key]={type:'value',value:el.value};
}
}
var pubTopics=document.getElementById('mqtt-publish-topics');
var subTopics=document.getElementById('mqtt-subscribe-topics');
snapshot['__publishTopicsHTML']=pubTopics?pubTopics.innerHTML:'';
snapshot['__subscribeTopicsHTML']=subTopics?subTopics.innerHTML:'';
}
return this._loadFullProtocolConfig('mqtt').then(function (){
if(form){
var inputs=form.querySelectorAll('input, select, textarea');
for(var i=0;i<inputs.length;i++){
var el=inputs[i];
var key=el.id||el.className;
if(!key||!snapshot[key])continue;
if(el.type==='checkbox'){
el.checked=snapshot[key].checked;
}else{
el.value=snapshot[key].value;
}
}
if(snapshot['__publishTopicsHTML']!==undefined&&pubTopics){
pubTopics.innerHTML=snapshot['__publishTopicsHTML'];
}
if(snapshot['__subscribeTopicsHTML']!==undefined&&subTopics){
subTopics.innerHTML=snapshot['__subscribeTopicsHTML'];
}
}
return self.saveProtocolConfig(formId);
});
}
});
})();
(function (){
if(typeof AppState==='undefined')return ;
if(typeof AppState.registerModule==='function'){
AppState.registerModule('protocol',{});
}
if(typeof AppState.setupProtocolEvents==='function'){
AppState.setupProtocolEvents();
}
document.dispatchEvent(new CustomEvent('protocol-modules-loaded'));
})();