const i18n={
currentLang:localStorage.getItem('language')||'zh-CN',
loadedLanguages:['zh-CN'],
loadingLanguages:[],
translations:{
'zh-CN':{},
'en':{}
},
t(key){
return (this.translations[this.currentLang]&&this.translations[this.currentLang][key])||key;
},
addTranslations(lang,data){
if(!this.translations[lang]){
this.translations[lang]={};
}
Object.assign(this.translations[lang],data);
if(!this.loadedLanguages.includes(lang)){
this.loadedLanguages.push(lang);
}
const loadingIndex=this.loadingLanguages.indexOf(lang);
if(loadingIndex>-1){
this.loadingLanguages.splice(loadingIndex,1);
}
},
mergeTranslations(lang,data){
this.addTranslations(lang,data);
},
isLanguageLoaded(lang){
return this.loadedLanguages.includes(lang);
},
isLanguageLoading(lang){
return this.loadingLanguages.indexOf(lang)>-1;
},
loadLanguagePack(lang,callback){
if(this.isLanguageLoaded(lang)){
if(callback)callback(true);
return ;
}
if(this.isLanguageLoading(lang)){
let waitCount=0;
const waitInterval=setInterval(()=>{
waitCount++;
if(this.isLanguageLoaded(lang)){
clearInterval(waitInterval);
if(callback)callback(true);
}else if(waitCount>50){
clearInterval(waitInterval);
if(callback)callback(false);
}
},100);
return ;
}
this.loadingLanguages.push(lang);
const script=document.createElement('script');
script.src='./js/modules/i18n-'+lang+'.js';
script.onload=()=>{
if(callback)callback(true);
};
script.onerror=()=>{
const loadingIndex=this.loadingLanguages.indexOf(lang);
if(loadingIndex>-1){
this.loadingLanguages.splice(loadingIndex,1);
}
console.error('Failed to load language pack: '+lang);
if(callback)callback(false);
};
document.head.appendChild(script);
},
setLanguage(lang){
const doSwitch=()=>{
if(this.translations[lang]){
this.currentLang=lang;
localStorage.setItem('language',lang);
this.updatePageText();
if(typeof Notification!=='undefined'){
Notification.success(
lang==='zh-CN'?'语言已切换为中文':'Language switched to English',
lang==='zh-CN'?'成功':'Success'
);
}
return true;
}
return false;
};
if(!this.isLanguageLoaded(lang)&&lang!=='zh-CN'){
this.loadLanguagePack(lang,(success)=>{
if(success){
doSwitch();
}else{
if(typeof Notification!=='undefined'){
Notification.error(
lang==='zh-CN'?'语言包加载失败，已回退到中文':'Language pack load failed, fallback to Chinese',
lang==='zh-CN'?'错误':'Error'
);
}
this.setLanguage('zh-CN');
}
});
return false;
}
return doSwitch();
},
updatePageText(){
const elements=document.querySelectorAll('[id]');
elements.forEach(element=>{
const key=element.id;
if(this.translations[this.currentLang]&&this.translations[this.currentLang][key]!==undefined){
if(element.tagName==='SELECT'){
return ;
}
if(element.tagName==='INPUT'&&element.type!=='button'&&element.type!=='submit'){
element.placeholder=this.t(key);
}else{
element.textContent=this.t(key);
}
}
});
document.querySelectorAll('[data-i18n]').forEach(element=>{
const key=element.getAttribute('data-i18n');
const translation=this.t(key);
if(translation&&translation!==key){
if(element.tagName==='INPUT'||element.tagName==='TEXTAREA'){
element.placeholder=translation;
}else if(element.tagName==='OPTION'){
element.textContent=translation;
const select=element.parentElement;
if(select&&select.tagName==='SELECT'){
const idx=select.selectedIndex;
select.selectedIndex=idx;
}
}else{
element.textContent=translation;
}
}
});
document.querySelectorAll('[data-i18n-placeholder]').forEach(element=>{
const key=element.getAttribute('data-i18n-placeholder');
const translation=this.t(key);
if(translation&&translation!==key){
element.placeholder=translation;
}
});
document.querySelectorAll('[data-i18n-title]').forEach(element=>{
const key=element.getAttribute('data-i18n-title');
const translation=this.t(key);
if(translation&&translation!==key){
element.title=translation;
}
});
document.documentElement.lang=this.currentLang;
}
};