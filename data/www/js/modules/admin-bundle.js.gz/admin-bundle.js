/**
 * Compatibility stub kept intentionally small.
 * Admin pages now load individual modules to avoid large one-shot downloads on ESP32.
 */
(function(){window.__fastbeeAdminBundleCompat=true;})();
