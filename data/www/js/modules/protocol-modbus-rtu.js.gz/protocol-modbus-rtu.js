(function (){
Object.assign(AppState,{
onModbusModeChange(mode){
},
onWorkModeChange(mode){
},
_isTransparentMode(){
var sel=document.getElementById('rtu-transfer-type');
return sel&&sel.value==='1';
},
_onTransferTypeChange(){
this._renderAllDevices();
},
_renderAllDevices(){
var tbody=document.getElementById('all-devices-body');
if(!tbody)return ;
var tasks=this._masterTasks||[];
var devices=this._modbusDevices||[];
var visibleDevices=devices;
if(tasks.length===0&&visibleDevices.length===0){
tbody.innerHTML=this._renderProtocolEmptyRow(6,i18n.t('modbus-no-devices')||'暂无子设备');
return ;
}
var fcNames={1:'FC01',2:'FC02',3:'FC03',4:'FC04'};
var typeLabels={
sensor:i18n.t('modbus-type-sensor')||'采集',
relay:i18n.t('modbus-type-relay')||'继电器',
pwm:i18n.t('modbus-type-pwm')||'PWM',
pid:i18n.t('modbus-type-pid')||'PID',
motor:i18n.t('modbus-type-motor')||'电机'
};
var rows='';
for(var i=0;i<tasks.length;i++){
rows+=this._renderAllDeviceSensorRow(tasks[i],i,fcNames,typeLabels);
}
for(var j=0;j<visibleDevices.length;j++){
rows+=this._renderAllDeviceControlRow(visibleDevices[j],j,typeLabels);
}
tbody.innerHTML=rows;
},
_editDevice(source,idx){
if(source==='sensor'){
this._openTaskEditModal(idx);
}else{
this._openEditModal(idx);
}
},
_deleteDevice(source,idx){
var msg=i18n.t('modbus-device-delete-confirm')||'确定删除？';
if(!confirm(msg))return ;
if(source==='sensor'){
if(this._masterTasks)this._masterTasks.splice(idx,1);
}else{
if(this._modbusDevices){
var devKey='dev_'+idx;
delete this._deviceCoilCache[devKey];
delete this._devicePwmCache[devKey];
delete this._devicePidCache[devKey];
this._modbusDevices.splice(idx,1);
if(this._activeDeviceIdx===idx){
this._activeDeviceIdx=-1;
}else if(this._activeDeviceIdx>idx){
this._activeDeviceIdx--;
}
}
}
this._renderAllDevices();
},
_showAddDeviceMenu(){
var menu=document.getElementById('add-device-menu');
if(!menu)return ;
var isVisible=!menu.classList.contains('fb-hidden');
if(isVisible){
menu.classList.add('fb-hidden');
}else{
menu.classList.remove('fb-hidden');
var closeMenu=function (e){
if(!menu.contains(e.target)){
menu.classList.add('fb-hidden');
document.removeEventListener('click',closeMenu);
}
};
setTimeout(function (){document.addEventListener('click',closeMenu);},0);
}
},
_addSensorDevice(){
var menu=document.getElementById('add-device-menu');
if(menu)menu.classList.add('fb-hidden');
if(!this._masterTasks)this._masterTasks=[];
if(this._masterTasks.length>=8){
Notification.warning('Max 8 sensor devices',i18n.t('modbus-all-devices-title'));
return ;
}
this._openTaskEditModal(-1);
},
_addControlDevice(){
var menu=document.getElementById('add-device-menu');
if(menu)menu.classList.add('fb-hidden');
if(!this._modbusDevices)this._modbusDevices=[];
if(this._modbusDevices.length>=8){
Notification.warning('Max 8 control devices',i18n.t('modbus-all-devices-title'));
return ;
}
this._openEditModal(-1);
},
_openTaskEditModal(idx){
var modal=document.getElementById('task-edit-modal');
if(!modal)return ;
this._editingTaskIdx=idx;
var task;
if(idx>=0&&this._masterTasks&&this._masterTasks[idx]){
task=this._masterTasks[idx];
}else{
task={slaveAddress:1,functionCode:3,startAddress:0,quantity:10,enabled:true,name:'',mappings:[]};
}
var f=function (id){return document.getElementById(id);};
f('task-edit-slave-addr').value=task.slaveAddress||1;
f('task-edit-fc').value=task.functionCode||3;
f('task-edit-start-addr').value=task.startAddress||0;
f('task-edit-quantity').value=task.quantity||10;
f('task-edit-name').value=task.name||task.label||'';
f('task-edit-enabled').checked=task.enabled!==false;
var titleEl=modal.querySelector('.modal-header h3');
if(titleEl)titleEl.textContent=idx<0?(i18n.t('modbus-task-add-title')||'新建子设备'):(i18n.t('modbus-task-edit-title')||'编辑子设备');
AppState.showModal(modal);
},
_closeTaskEditModal(){
var modal=document.getElementById('task-edit-modal');
if(modal)AppState.hideModal(modal);
this._editingTaskIdx=-1;
},
_saveTaskEditModal(){
var f=function (id){return document.getElementById(id);};
var fc=parseInt(f('task-edit-fc').value)||3;
var fcToDeviceType={1:'coil',2:'discrete',3:'holding',4:'input'};
var task={
slaveAddress:parseInt(f('task-edit-slave-addr').value)||1,
functionCode:fc,
startAddress:parseInt(f('task-edit-start-addr').value)||0,
quantity:parseInt(f('task-edit-quantity').value)||10,
name:f('task-edit-name').value||'',
deviceType:fcToDeviceType[fc]||'holding',
enabled:f('task-edit-enabled').checked
};
if(!this._masterTasks)this._masterTasks=[];
if(this._editingTaskIdx>=0&&this._masterTasks[this._editingTaskIdx]){
var oldTask=this._masterTasks[this._editingTaskIdx];
task.mappings=oldTask.mappings||[];
task.pollInterval=oldTask.pollInterval;
this._masterTasks[this._editingTaskIdx]=task;
}else{
task.mappings=[];
this._masterTasks.push(task);
}
this._renderAllDevices();
this._closeTaskEditModal();
},
addMasterPollTask(){
if(!this._masterTasks)this._masterTasks=[];
if(this._masterTasks.length>=8){
Notification.warning('Max 8 tasks',i18n.t('modbus-master-title'));
return ;
}
this._openTaskEditModal(-1);
},
removeMasterPollTask(idx){
if(this._masterTasks){
this._masterTasks.splice(idx,1);
this._renderAllDevices();
}
},
openMappingModal(taskIdx){
if(!this._masterTasks||!this._masterTasks[taskIdx])return ;
this._currentMappingTaskIdx=taskIdx;
this._currentMappings=JSON.parse(JSON.stringify(this._masterTasks[taskIdx].mappings||[]));
this._renderMappingTable();
AppState.showModal('mapping-modal');
},
closeMappingModal(){
AppState.hideModal('mapping-modal');
this._currentMappingTaskIdx=-1;
this._currentMappings=[];
},
saveMappingModal(){
if(this._currentMappingTaskIdx<0)return ;
this._collectMappingValues();
this._masterTasks[this._currentMappingTaskIdx].mappings=this._currentMappings;
this._renderAllDevices();
this.closeMappingModal();
},
addMapping(){
if(this._currentMappings.length>=8){
Notification.warning(i18n.t('modbus-mapping-max'));
return ;
}
this._collectMappingValues();
this._currentMappings.push({regOffset:0,dataType:0,scaleFactor:0.1,decimalPlaces:1,sensorId:'',unit:''});
this._renderMappingTable();
},
removeMapping(idx){
this._collectMappingValues();
this._currentMappings.splice(idx,1);
this._renderMappingTable();
},
_collectMappingValues(){
const tbody=document.getElementById('mapping-table-body');
if(!tbody)return ;
const rows=tbody.querySelectorAll('tr');
rows.forEach((row,idx)=>{
if(idx>=this._currentMappings.length)return ;
const inputs=row.querySelectorAll('input, select');
if(inputs.length>=6){
this._currentMappings[idx].regOffset=parseInt(inputs[0].value)||0;
this._currentMappings[idx].dataType=parseInt(inputs[1].value)||0;
this._currentMappings[idx].scaleFactor=parseFloat(inputs[2].value)||1.0;
this._currentMappings[idx].decimalPlaces=parseInt(inputs[3].value)||1;
this._currentMappings[idx].sensorId=inputs[4].value||'';
this._currentMappings[idx].unit=inputs[5].value||'';
}
});
},
_renderMappingTable(){
const tbody=document.getElementById('mapping-table-body');
if(!tbody)return ;
const dtOpts=[
{v:0,t:'uint16'},{v:1,t:'int16'},
{v:2,t:'uint32'},{v:3,t:'int32'},{v:4,t:'float32'}
];
if(this._currentMappings.length===0){
tbody.innerHTML=this._renderProtocolEmptyRow(7,i18n.t('modbus-master-no-tasks'));
return ;
}
tbody.innerHTML=this._currentMappings.map((m,idx)=>{
const dtSelect=dtOpts.map(o=>
'<option value="'+o.v+'"'+(m.dataType===o.v?' selected':'')+'>'+o.t+'</option>'
).join ('');
return '<tr>'+
'<td><input type="number" class="protocol-mapping-num-sm" value="'+(m.regOffset||0)+'" min="0" max="124"></td>'+
'<td><select class="protocol-mapping-select">'+dtSelect+'</select></td>'+
'<td><input type="number" class="protocol-mapping-num-md" value="'+(m.scaleFactor??0.1)+'" step="0.001"></td>'+
'<td><input type="number" class="protocol-mapping-num-sm" value="'+(m.decimalPlaces??1)+'" min="0" max="6"></td>'+
'<td><input type="text" class="protocol-mapping-text" value="'+(m.sensorId||'')+'" maxlength="15" placeholder="temperature"></td>'+
'<td><input type="text" class="protocol-mapping-text protocol-mapping-unit" value="'+(m.unit||'')+'" maxlength="7" placeholder="°C"></td>'+
'<td><button type="button" class="fb-btn fb-btn-sm fb-btn-danger protocol-mapping-remove" data-index="'+idx+'">删除</button></td>'+
'</tr>';
}).join ('');
},
_loadModbusDevices(){
var serverDevices=this._modbusDevices||[];
if(serverDevices.length===0){
try{
var rtu=this._protocolConfig&&this._protocolConfig.modbusRtu;
if(rtu&&rtu.master&&rtu.master.devices&&rtu.master.devices.length>0){
serverDevices=Array.isArray(rtu.master.devices)
?rtu.master.devices.slice()
:Object.keys(rtu.master.devices).map(function (k){return rtu.master.devices[k];});
}
}catch(e){}
}
if(serverDevices.length===0){
try{
var raw=localStorage.getItem('modbus_devices');
if(raw){
var localDevices=JSON.parse(raw);
if(localDevices&&localDevices.length>0){
serverDevices=localDevices.map(function (d){
return {
name:d.name||'Device',
sensorId:d.sensorId||'',
deviceType:d.deviceType||d.type||'relay',
slaveAddress:d.slaveAddress||1,
channelCount:d.channelCount||2,
coilBase:d.coilBase||0,
ncMode:!!d.ncMode,
controlProtocol:d.relayMode==='register'?1:0,
batchRegister:d.batchRegister||0,
pwmRegBase:d.pwmRegBase||0,
pwmResolution:d.pwmResolution||8,
pidAddrs:[
d.pidPvAddr||0,d.pidSvAddr||1,d.pidOutAddr||2,
d.pidPAddr||3,d.pidIAddr||4,d.pidDAddr||5
],
pidDecimals:d.pidDecimals||1,
enabled:d.enabled!==false
};
});
}
}
}catch(e){}
}
this._modbusDevices=serverDevices;
for(var i=0;i<this._modbusDevices.length;i++){
if(!this._modbusDevices[i].deviceType){
this._modbusDevices[i].deviceType=this._modbusDevices[i].type||'relay';
}
}
this._activeDeviceIdx=-1;
this._renderAllDevices();
},
_refreshModbusDeviceList(){
var btn=document.getElementById('modbus-refresh-devices-btn');
if(btn&&btn.disabled)return ;
if(btn){
btn.disabled=true;
btn.textContent='加载中...';
}
this._protocolConfig=null;
if(typeof window.apiInvalidateCache==='function'){
window.apiInvalidateCache('/api/protocol/config');
window.apiInvalidateCache('/api/peripherals');
window.apiInvalidateCache('/api/modbus/status');
}
this.loadProtocolConfig('modbus-rtu',{noCache:true})
.then(function (res){
if(res){
Notification.success('设备列表已刷新');
}else{
Notification.error('获取配置失败');
}
})
.catch(function (err){
if(!(err&&err._pageAborted)){
Notification.error('刷新失败，请检查网络');
}
})
.finally(function (){
if(btn){
btn.disabled=false;
btn.innerHTML='&#x21bb; 刷新列表';
}
});
},
_renderDeviceTable(){
var tbody=document.getElementById('modbus-devices-body');
if(!tbody)return ;
if(!this._modbusDevices||this._modbusDevices.length===0){
tbody.innerHTML=this._renderProtocolEmptyRow(8,i18n.t('modbus-device-no-devices')||'暂无子设备');
return ;
}
var typeLabels={relay:i18n.t('modbus-ctrl-type-relay')||'继电器',pwm:'PWM',pid:'PID',motor:i18n.t('modbus-type-motor')||'电机'};
var protLabels=['Coil','Register'];
var self=this;
tbody.innerHTML=this._modbusDevices.map(function (dev,idx){
return self._renderModbusDeviceRow(dev,idx,typeLabels,protLabels);
}).join ('');
},
_updateDevice(idx,field,value){
if(this._modbusDevices&&this._modbusDevices[idx]){
this._modbusDevices[idx][field]=value;
if(field==='deviceType'){
if(idx===this._activeDeviceIdx){
this._activateDevice(idx);
}else{
this._renderAllDevices();
}
}
}
},
_updateActiveDeviceExt(field,value){
if(this._activeDeviceIdx<0||!this._modbusDevices)return ;
var dev=this._modbusDevices[this._activeDeviceIdx];
if(!dev)return ;
if(field.indexOf('pidAddrs.')===0){
var arrIdx=parseInt(field.split('.')[1]);
if(!dev.pidAddrs)dev.pidAddrs=[0,1,2,3,4,5];
dev.pidAddrs[arrIdx]=value;
}else{
dev[field]=value;
}
},
addModbusDevice(){
if(!this._modbusDevices)this._modbusDevices=[];
if(this._modbusDevices.length>=8){
Notification.warning(i18n.t('modbus-device-max-reached')||'最多8个子设备');
return ;
}
this._openEditModal(-1);
},
_removeDevice(idx){
if(!this._modbusDevices)return ;
var msg=i18n.t('modbus-device-delete-confirm')||'确定要删除此设备？';
if(!confirm(msg))return ;
var devKey='dev_'+idx;
delete this._deviceCoilCache[devKey];
delete this._devicePwmCache[devKey];
delete this._devicePidCache[devKey];
this._modbusDevices.splice(idx,1);
if(this._activeDeviceIdx===idx){
this._activeDeviceIdx=-1;
}else if(this._activeDeviceIdx>idx){
this._activeDeviceIdx--;
}
this._renderAllDevices();
},
_openEditModal(idx){
this._editingDeviceIdx=idx;
var dev=(idx>=0&&this._modbusDevices&&this._modbusDevices[idx])
?this._modbusDevices[idx]:null;
var modal=document.getElementById('modbus-device-edit-modal');
if(!modal)return ;
document.getElementById('mdev-edit-name').value=dev?(dev.name||''):((i18n.t('modbus-ctrl-device-default-name')||'设备')+((this._modbusDevices?this._modbusDevices.length:0)+1));
document.getElementById('mdev-edit-sensorid').value=dev?(dev.sensorId||''):'';
document.getElementById('mdev-edit-type').value=dev?(dev.deviceType||'relay'):'relay';
document.getElementById('mdev-edit-addr').value=dev?(dev.slaveAddress||1):1;
document.getElementById('mdev-edit-ch').value=String(dev?(dev.channelCount||2):2);
document.getElementById('mdev-edit-base').value=dev?(dev.coilBase||0):0;
document.getElementById('mdev-edit-protocol').value=String(dev?(dev.controlProtocol||0):0);
document.getElementById('mdev-edit-nc').value=dev?(dev.ncMode?'true':'false'):'true';
document.getElementById('mdev-edit-enabled').checked=dev?(dev.enabled!==false):true;
document.getElementById('mdev-edit-batch-reg').value=dev?(dev.batchRegister||0):0;
document.getElementById('mdev-edit-batch-type').value=String(dev?(dev.batchRegType||0):0);
document.getElementById('mdev-edit-pwm-reg-base').value=dev?(dev.pwmRegBase||0):0;
document.getElementById('mdev-edit-pwm-resolution').value=String(dev?(dev.pwmResolution||8):8);
var pidA=dev?(dev.pidAddrs||[0,1,2,3,4,5]):[0,1,2,3,4,5];
var pidFields=['pv','sv','out','p','i','d'];
for(var pi=0;pi<pidFields.length;pi++){
var pe=document.getElementById('mdev-edit-pid-'+pidFields[pi]);
if(pe)pe.value=pidA[pi]||pi;
}
document.getElementById('mdev-edit-pid-decimals').value=String(dev?(dev.pidDecimals||1):1);
var motorRegs=dev?(dev.motorRegs||[0,1,2,5,7]):[0,1,2,5,7];
var motorFields=['fwd','rev','stop','speed','pulse'];
for(var mi=0;mi<motorFields.length;mi++){
var me=document.getElementById('mdev-edit-motor-'+motorFields[mi]);
if(me)me.value=motorRegs[mi]!=null?motorRegs[mi]:[0,1,2,5,7][mi];
}
document.getElementById('mdev-edit-motor-decimals').value=String(dev?(dev.motorDecimals||0):0);
this._onEditTypeChange();
var title=document.getElementById('modbus-edit-modal-title');
if(title)title.textContent=(idx>=0)
?(i18n.t('modbus-device-edit-title')||'编辑子设备')
:(i18n.t('modbus-device-add')||'添加设备');
AppState.showModal(modal);
},
_onEditTypeChange(){
var type=document.getElementById('mdev-edit-type').value;
var pwmSec=document.getElementById('mdev-edit-pwm-section');
var pidSec=document.getElementById('mdev-edit-pid-section');
var motorSec=document.getElementById('mdev-edit-motor-section');
var relaySec=document.getElementById('mdev-edit-relay-section');
if(pwmSec)pwmSec.classList.remove('fb-hidden');
if(pidSec)pidSec.classList.remove('fb-hidden');
if(motorSec)motorSec.classList.remove('fb-hidden');
if(relaySec)relaySec.classList.remove('fb-hidden');
if(pwmSec)AppState.toggleVisible(pwmSec,type==='pwm');
if(pidSec)AppState.toggleVisible(pidSec,type==='pid');
if(motorSec)AppState.toggleVisible(motorSec,type==='motor');
if(relaySec)AppState.toggleVisible(relaySec,type==='relay');
},
_closeEditModal(){
var modal=document.getElementById('modbus-device-edit-modal');
if(modal)AppState.hideModal(modal);
this._editingDeviceIdx=-1;
},
_saveEditModal(){
var idx=this._editingDeviceIdx;
var isNew=(idx<0);
if(isNew){
if(!this._modbusDevices||!Array.isArray(this._modbusDevices)){
this._modbusDevices=[];
}
if(this._modbusDevices.length>=8){
Notification.warning(i18n.t('modbus-device-max-reached')||'最多8个子设备');
return ;
}
this._modbusDevices.push({});
idx=this._modbusDevices.length-1;
}
var dev=this._modbusDevices[idx];
if(!dev){
console.error('_saveEditModal: dev is undefined, idx=',idx,'devices=',this._modbusDevices);
return ;
}
dev.name=document.getElementById('mdev-edit-name').value||'Device';
dev.sensorId=(document.getElementById('mdev-edit-sensorid').value||'').trim();
dev.deviceType=document.getElementById('mdev-edit-type').value||'relay';
dev.slaveAddress=parseInt(document.getElementById('mdev-edit-addr').value)||1;
dev.channelCount=parseInt(document.getElementById('mdev-edit-ch').value)||2;
dev.coilBase=parseInt(document.getElementById('mdev-edit-base').value)||0;
dev.controlProtocol=parseInt(document.getElementById('mdev-edit-protocol').value)||0;
dev.ncMode=(document.getElementById('mdev-edit-nc').value==='true');
dev.enabled=document.getElementById('mdev-edit-enabled').checked;
dev.batchRegister=parseInt(document.getElementById('mdev-edit-batch-reg').value)||0;
dev.batchRegType=parseInt(document.getElementById('mdev-edit-batch-type').value)||0;
dev.pwmRegBase=parseInt(document.getElementById('mdev-edit-pwm-reg-base').value)||0;
dev.pwmResolution=parseInt(document.getElementById('mdev-edit-pwm-resolution').value)||8;
var pidFields=['pv','sv','out','p','i','d'];
dev.pidAddrs=[];
for(var pi=0;pi<pidFields.length;pi++){
dev.pidAddrs.push(parseInt(document.getElementById('mdev-edit-pid-'+pidFields[pi]).value)||pi);
}
dev.pidDecimals=parseInt(document.getElementById('mdev-edit-pid-decimals').value)||1;
dev.motorRegs=[];
var motorFields=['fwd','rev','stop','speed','pulse'];
for(var mi=0;mi<motorFields.length;mi++){
dev.motorRegs.push(parseInt(document.getElementById('mdev-edit-motor-'+motorFields[mi]).value)||[0,1,2,5,7][mi]);
}
dev.motorDecimals=parseInt(document.getElementById('mdev-edit-motor-decimals').value)||0;
this._renderAllDevices();
this._closeEditModal();
},
async _loadUartPeripherals(selectedId,options){
const select=document.getElementById('rtu-peripheral-id');
if(!select)return ;
try{
const getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
const res=await getter('/api/peripherals',{
pageSize:100,
compact:1,
enabledOnly:1,
category:'communication'
});
if(!res||!res.success)return ;
this._uartPeripherals=(res.data||[]).filter(p=>p.type===1&&p.enabled);
select.innerHTML='<option value="" disabled>'+i18n.t('rtu-peripheral-placeholder')+'</option>';
if(this._uartPeripherals.length===0){
select.innerHTML+='<option value="" disabled>'+i18n.t('rtu-no-uart-peripherals')+'</option>';
return ;
}
this._uartPeripherals.forEach(p=>{
const pinsText=p.pins&&p.pins.length>=2?' (RX:'+p.pins[0]+', TX:'+p.pins[1]+')':'';
const opt=document.createElement('option');
opt.value=p.id;
opt.textContent=p.name+pinsText;
select.appendChild(opt);
});
if(selectedId){
select.value=selectedId;
this.onRtuPeripheralChange(selectedId,options);
}
}catch(e){console.error('Failed to load UART peripherals:',e);}
},
onRtuPeripheralChange(peripheralId,options){
const infoDiv=document.getElementById('rtu-peripheral-info');
if(!infoDiv||!peripheralId){if(infoDiv)AppState.hideElement(infoDiv);return ;}
const periph=(this._uartPeripherals||[]).find(p=>p.id===peripheralId);
if(!periph){AppState.hideElement(infoDiv);return ;}
const getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
getter('/api/peripherals/',{id:peripheralId}).then(res=>{
if(!res||!res.success)return ;
const data=res.data;
const baudRate=data.params?.baudRate||i18n.t('unknown')||'未知';
const pins=data.pins||[];
infoDiv.textContent='RX: GPIO'+pins[0]+', TX: GPIO'+pins[1]+', '+i18n.t('uart-baudrate-label')+': '+baudRate;
AppState.showElement(infoDiv);
}).catch(()=>{
const pins=periph.pins||[];
infoDiv.textContent='RX: GPIO'+pins[0]+', TX: GPIO'+pins[1];
AppState.showElement(infoDiv);
});
}
});
})();
(function (){
Object.assign(AppState,{
_isCtrlModalOffline(){
return this._modbusCtrlOffline===true;
},
_setCtrlModalOffline(offline,message){
var modal=document.getElementById('modbus-device-ctrl-modal');
if(!modal){
this._modbusCtrlOffline=!!offline;
return ;
}
var isOffline=!!offline;
this._modbusCtrlOffline=isOffline;
modal.classList.toggle('modbus-ctrl-offline',isOffline);
var banner=document.getElementById('modbus-ctrl-offline-banner');
if(banner)banner.remove();
if(isOffline){
if(typeof this._stopCoilAutoRefresh==='function')this._stopCoilAutoRefresh();
if(typeof this._stopPidAutoRefresh==='function')this._stopPidAutoRefresh();
var autoEl=document.getElementById('modbus-ctrl-auto-refresh');
if(autoEl)autoEl.checked=false;
var pidAutoEl=document.getElementById('modbus-ctrl-pid-auto-refresh');
if(pidAutoEl)pidAutoEl.checked=false;
}
var controls=modal.querySelectorAll('.modal-body input, .modal-body select, .modal-body textarea, .modal-body button');
controls.forEach(function (el){
if(isOffline){
if(!el.disabled)el.dataset.modbusOfflineDisabled='1';
el.disabled=true;
}else if(el.dataset.modbusOfflineDisabled==='1'){
el.disabled=false;
delete el.dataset.modbusOfflineDisabled;
}
});
},
_markCtrlModalOnline(){
if(this._modbusCtrlOffline===true){
this._setCtrlModalOffline(false);
}
},
_openCtrlModal(idx){
if(idx===undefined||idx===null||isNaN(idx)){
console.warn('[protocol] Invalid device index:',idx);
Notification.error(i18n.t('modbus-device-not-found')||'设备未找到');
return ;
}
if(!this._modbusDevices||!this._modbusDevices[idx]){
console.warn('[protocol] Device not found at index',idx);
Notification.error(i18n.t('modbus-device-not-found')||'设备未找到，请刷新列表');
this._renderDeviceTable();
this._renderAllDevices();
return ;
}
if(this._coilAutoRefreshTimer){
clearTimeout(this._coilAutoRefreshTimer);
this._coilAutoRefreshTimer=null;
}
if(this._pidAutoRefreshTimer){
clearTimeout(this._pidAutoRefreshTimer);
this._pidAutoRefreshTimer=null;
}
var autoEl=document.getElementById('modbus-ctrl-auto-refresh');
if(autoEl)autoEl.checked=false;
var pidAutoEl=document.getElementById('modbus-ctrl-pid-auto-refresh');
if(pidAutoEl)pidAutoEl.checked=false;
this._coilAutoRefreshErrors=0;
this._pidAutoRefreshErrors=0;
if(this._activeDeviceIdx>=0){
var cacheKey='dev_'+this._activeDeviceIdx;
if(this._coilStates.length>0)this._deviceCoilCache[cacheKey]=this._coilStates.slice();
if(this._pwmStates.length>0)this._devicePwmCache[cacheKey]=this._pwmStates.slice();
if(this._pidValues&&Object.keys(this._pidValues).length>0){
this._devicePidCache[cacheKey]=JSON.parse(JSON.stringify(this._pidValues));
}
}
this._activeDeviceIdx=idx;
localStorage.setItem('modbus_active_device',String(idx));
var dev=this._modbusDevices[idx];
var type=dev.deviceType||'relay';
var deviceOffline=dev.enabled===false;
this._setCtrlModalOffline(false);
var title=document.getElementById('modbus-ctrl-modal-title');
if(title)title.textContent=(dev.name||'Device')+' - '+(i18n.t('modbus-device-ctrl-title')||'设备控制');
var relayConfig=document.getElementById('modbus-relay-config');
var relayPanel=document.getElementById('modbus-relay-panel');
var pwmPanel=document.getElementById('modbus-pwm-panel');
var pidPanel=document.getElementById('modbus-pid-panel');
var motorPanel=document.getElementById('modbus-motor-panel');
[relayConfig,relayPanel,pwmPanel,pidPanel,motorPanel].forEach(function (el){
if(el)el.classList.remove('fb-hidden');
});
if(relayConfig)AppState.toggleVisible(relayConfig,type==='relay');
if(relayPanel)AppState.toggleVisible(relayPanel,type==='relay');
if(pwmPanel)AppState.toggleVisible(pwmPanel,type==='pwm');
if(pidPanel)AppState.toggleVisible(pidPanel,type==='pid');
if(motorPanel)AppState.toggleVisible(motorPanel,type==='motor');
this._updateDelayChannelSelect();
var newCacheKey='dev_'+idx;
if(type==='pwm'){
if(this._devicePwmCache[newCacheKey]){
this._pwmStates=this._devicePwmCache[newCacheKey].slice();
this._renderPwmGrid();
}else{
this._pwmStates=[];
this._renderPwmGrid(!deviceOffline);
if(!deviceOffline)this.refreshPwmStatus();
}
}else if(type==='pid'){
if(this._devicePidCache[newCacheKey]){
this._pidValues=JSON.parse(JSON.stringify(this._devicePidCache[newCacheKey]));
this._renderPidGrid();
}else{
this._pidValues={};
this._renderPidGrid(!deviceOffline);
if(!deviceOffline)this.refreshPidStatus();
}
}else if(type==='motor'){
if(!deviceOffline)this.refreshMotorStatus();
}else{
if(this._deviceCoilCache[newCacheKey]){
this._coilStates=this._deviceCoilCache[newCacheKey].slice();
this._renderCoilGrid();
}else{
this._coilStates=[];
this._renderCoilGrid();
if(!deviceOffline)this.refreshCoilStatus();
}
}
var modal=document.getElementById('modbus-device-ctrl-modal');
if(!modal){
console.error('[protocol] Modal element "modbus-device-ctrl-modal" not found in DOM');
return ;
}
AppState.showModal(modal);
if(deviceOffline){
this._setCtrlModalOffline(true,i18n.t('device-control-offline')||'设备离线，当前控制不可操作');
}
},
_closeCtrlModal(){
if(typeof this._stopCoilAutoRefresh==='function')this._stopCoilAutoRefresh();
if(typeof this._stopPidAutoRefresh==='function')this._stopPidAutoRefresh();
var autoEl=document.getElementById('modbus-ctrl-auto-refresh');
if(autoEl)autoEl.checked=false;
var pidAutoEl=document.getElementById('modbus-ctrl-pid-auto-refresh');
if(pidAutoEl)pidAutoEl.checked=false;
var modal=document.getElementById('modbus-device-ctrl-modal');
if(modal)AppState.hideModal(modal);
},
_activateDevice(idx){
this._openCtrlModal(idx);
},
onDeviceTypeChange(){
if(this._activeDeviceIdx<0||!this._modbusDevices)return ;
var dev=this._modbusDevices[this._activeDeviceIdx];
if(!dev)return ;
var type=dev.deviceType||'relay';
var types=['relay','pwm','pid'];
types.forEach(function (t){
var panel=document.getElementById('modbus-'+t+'-panel');
var config=document.getElementById('modbus-'+t+'-config');
if(panel)panel.classList.remove('fb-hidden');
if(config)config.classList.remove('fb-hidden');
if(panel)AppState.toggleVisible(panel,t===type);
if(config)AppState.toggleVisible(config,t===type);
});
},
onRelayModeChange(){
if(this._activeDeviceIdx<0||!this._modbusDevices)return ;
var dev=this._modbusDevices[this._activeDeviceIdx];
if(!dev)return ;
var mode=(dev.controlProtocol===1)?'register':'coil';
var hintEl=document.querySelector('#modbus-relay-config .field-hint');
if(hintEl){
hintEl.textContent=(mode==='register')
?(i18n.t('modbus-ctrl-reg-base-hint')||'寄存器起始地址，如M88继电器从0x0008开始')
:(i18n.t('modbus-ctrl-coil-base-hint')||'线圈起始地址，默认0');
}
},
_getPwmParams(){
var dev=(this._activeDeviceIdx>=0&&this._modbusDevices)
?this._modbusDevices[this._activeDeviceIdx]:null;
var res=dev?(dev.pwmResolution||8):8;
return {
slaveAddress:dev?(dev.slaveAddress||1):1,
channelCount:dev?(dev.channelCount||4):4,
regBase:dev?(dev.pwmRegBase||0):0,
resolution:res,
maxValue:(1<<res)-1
};
},
_renderPwmGrid(loading){
var grid=document.getElementById('pwm-channel-grid');
if(!grid)return ;
var p=this._getPwmParams();
var html='';
if(loading){
grid.innerHTML='<div class="fb-loading-placeholder pwm-loading-placeholder"><div class="fb-loading-placeholder-title">Loading...</div><div class="fb-loading-placeholder-detail">Loading PWM channel status</div></div>';
return ;
}
for(var i=0;i<p.channelCount;i++){
var val=i<this._pwmStates.length?this._pwmStates[i]:0;
var pct=p.maxValue>0?Math.round(val / p.maxValue*100):0;
html+='<div class="pwm-card">'
+'<div class="pwm-ch">CH'+i+'</div>'
+'<input type="range" class="pwm-slider" min="0" max="'+p.maxValue+'" value="'+val+'" data-ch="'+i+'">'
+'<div class="pwm-value-row">'
+'<input type="number" class="pwm-num-input" min="0" max="'+p.maxValue+'" value="'+val+'" data-ch="'+i+'">'
+'<span class="pwm-pct">'+pct+'%</span>'
+'</div></div>';
}
grid.innerHTML=html;
},
async refreshPwmStatus(){
var p=this._getPwmParams();
try{
var res=await apiGetSilent('/api/modbus/register/read',{
slaveAddress:p.slaveAddress,startAddress:p.regBase,
quantity:p.channelCount,functionCode:3
});
if(res&&res.success&&res.data&&res.data.values){
this._markCtrlModalOnline();
this._pwmStates=res.data.values;
var cacheKey='dev_'+this._activeDeviceIdx;
this._devicePwmCache[cacheKey]=this._pwmStates.slice();
this._renderPwmGrid();
this._appendDebugLog(res.debug,'ReadRegs FC03');
}else if(res&&!res.success){
this._setCtrlModalOffline(true,res.error||(i18n.t('device-control-offline')||'设备离线，当前控制不可操作'));
}
}catch(e){
if(this._pwmStates.length===0){
var p2=this._getPwmParams();
this._pwmStates=new Array(p2.channelCount).fill(0);
}
this._renderPwmGrid();
this._setCtrlModalOffline(true,i18n.t('device-control-offline')||'设备离线，当前控制不可操作');
}
},
async setPwmChannel(ch,value){
if(this._isCtrlModalOffline())return ;
var p=this._getPwmParams();
try{
var res=await apiPostPriority('/api/modbus/register/write',{
slaveAddress:p.slaveAddress,registerAddress:p.regBase+ch,value:value
});
if(res&&res.success){
if(ch<this._pwmStates.length)this._pwmStates[ch]=value;
this._appendDebugLog(res.debug,'WriteReg CH'+ch+'='+value);
}
}catch(e){
Notification.error(i18n.t('modbus-ctrl-fail'));
}
},
async batchPwm(action){
if(this._isCtrlModalOffline())return ;
var p=this._getPwmParams();
var values=[];
var fillVal=action==='max'?p.maxValue:0;
for(var i=0;i<p.channelCount;i++)values.push(fillVal);
try{
var res=await apiPostPriority('/api/modbus/register/batch-write',{
slaveAddress:p.slaveAddress,startAddress:p.regBase,
values:JSON.stringify(values)
});
if(res&&res.success){
this._pwmStates=values;
this._renderPwmGrid();
Notification.success(i18n.t('modbus-ctrl-success'));
}
}catch(e){
Notification.error(i18n.t('modbus-ctrl-fail'));
}
},
_onPwmSliderInput(ch,val){
var numInput=document.querySelector('.pwm-num-input[data-ch="'+ch+'"]');
var card=numInput?numInput.closest('.pwm-card'):null;
var pctSpan=card?card.querySelector('.pwm-pct'):null;
var p=this._getPwmParams();
if(numInput)numInput.value=val;
if(pctSpan)pctSpan.textContent=(p.maxValue>0?Math.round(val / p.maxValue*100):0)+'%';
},
_onPwmSliderChange(ch,val){
this.setPwmChannel(ch,parseInt(val));
},
_onPwmNumChange(ch,val){
var p=this._getPwmParams();
val=Math.max(0,Math.min (parseInt(val)||0,p.maxValue));
var slider=document.querySelector('.pwm-slider[data-ch="'+ch+'"]');
if(slider)slider.value=val;
var card=slider?slider.closest('.pwm-card'):null;
var pctSpan=card?card.querySelector('.pwm-pct'):null;
if(pctSpan)pctSpan.textContent=(p.maxValue>0?Math.round(val / p.maxValue*100):0)+'%';
this.setPwmChannel(ch,val);
},
_getPidParams(){
var dev=(this._activeDeviceIdx>=0&&this._modbusDevices)
?this._modbusDevices[this._activeDeviceIdx]:null;
var pidA=dev?(dev.pidAddrs||[0,1,2,3,4,5]):[0,1,2,3,4,5];
var decimals=dev?(dev.pidDecimals||1):1;
return {
slaveAddress:dev?(dev.slaveAddress||1):1,
pvAddr:pidA[0]||0,svAddr:pidA[1]||1,outAddr:pidA[2]||2,
pAddr:pidA[3]||3,iAddr:pidA[4]||4,dAddr:pidA[5]||5,
decimals:decimals,
scaleFactor:Math.pow(10,decimals)
};
},
_renderPidGrid(loading){
var container=document.getElementById('pid-data-grid');
if(!container)return ;
if(loading){
container.innerHTML='<div class="fb-loading-placeholder pid-loading-placeholder"><div class="fb-loading-placeholder-title">Loading...</div><div class="fb-loading-placeholder-detail">Loading PID data</div></div>';
return ;
}
var p=this._getPidParams();
var v=this._pidValues||{};
var sf=p.scaleFactor;
var fmtVal=function (raw,dec){
if(raw===undefined||raw===null)return '--';
return (raw / sf).toFixed(dec);
};
var fmtPct=function (raw){
if(raw===undefined||raw===null)return '--';
return (raw / sf).toFixed(p.decimals)+'%';
};
var cards=[
{key:'pv',label:i18n.t('modbus-ctrl-pid-pv-label')||'过程值 PV',value:fmtVal(v.pv,p.decimals),editable:false,big:true},
{key:'sv',label:i18n.t('modbus-ctrl-pid-sv-label')||'设定值 SV',value:fmtVal(v.sv,p.decimals),editable:true},
{key:'out',label:i18n.t('modbus-ctrl-pid-out-label')||'输出 %',value:fmtPct(v.out),editable:false},
{key:'p',label:i18n.t('modbus-ctrl-pid-p-label')||'P 比例',value:fmtVal(v.p,p.decimals),editable:true},
{key:'i',label:i18n.t('modbus-ctrl-pid-i-label')||'I 积分',value:fmtVal(v.i,p.decimals),editable:true},
{key:'d',label:i18n.t('modbus-ctrl-pid-d-label')||'D 微分',value:fmtVal(v.d,p.decimals),editable:true}
];
var html='';
for(var ci=0;ci<cards.length;ci++){
var c=cards[ci];
var cls='pid-card'+(c.big?' pid-pv-card':'')+(c.editable?' pid-editable':'');
html+='<div class="'+cls+'">';
html+='<div class="pid-card-label">'+c.label+'</div>';
if(c.editable){
var rawVal=(v[c.key]!==undefined&&v[c.key]!==null)?(v[c.key]/ sf).toFixed(p.decimals):'';
html+='<div class="pid-card-value">'+c.value+'</div>';
html+='<div class="pid-edit-row">';
html+='<input type="number" class="pid-input" step="'+(1 / sf)+'" value="'+rawVal+'" data-param="'+c.key+'">';
html+='<button type="button" class="fb-btn fb-btn-sm fb-btn-success pid-set-btn pid-set-btn-wide" data-param="'+c.key+'">'
+(i18n.t('modbus-ctrl-pid-set')||'设置')+'</button>';
html+='</div>';
}else{
html+='<div class="pid-card-value">'+c.value+'</div>';
}
html+='</div>';
}
container.innerHTML=html;
},
refreshPidStatus(){
var p=this._getPidParams();
if(!p.slaveAddress)return ;
var addrs=[p.pvAddr,p.svAddr,p.outAddr,p.pAddr,p.iAddr,p.dAddr];
var minAddr=Math.min .apply(null,addrs);
var maxAddr=Math.max.apply(null,addrs);
var quantity=maxAddr-minAddr+1;
if(quantity>125){
Notification.warning('PID 寄存器地址跨度过大 (>'+125+')');
return ;
}
var self=this;
apiGetSilent('/api/modbus/register/read',{
slaveAddress:p.slaveAddress,startAddress:minAddr,quantity:quantity,functionCode:3
}).then(function (res){
if(res&&res.success&&res.data&&res.data.values){
self._markCtrlModalOnline();
self._pidAutoRefreshErrors=0;
var vals=res.data.values;
self._pidValues={
pv:vals[p.pvAddr-minAddr],sv:vals[p.svAddr-minAddr],
out:vals[p.outAddr-minAddr],p:vals[p.pAddr-minAddr],
i:vals[p.iAddr-minAddr],d:vals[p.dAddr-minAddr]
};
var cacheKey='dev_'+self._activeDeviceIdx;
self._devicePidCache[cacheKey]=JSON.parse(JSON.stringify(self._pidValues));
self._renderPidGrid();
}else{
self._pidAutoRefreshErrors++;
self._stopPidAutoRefreshOnErrors();
self._setCtrlModalOffline(true,(res&&res.error)||(i18n.t('device-control-offline')||'设备离线，当前控制不可操作'));
}
if(res&&res.debug){
self._appendDebugLog(res.debug.tx?{tx:res.debug.tx,rx:res.debug.rx}:null,'PID Read');
}
}).catch(function (){
self._pidAutoRefreshErrors++;
self._stopPidAutoRefreshOnErrors();
if(!self._pidValues||Object.keys(self._pidValues).length===0){
self._pidValues={pv:0,sv:0,out:0,p:0,i:0,d:0};
}
self._renderPidGrid();
self._setCtrlModalOffline(true,i18n.t('device-control-offline')||'设备离线，当前控制不可操作');
});
},
setPidRegister(paramName,rawValue){
if(this._isCtrlModalOffline())return ;
var p=this._getPidParams();
var addrMap={sv:p.svAddr,p:p.pAddr,i:p.iAddr,d:p.dAddr};
var addr=addrMap[paramName];
if(addr===undefined)return ;
var self=this;
apiPostPriority('/api/modbus/register/write',{
slaveAddress:p.slaveAddress,registerAddress:addr,value:rawValue
}).then(function (res){
if(res&&res.success){
self._pidValues[paramName]=rawValue;
var cacheKey='dev_'+self._activeDeviceIdx;
self._devicePidCache[cacheKey]=JSON.parse(JSON.stringify(self._pidValues));
self._renderPidGrid();
}
if(res&&res.debug){
self._appendDebugLog(res.debug.tx?{tx:res.debug.tx,rx:res.debug.rx}:null,'PID Write '+paramName);
}
}).catch(function (){});
},
_onPidInputChange(paramName,displayValue){
var p=this._getPidParams();
var val=parseFloat(displayValue);
if(isNaN(val))return ;
var rawValue=Math.round(val*p.scaleFactor);
this.setPidRegister(paramName,rawValue);
},
_stopPidAutoRefresh(){
if(this._pidAutoRefreshTimer){
clearTimeout(this._pidAutoRefreshTimer);
this._pidAutoRefreshTimer=null;
}
},
_schedulePidAutoRefresh(){
var self=this;
this._stopPidAutoRefresh();
this._pidAutoRefreshTimer=setTimeout(function (){
self._pidAutoRefreshTimer=null;
var autoRefreshEl=document.getElementById('modbus-ctrl-pid-auto-refresh');
if(!autoRefreshEl||!autoRefreshEl.checked)return ;
Promise.resolve(self.refreshPidStatus()).finally(function (){
var nextAutoRefreshEl=document.getElementById('modbus-ctrl-pid-auto-refresh');
if(nextAutoRefreshEl&&nextAutoRefreshEl.checked){
self._schedulePidAutoRefresh();
}
});
},typeof apiGetPressureAwareInterval==='function'
?apiGetPressureAwareInterval('modbusControl',8000)
:8000);
},
togglePidAutoRefresh(){
var checked=document.getElementById('modbus-ctrl-pid-auto-refresh')?.checked;
if(checked){
this._pidAutoRefreshErrors=0;
this.refreshPidStatus();
this._schedulePidAutoRefresh();
}else{
this._stopPidAutoRefresh();
}
}
});
})();
(function (){
Object.assign(AppState,{
_getCoilParams(){
var dev=(this._activeDeviceIdx>=0&&this._modbusDevices[this._activeDeviceIdx])
?this._modbusDevices[this._activeDeviceIdx]:{};
return {
slaveAddress:dev.slaveAddress||1,
channelCount:dev.channelCount||8,
coilBase:dev.coilBase||0,
ncMode:!!dev.ncMode,
relayMode:(dev.controlProtocol===1)?'register':'coil'
};
},
async refreshCoilStatus(){
const p=this._getCoilParams();
try{
const res=await apiGetSilent('/api/modbus/coil/status',{
slaveAddress:p.slaveAddress,channelCount:p.channelCount,
coilBase:p.coilBase,mode:p.relayMode
});
if(res&&res.success&&res.data&&res.data.states){
this._markCtrlModalOnline();
this._coilAutoRefreshErrors=0;
this._coilStates=res.data.states;
var cacheKey='dev_'+this._activeDeviceIdx;
this._deviceCoilCache[cacheKey]=this._coilStates.slice();
this._renderCoilGrid();
this._appendDebugLog(res.debug,'ReadCoils FC01');
}else if(res&&!res.success){
this._coilAutoRefreshErrors++;
this._stopAutoRefreshOnErrors();
this._setCtrlModalOffline(true,res.error||(i18n.t('device-control-offline')||'设备离线，当前控制不可操作'));
Notification.error(res.error||i18n.t('modbus-ctrl-fail'));
this._appendDebugError(res.error||'ReadCoils failed',res.debug);
}else{
if(this._coilStates.length===0){
for(var i=0;i<p.channelCount;i++)this._coilStates.push(false);
}
this._renderCoilGrid();
}
}catch(e){
this._coilAutoRefreshErrors++;
this._stopAutoRefreshOnErrors();
if(this._coilStates.length===0){
for(var i=0;i<p.channelCount;i++)this._coilStates.push(false);
}
this._renderCoilGrid();
this._setCtrlModalOffline(true,i18n.t('device-control-offline')||'设备离线，当前控制不可操作');
}
},
_renderCoilGrid(){
const grid=document.getElementById('coil-status-grid');
if(!grid)return ;
const p=this._getCoilParams();
const onText=i18n.t('modbus-ctrl-status-on')||'ON';
const offText=i18n.t('modbus-ctrl-status-off')||'OFF';
let html='';
for(let i=0;i<p.channelCount;i++){
const coilState=i<this._coilStates.length?this._coilStates[i]:false;
const isOn=p.ncMode?!coilState:coilState;
const cls=isOn?'coil-on':'coil-off';
html+='<div class="coil-card '+cls+'" data-ch="'+i+'">'
+'<div class="coil-ch">CH'+i+'</div>'
+'<div class="coil-st">'+(isOn?onText:offText)+'</div>'
+'</div>';
}
grid.innerHTML=html;
},
async toggleCoil(ch){
if(this._isCtrlModalOffline())return ;
const card=document.querySelector('.coil-card[data-ch="'+ch+'"]');
if(card)card.classList.add('coil-loading');
const p=this._getCoilParams();
try{
const res=await apiPostPriority('/api/modbus/coil/control',{
slaveAddress:p.slaveAddress,channel:ch,coilBase:p.coilBase,
action:'toggle',mode:p.relayMode
});
if(res&&res.success&&res.data){
if(ch<this._coilStates.length)this._coilStates[ch]=res.data.state;
this._renderCoilGrid();
Notification.success(i18n.t('modbus-ctrl-success'));
this._appendDebugLog(res.debug,'Toggle CH'+ch);
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Toggle CH'+ch+' failed',res&&res.debug);
}
}catch(e){
Notification.error(i18n.t('modbus-ctrl-fail'));
}
if(card)card.classList.remove('coil-loading');
},
async batchCoil(action){
if(this._isCtrlModalOffline())return ;
const p=this._getCoilParams();
let modbusAction=action;
if(p.ncMode){
if(action==='allOn')modbusAction='allOff';
else if(action==='allOff')modbusAction='allOn';
}
try{
const res=await apiPostPriority('/api/modbus/coil/batch',{
slaveAddress:p.slaveAddress,channelCount:p.channelCount,
coilBase:p.coilBase,action:modbusAction,mode:p.relayMode
});
if(res&&res.success&&res.data&&res.data.states){
this._coilStates=res.data.states;
this._renderCoilGrid();
Notification.success(i18n.t('modbus-ctrl-success'));
this._appendDebugLog(res.debug,'Batch: '+action);
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Batch '+action+' failed',res&&res.debug);
}
}catch(e){
Notification.error(i18n.t('modbus-ctrl-fail'));
}
},
async startCoilDelay(){
if(this._isCtrlModalOffline())return ;
const p=this._getCoilParams();
const ch=parseInt(document.getElementById('modbus-ctrl-delay-ch')?.value||'0');
const units=parseInt(document.getElementById('modbus-ctrl-delay-units')?.value||'50');
if(units<1||units>255){
Notification.warning(i18n.t('modbus-ctrl-fail')+': 1-255 (x100ms)');
return ;
}
try{
const params={
slaveAddress:p.slaveAddress,channel:ch,delayBase:0x0200,
delayUnits:units,ncMode:p.ncMode,coilBase:p.coilBase
};
const res=await apiPostPriority('/api/modbus/coil/delay',params);
if(res&&res.success){
Notification.success(i18n.t('modbus-ctrl-delay-ok'));
this._appendDebugLog(res.debug,'Delay CH'+ch+' '+units+'x100ms'+(p.ncMode?' (NC)':''));
const refreshDelay=p.ncMode?(units*100+500):500;
setTimeout(()=>this.refreshCoilStatus(),refreshDelay);
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Delay CH'+ch+' failed',res&&res.debug);
}
}catch(e){
Notification.error(i18n.t('modbus-ctrl-fail'));
}
},
onCoilChannelCountChange(){
this._updateDelayChannelSelect();
this._renderCoilGrid();
},
_updateDelayChannelSelect(){
const sel=document.getElementById('modbus-ctrl-delay-ch');
if(!sel)return ;
var dev=(this._activeDeviceIdx>=0&&this._modbusDevices)
?this._modbusDevices[this._activeDeviceIdx]:null;
const count=dev?(dev.channelCount||8):8;
let html='';
for(let i=0;i<count;i++){
html+='<option value="'+i+'">CH'+i+'</option>';
}
sel.innerHTML=html;
},
toggleCoilAutoRefresh(){
const checked=document.getElementById('modbus-ctrl-auto-refresh')?.checked;
if(checked){
this._coilAutoRefreshErrors=0;
this.refreshCoilStatus();
this._scheduleCoilAutoRefresh();
}else{
this._stopCoilAutoRefresh();
}
},
_getModbusControlRefreshInterval(){
if(typeof apiGetPressureAwareInterval==='function'){
return apiGetPressureAwareInterval('modbusControl',8000);
}
return 8000;
},
_scheduleCoilAutoRefresh(){
var self=this;
this._stopCoilAutoRefresh();
this._coilAutoRefreshTimer=setTimeout(function (){
self._coilAutoRefreshTimer=null;
var autoRefreshEl=document.getElementById('modbus-ctrl-auto-refresh');
if(!autoRefreshEl||!autoRefreshEl.checked)return ;
Promise.resolve(self.refreshCoilStatus()).finally(function (){
var nextAutoRefreshEl=document.getElementById('modbus-ctrl-auto-refresh');
if(nextAutoRefreshEl&&nextAutoRefreshEl.checked){
self._scheduleCoilAutoRefresh();
}
});
},this._getModbusControlRefreshInterval());
},
_stopCoilAutoRefresh(){
if(this._coilAutoRefreshTimer){
clearTimeout(this._coilAutoRefreshTimer);
this._coilAutoRefreshTimer=null;
}
},
_stopAutoRefreshOnErrors(){
if(this._coilAutoRefreshErrors>=3){
this._stopCoilAutoRefresh();
var el=document.getElementById('modbus-ctrl-auto-refresh');
if(el)el.checked=false;
console.warn('[protocol] Coil auto-refresh stopped after',this._coilAutoRefreshErrors,'consecutive errors');
}
},
_stopPidAutoRefreshOnErrors(){
if(this._pidAutoRefreshErrors>=3){
if(typeof this._stopPidAutoRefresh==='function'){
this._stopPidAutoRefresh();
}
var el=document.getElementById('modbus-ctrl-pid-auto-refresh');
if(el)el.checked=false;
console.warn('[protocol] PID auto-refresh stopped after',this._pidAutoRefreshErrors,'consecutive errors');
}
},
async readDiscreteInputs(){
const slaveAddr=parseInt(document.getElementById('modbus-debug-slave-addr')?.value||'0');
const inputCount=parseInt(document.getElementById('modbus-ctrl-input-count')?.value||'4');
const inputBase=parseInt(document.getElementById('modbus-ctrl-input-base')?.value||'0');
try{
const res=await apiGet('/api/modbus/device/inputs',{slaveAddress:slaveAddr,inputCount:inputCount,inputBase:inputBase});
const display=document.getElementById('modbus-ctrl-inputs-display');
if(res&&res.success&&res.data&&res.data.states){
const states=res.data.states;
if(display){
display.innerHTML='';
var chipList=document.createElement('div');
chipList.className='protocol-chip-list';
for(var si=0;si<states.length;si++){
var chip=document.createElement('span');
chip.className='protocol-chip'+(states[si]?' is-on':'');
chip.textContent='IN'+si+':'+(states[si]?'ON':'OFF');
chipList.appendChild(chip);
}
display.appendChild(chipList);
}
Notification.success(i18n.t('modbus-ctrl-success'));
this._appendDebugLog(res.debug,'ReadInputs FC02');
}else{
if(display)display.innerHTML='';
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('ReadInputs failed',res&&res.debug);
}
}catch(e){Notification.error(i18n.t('modbus-ctrl-fail'));}
},
_getMotorDevParams(){
var idx=this._activeDeviceIdx;
if(idx<0||!this._modbusDevices||!this._modbusDevices[idx])return null;
var dev=this._modbusDevices[idx];
return {
slaveAddress:dev.slaveAddress||1,
motorRegs:dev.motorRegs||[0,1,2,5,7],
motorDecimals:dev.motorDecimals||0
};
},
async motorForward(){
if(this._isCtrlModalOffline())return ;
var p=this._getMotorDevParams();
if(!p)return ;
try{
var res=await apiPostSilentPriority('/api/modbus/motor/control',{slaveAddress:p.slaveAddress,action:'forward'});
if(res&&res.success){
Notification.success(i18n.t('modbus-motor-ctrl-forward-ok')||'正转指令已发送');
this._appendDebugLog(res.debug,'Motor Forward');
document.getElementById('motor-cur-direction').textContent='← '+(i18n.t('modbus-motor-ctrl-forward')||'正转');
var elRun=document.getElementById('modbus-ctrl-motor-run-status');
if(elRun){elRun.className='motor-run-badge motor-run-forward';elRun.textContent=i18n.t('modbus-motor-dir-forward')||'正转中';}
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Motor Forward failed',res&&res.debug);
}
}catch(e){Notification.error(i18n.t('modbus-ctrl-fail'));}
},
async motorReverse(){
if(this._isCtrlModalOffline())return ;
var p=this._getMotorDevParams();
if(!p)return ;
try{
var res=await apiPostSilentPriority('/api/modbus/motor/control',{slaveAddress:p.slaveAddress,action:'reverse'});
if(res&&res.success){
Notification.success(i18n.t('modbus-motor-ctrl-reverse-ok')||'反转指令已发送');
this._appendDebugLog(res.debug,'Motor Reverse');
document.getElementById('motor-cur-direction').textContent='→ '+(i18n.t('modbus-motor-ctrl-reverse')||'反转');
var elRun=document.getElementById('modbus-ctrl-motor-run-status');
if(elRun){elRun.className='motor-run-badge motor-run-reverse';elRun.textContent=i18n.t('modbus-motor-dir-reverse')||'反转中';}
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Motor Reverse failed',res&&res.debug);
}
}catch(e){Notification.error(i18n.t('modbus-ctrl-fail'));}
},
async motorStop(){
if(this._isCtrlModalOffline())return ;
var p=this._getMotorDevParams();
if(!p)return ;
try{
var res=await apiPostSilentPriority('/api/modbus/motor/control',{slaveAddress:p.slaveAddress,action:'stop'});
if(res&&res.success){
Notification.success(i18n.t('modbus-motor-ctrl-stop-ok')||'停止指令已发送');
this._appendDebugLog(res.debug,'Motor Stop');
document.getElementById('motor-cur-direction').textContent=i18n.t('modbus-motor-status-stop')||'停止';
var elRun=document.getElementById('modbus-ctrl-motor-run-status');
if(elRun){elRun.className='motor-run-badge motor-run-stopped';elRun.textContent=i18n.t('modbus-motor-status-stop')||'停止';}
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Motor Stop failed',res&&res.debug);
}
}catch(e){Notification.error(i18n.t('modbus-ctrl-fail'));}
},
async setMotorSpeed(){
if(this._isCtrlModalOffline())return ;
var p=this._getMotorDevParams();
if(!p)return ;
var speed=parseInt(document.getElementById('modbus-ctrl-motor-speed').value)||50;
try{
var res=await apiPostSilentPriority('/api/modbus/motor/control',{slaveAddress:p.slaveAddress,action:'setSpeed',value:speed});
if(res&&res.success){
Notification.success(i18n.t('modbus-motor-ctrl-speed-ok')||'速度设置成功');
this._appendDebugLog(res.debug,'Motor SetSpeed');
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Motor SetSpeed failed',res&&res.debug);
}
}catch(e){Notification.error(i18n.t('modbus-ctrl-fail'));}
},
async setMotorPulse(){
if(this._isCtrlModalOffline())return ;
var p=this._getMotorDevParams();
if(!p)return ;
var pulse=parseInt(document.getElementById('modbus-ctrl-motor-pulse').value)||1600;
try{
var res=await apiPostSilentPriority('/api/modbus/motor/control',{slaveAddress:p.slaveAddress,action:'setPulse',value:pulse});
if(res&&res.success){
Notification.success(i18n.t('modbus-motor-ctrl-pulse-ok')||'脉冲数设置成功');
this._appendDebugLog(res.debug,'Motor SetPulse');
}else{
Notification.error((res&&res.error)||i18n.t('modbus-ctrl-fail'));
this._appendDebugError('Motor SetPulse failed',res&&res.debug);
}
}catch(e){Notification.error(i18n.t('modbus-ctrl-fail'));}
},
async refreshMotorStatus(){
var p=this._getMotorDevParams();
if(!p)return ;
try{
var res=await apiPostSilent('/api/modbus/motor/control',{slaveAddress:p.slaveAddress,action:'readStatus'});
if(res&&res.success&&res.data){
this._markCtrlModalOnline();
var data=res.data;
var sf=Math.pow(10,p.motorDecimals||0);
var elSpeed=document.getElementById('motor-cur-speed');
var elPulse=document.getElementById('motor-cur-pulse');
var elDir=document.getElementById('motor-cur-direction');
var elCount=document.getElementById('motor-cur-count');
var elRun=document.getElementById('modbus-ctrl-motor-run-status');
if(data.speed!==undefined&&elSpeed)elSpeed.textContent=(data.speed / sf).toFixed(p.motorDecimals||0);
if(data.pulse!==undefined&&elPulse)elPulse.textContent=data.pulse;
if(elDir){
if(data.direction==='forward'||data.direction===1){
elDir.textContent='← '+(i18n.t('modbus-motor-ctrl-forward')||'正转');
}else if(data.direction==='reverse'||data.direction===-1){
elDir.textContent='→ '+(i18n.t('modbus-motor-ctrl-reverse')||'反转');
}else{
elDir.textContent=i18n.t('modbus-motor-status-stop')||'停止';
}
}
if(data.count!==undefined&&elCount)elCount.textContent=data.count+' '+(i18n.t('modbus-motor-count')||'次');
if(elRun){
var dir=data.direction||'';
elRun.className='motor-run-badge '+(dir==='forward'||dir===1?'motor-run-forward':dir==='reverse'||dir===-1?'motor-run-reverse':'motor-run-stopped');
elRun.textContent=(dir==='forward'||dir===1)?(i18n.t('modbus-motor-dir-forward')||'正转中'):(dir==='reverse'||dir===-1)?(i18n.t('modbus-motor-dir-reverse')||'反转中'):(i18n.t('modbus-motor-status-stop')||'停止');
}
this._appendDebugLog(res.debug,'Motor ReadStatus');
}else{
this._appendDebugError('Motor ReadStatus failed',res&&res.debug);
this._setCtrlModalOffline(true,(res&&res.error)||(i18n.t('device-control-offline')||'设备离线，当前控制不可操作'));
}
}catch(e){
console.error('refreshMotorStatus failed:',e);
this._setCtrlModalOffline(true,i18n.t('device-control-offline')||'设备离线，当前控制不可操作');
}
},
_appendDebugLog(debug,label){
var log=document.getElementById('modbus-debug-log');
if(!log)return ;
if(!debug&&!label)return ;
var time=new Date().toLocaleTimeString();
var entry=document.createElement('div');
entry.className='modbus-debug-entry';
var html='<div class="modbus-debug-time">['+escapeHtml(time)+'] '+escapeHtml(label||'')+'</div>';
if(debug&&debug.tx)html+='<div class="modbus-debug-tx">TX: '+escapeHtml(debug.tx)+'</div>';
if(debug&&debug.rx)html+='<div class="modbus-debug-rx">RX: '+escapeHtml(debug.rx)+'</div>';
entry.innerHTML=html;
log.appendChild(entry);
log.scrollTop=log.scrollHeight;
while(log.children.length>100)log.removeChild(log.firstChild);
},
_appendDebugError(msg,debug){
var log=document.getElementById('modbus-debug-log');
if(!log)return ;
var time=new Date().toLocaleTimeString();
var entry=document.createElement('div');
entry.className='modbus-debug-entry';
var html='<div class="modbus-debug-time">['+escapeHtml(time)+']</div>';
html+='<div class="modbus-debug-err">'+escapeHtml(msg)+'</div>';
if(debug&&debug.tx)html+='<div class="modbus-debug-tx">TX: '+escapeHtml(debug.tx)+'</div>';
if(debug&&debug.rx)html+='<div class="modbus-debug-rx">RX: '+escapeHtml(debug.rx)+'</div>';
entry.innerHTML=html;
log.appendChild(entry);
log.scrollTop=log.scrollHeight;
while(log.children.length>100)log.removeChild(log.firstChild);
},
clearModbusDebugLog(){
var log=document.getElementById('modbus-debug-log');
if(log)log.innerHTML='';
}
});
})();