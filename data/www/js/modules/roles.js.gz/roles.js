(function (){
AppState.registerModule('roles',{
setupRolesEvents(){
const closeId=(id)=>{this.hideModal(id);};
const addRoleBtn=document.getElementById('add-role-btn');
if(addRoleBtn){
if(AppState.hasPermission('role.admin')){
addRoleBtn.addEventListener('click',()=>this.showAddRoleModal());
}else{
addRoleBtn.style.display='none';
}
}
['close-role-modal','cancel-role-btn'].forEach(id=>{
const el=document.getElementById(id);
if(el)el.addEventListener('click',()=>closeId('role-modal'));
});
const confirmRole=document.getElementById('confirm-role-btn');
if(confirmRole)confirmRole.addEventListener('click',()=>this.saveRole());
const rolesRefreshBtn=document.getElementById('roles-refresh-btn');
if(rolesRefreshBtn)rolesRefreshBtn.addEventListener('click',()=>this._refreshRolesList());
},
_refreshRolesList(){
var btn=document.getElementById('roles-refresh-btn');
if(btn&&btn.disabled)return ;
if(btn){btn.disabled=true;btn.textContent='加载中...';}
if(typeof window.apiInvalidateCache==='function'){
window.apiInvalidateCache('/api/roles');
}
this.loadRoles({noCache:true});
setTimeout(function (){
if(btn){btn.disabled=false;btn.innerHTML='&#x21bb; 刷新';}
},2000);
},
loadRoles(options){
var getter=(options&&options.noCache===true&&typeof apiGetFresh==='function')?apiGetFresh:apiGet;
getter('/api/roles')
.then(res=>{
if(!res||!res.success)return ;
const roles=(res.data&&res.data.roles)?res.data.roles:[];
const permissions=(res.data&&res.data.permissions)?res.data.permissions:[];
this._permDefs=permissions;
this._renderRolesList(roles);
})
.catch(()=>{});
},
_renderRolesList(roles){
const tbody=document.getElementById('roles-table-body');
if(!tbody)return ;
tbody.innerHTML='';
roles.forEach(role=>{
const row=document.createElement('tr');
const tdId=document.createElement('td');
tdId.textContent=role.id;
row.appendChild(tdId);
const tdName=document.createElement('td');
const _rnm={'管理员':'role-admin','操作员':'role-operator','查看者':'role-viewer'};
const _rnmZh={'管理员':'管理员','操作员':'操作员','查看者':'查看者'};
const dName=_rnmZh[role.name]||role.name;
tdName.textContent=dName;
row.appendChild(tdName);
const tdDesc=document.createElement('td');
tdDesc.textContent=role.description||'—';
tdDesc.className='role-desc-cell';
row.appendChild(tdDesc);
const tdPermCount=document.createElement('td');
const permCount=(role.permissions||[]).length;
var pillSpan=document.createElement('span');
pillSpan.className='role-pill role-pill--count';
pillSpan.textContent=permCount;
tdPermCount.appendChild(pillSpan);
row.appendChild(tdPermCount);
const tdType=document.createElement('td');
var typeSpan=document.createElement('span');
if(role.id==='admin'){
typeSpan.className='role-pill role-pill--super';
typeSpan.textContent='超级管理员';
}else if(role.isBuiltin ){
typeSpan.className='role-pill role-pill--builtin';
typeSpan.textContent='内置角色';
}else{
typeSpan.className='role-pill role-pill--custom';
typeSpan.textContent='自定义';
}
tdType.appendChild(typeSpan);
row.appendChild(tdType);
const tdAction=document.createElement('td');
tdAction.className='u-toolbar-sm';
const canManageRoles=AppState.hasPermission('role.admin');
const viewBtn=document.createElement('button');
viewBtn.className='fb-btn fb-btn-sm fb-btn-secondary';
viewBtn.textContent='查看权限';
viewBtn.addEventListener('click',()=>this.showRolePermissions(role));
tdAction.appendChild(viewBtn);
if(role.id!=='admin'){
const editBtn=document.createElement('button');
editBtn.className='fb-btn fb-btn-sm fb-btn-primary fb-btn-action-edit fb-mr-1';
editBtn.textContent='编辑';
if(canManageRoles){
editBtn.addEventListener('click',()=>this.showEditRoleModal(role.id));
}else{
editBtn.disabled=true;
editBtn.title='没有操作权限';
}
tdAction.appendChild(editBtn);
const delBtn=document.createElement('button');
delBtn.className='fb-btn fb-btn-sm fb-btn-danger';
delBtn.textContent='删除';
if(canManageRoles){
delBtn.addEventListener('click',()=>{
const dName2=role.name;
this.deleteRole(role.id,dName2);
});
}else{
delBtn.disabled=true;
delBtn.title='没有操作权限';
}
tdAction.appendChild(delBtn);
}
row.appendChild(tdAction);
tbody.appendChild(row);
});
},
showRolePermissions(role){
const permDefs=this._permDefs||[];
const rolePerms=new Set(role.permissions||[]);
const _gpk={
'设备':'device','Device':'device',
'网络':'network','Network':'network',
'系统':'system','System':'system',
'用户':'user','Users':'user',
'文件':'file','Files':'file',
'协议':'protocol','Protocol':'protocol',
'审计':'audit','Audit':'audit',
'GPIO':'gpio',
'外设':'peripheral','Peripheral':'peripheral'
};
const permGroups={};
permDefs.forEach(p=>{
if(!permGroups[p.group])permGroups[p.group]=[];
permGroups[p.group].push(p);
});
let html=`<div class="role-perm-sheet">`;
Object.keys(permGroups).sort().forEach(group=>{
const _permGroupZh={'device':'设备','network':'网络','system':'系统','user':'用户','file':'文件','protocol':'协议','audit':'审计','gpio':'GPIO','peripheral':'外设'};
const gKey=_gpk[group]?(_permGroupZh[_gpk[group]]||group):group;
html+=`<div class="role-perm-group">`;
html+=`<h4 class="role-perm-group-title">${gKey}</h4>`;
html+=`<div class="role-perm-chip-list">`;
permGroups[group].forEach(perm=>{
const hasPerm=rolePerms.has(perm.id);
const pName=perm.name;
const pDesc=perm.description||perm.name;
html+=`<span class="role-perm-chip${hasPerm ? ' is-enabled' : ''}">`;
html+=`<span class="role-perm-chip-indicator">${hasPerm?'✓':'✗'}</span>`;
html+=`<span title="${escapeHtml(pDesc)}">${escapeHtml(pName)}</span></span>`;
});
html+=`</div></div>`;
});
html+=`</div>`;
const roleNameMap={'管理员':'管理员','操作员':'操作员','查看者':'查看者'};
const displayRoleName=roleNameMap[role.name]||role.name;
const overlay=document.createElement('div');
overlay.className='role-perm-overlay';
overlay.innerHTML=`
<div class="role-perm-dialog">
<div class="role-perm-dialog-header">
<h3 class="role-perm-dialog-title">${escapeHtml(displayRoleName)}-权限详情</h3>
<button type="button" class="role-perm-dialog-close">×</button>
</div>
<div class="role-perm-dialog-body">${html}</div>
</div>
`;
overlay.addEventListener('click',(e)=>{
if(e.target===overlay)overlay.remove();
});
const closeBtn=overlay.querySelector('.role-perm-dialog-close');
if(closeBtn){
closeBtn.addEventListener('click',()=>overlay.remove());
}
const dialog=overlay.querySelector('.role-perm-dialog');
if(dialog){
dialog.addEventListener('click',(e)=>e.stopPropagation());
}
document.body.appendChild(overlay);
},
showAddRoleModal(){
const modal=document.getElementById('role-modal');
if(!modal)return ;
const title=document.getElementById('role-modal-title');
if(title)title.textContent='新增角色';
const idInput=document.getElementById('role-id-input');
const nameInput=document.getElementById('role-name-input');
const descInput=document.getElementById('role-desc-input');
if(idInput){idInput.value='';idInput.disabled=false;}
if(nameInput)nameInput.value='';
if(descInput)descInput.value='';
modal.dataset.editMode='add';
modal.dataset.editRoleId='';
this._renderPermissionCheckboxes([]);
AppState.clearInlineError('role-error');
AppState.showModal(modal);
},
showEditRoleModal(roleId){
const modal=document.getElementById('role-modal');
if(!modal){
console.error('[showEditRoleModal] modal not found!');
return ;
}
modal.dataset.editMode='edit';
modal.dataset.editRoleId=roleId;
var getter=(typeof apiGetFresh==='function')?apiGetFresh:apiGet;
getter('/api/roles')
.then(res=>{
if(!res||!res.success)return ;
const roles=(res.data&&res.data.roles)?res.data.roles:[];
const role=roles.find(r=>r.id===roleId);
if(!role){
Notification.error('角色不存在','错误');
return ;
}
const title=document.getElementById('role-modal-title');
if(title)title.textContent='编辑角色';
const idInput=document.getElementById('role-id-input');
const nameInput=document.getElementById('role-name-input');
const descInput=document.getElementById('role-desc-input');
if(idInput){idInput.value=role.id;idInput.disabled=true;}
if(nameInput)nameInput.value=role.name;
if(descInput)descInput.value=role.description||'';
this._renderPermissionCheckboxes(role.permissions||[]);
AppState.clearInlineError('role-error');
AppState.showModal(modal);
})
.catch(()=>{});
},
_renderPermissionCheckboxes(selectedPerms){
const container=document.getElementById('role-permissions-container');
if(!container)return ;
container.innerHTML='';
const permDefs=this._permDefs||[];
const selectedSet=new Set(selectedPerms);
const _gpk={
'设备':'device','Device':'device',
'网络':'network','Network':'network',
'系统':'system','System':'system',
'用户':'user','Users':'user',
'文件':'file','Files':'file',
'协议':'protocol','Protocol':'protocol',
'审计':'audit','Audit':'audit',
'GPIO':'gpio',
'外设':'peripheral','Peripheral':'peripheral'
};
const permGroups={};
permDefs.forEach(p=>{
if(!permGroups[p.group])permGroups[p.group]=[];
permGroups[p.group].push(p);
});
Object.keys(permGroups).sort().forEach(group=>{
const groupDiv=document.createElement('div');
groupDiv.className='role-perm-group';
const _permGroupZh2={'device':'设备','network':'网络','system':'系统','user':'用户','file':'文件','protocol':'协议','audit':'审计','gpio':'GPIO','peripheral':'外设'};
const gKey=_gpk[group]?(_permGroupZh2[_gpk[group]]||group):group;
const groupTitle=document.createElement('h5');
groupTitle.className='role-perm-group-title';
groupTitle.textContent=gKey;
groupDiv.appendChild(groupTitle);
const permList=document.createElement('div');
permList.className='role-perm-list';
permGroups[group].forEach(perm=>{
const pName=perm.name;
const pDesc=perm.description||perm.name;
const label=document.createElement('label');
label.className='role-perm-label fb-checkbox';
var checkbox=document.createElement('input');
checkbox.type='checkbox';
checkbox.name='role-perm';
checkbox.value=perm.id;
if(selectedSet.has(perm.id))checkbox.checked=true;
label.appendChild(checkbox);
var labelText=document.createElement('span');
labelText.title=pDesc;
labelText.textContent=pName;
label.appendChild(labelText);
permList.appendChild(label);
});
groupDiv.appendChild(permList);
container.appendChild(groupDiv);
});
},
saveRole(){
const modal=document.getElementById('role-modal');
if(!modal){
Notification.error('弹窗元素不存在','错误');
return ;
}
const isEditMode=modal.dataset.editMode==='edit';
const editRoleId=modal.dataset.editRoleId||'';
const idInput=document.getElementById('role-id-input');
const id=isEditMode?editRoleId:(idInput?idInput.value.trim():'');
const name=((document.getElementById('role-name-input')||{}).value||'').trim();
const description=((document.getElementById('role-desc-input')||{}).value||'').trim();
const errDiv=document.getElementById('role-error');
const showErr=(msg)=>{
AppState.showInlineError('role-error',msg);
Notification.error(msg,isEditMode?'编辑角色失败':'新增角色失败');
};
if(!id)return showErr('请输入角色ID！');
if(!name)return showErr('请输入角色名称！');
const permCheckboxes=document.querySelectorAll('input[name="role-perm"]:checked');
const permissions=Array.from(permCheckboxes).map(cb=>cb.value).join (',');
AppState.clearInlineError('role-error');
const btn=document.getElementById('confirm-role-btn');
if(btn){btn.disabled=true;btn.textContent='保存中...';}
let apiCall;
if(isEditMode){
apiCall=apiPutForm('/api/roles/'+encodeURIComponent(id),{name,description})
.then(res=>{
if(res&&res.success){
return apiPutForm('/api/roles/'+encodeURIComponent(id)+'/permissions',{permissions});
}
throw new Error(res.error||'更新角色失败');
});
}else{
apiCall=apiPost('/api/roles',{id,name,description})
.then(res=>{
if(res&&res.success){
return apiPutForm('/api/roles/'+encodeURIComponent(id)+'/permissions',{permissions});
}
throw new Error(res.error||'创建角色失败');
});
}
apiCall
.then(res=>{
if(res&&res.success){
Notification.success(`角色管理:${name}${isEditMode?'修改':'创建'}成功`,'角色管理');
if(modal)AppState.hideModal(modal);
if(typeof window.apiInvalidateCache==='function'){
window.apiInvalidateCache('/api/roles');
}
this.loadRoles({noCache:true});
}else{
showErr((res&&res.error)||'操作失败');
}
})
.catch(err=>{
showErr(err.message||'操作失败');
})
.finally(()=>{
if(btn){btn.disabled=false;btn.textContent='保存';}
});
},
deleteRole(roleId,roleName){
if(!confirm(`确定要删除角色 "${roleName || roleId}" 吗？`))return ;
apiDelete('/api/roles/'+encodeURIComponent(roleId))
.then(res=>{
if(res&&res.success){
Notification.success(`${roleName||roleId}已删除`,'删除成功');
if(typeof window.apiInvalidateCache==='function'){
window.apiInvalidateCache('/api/roles');
}
this.loadRoles({noCache:true});
}else{
Notification.error((res&&res.error)||'操作失败','操作失败');
}
})
.catch(()=>{});
}
});
if(typeof AppState.setupRolesEvents==='function'){
AppState.setupRolesEvents();
}
})();