const Notification={
container:null,notifications:[],
init(){
this.container=document.getElementById('notification-container');
if(!this.container){this.container=document.createElement('div');this.container.id='notification-container';this.container.className='notification-container';document.body.appendChild(this.container);}
},
show(options){
const id='notification-'+Date.now();const duration=options.duration||3000;
const notification=document.createElement('div');notification.id=id;
notification.className='notification notification-'+(options.type||'info');
const icons={primary:'✅',success:'✅',warning:'⚠️',error:'❌',info:'ℹ️'};
const header=document.createElement('div');
header.className='notification-header';
const title=document.createElement('div');
title.className='notification-title';
const icon=document.createElement('i');
icon.textContent=icons[options.type]||icons.info;
const titleText=document.createElement('span');
titleText.textContent=options.title||this.getDefaultTitle(options.type);
title.appendChild(icon);
title.appendChild(titleText);
const closeBtn=document.createElement('button');
closeBtn.type='button';
closeBtn.className='notification-close';
closeBtn.textContent='×';
closeBtn.addEventListener('click',()=>this.close(id));
header.appendChild(title);
header.appendChild(closeBtn);
const body=document.createElement('div');
body.className='notification-body';
if(options.html===true){body.innerHTML=options.message||'';}
else{body.textContent=options.message||'';}
const progress=document.createElement('div');
progress.className='notification-progress';
const progressBar=document.createElement('div');
progressBar.className='notification-progress-bar';
progressBar.style.setProperty('--notification-duration',duration+'ms');
progress.appendChild(progressBar);
notification.appendChild(header);
notification.appendChild(body);
notification.appendChild(progress);
this.container.appendChild(notification);
const notificationObj={id:id,element:notification,timeout:null};this.notifications.push(notificationObj);
if(options.autoClose!==false){notificationObj.timeout=setTimeout(()=>{this.close(id);},duration);}
return id;
},
close(id){
const notification=document.getElementById(id);
if(notification){notification.classList.add('hiding');
const notificationObj=this.notifications.find(n=>n.id===id);
if(notificationObj&&notificationObj.timeout){clearTimeout(notificationObj.timeout);}
setTimeout(()=>{if(notification.parentNode){notification.parentNode.removeChild(notification);}this.notifications=this.notifications.filter(n=>n.id!==id);},300);
}
},
closeAll(){this.notifications.forEach(n=>{this.close(n.id);});},
getDefaultTitle(type){const t={primary:'提示',success:'成功',warning:'警告',error:'错误',info:'信息'};return t[type]||'通知';},
primary(message,title){return this.show({type:'primary',title:title||'提示',message:message});},
success(message,title){return this.show({type:'success',title:title||'成功',message:message});},
warning(message,title){return this.show({type:'warning',title:title||'警告',message:message});},
error(message,title){return this.show({type:'error',title:title||'错误',message:message});},
info(message,title){return this.show({type:'info',title:title||'信息',message:message});}
};
var PageLoader={
_loadedPages:{},
_loadingPages:{},
_resolveAssetUrl(path){
if(typeof window!=='undefined'&&typeof window.__fastbeeResolveAssetUrl==='function'){
return window.__fastbeeResolveAssetUrl(path);
}
return path;
},
async loadPage(pageId,pageMapping){
var moduleName=pageMapping[pageId];
if(!moduleName||this._loadedPages[moduleName])return ;
if(this._loadingPages[moduleName])return this._loadingPages[moduleName];
this._loadingPages[moduleName]=(async()=>{
var resp=await fetch(this._resolveAssetUrl('/pages/'+moduleName+'.html'));
if(!resp.ok)throw new Error('HTTP '+resp.status);
var html=await resp.text();
var container=document.getElementById('content-area');
if(container){
var wrapper=document.createElement('div');
wrapper.innerHTML=html;
while(wrapper.firstChild){
container.appendChild(wrapper.firstChild);
}
}
this._loadedPages[moduleName]=true;
})();
try{
await this._loadingPages[moduleName];
}catch(e){
console.error('[PageLoader] Failed to load:',moduleName,e);
}finally{
delete this._loadingPages[moduleName];
}
},
preloadPages(pageIds,pageMapping,options){
options=options||{};
var delayMs=Number(options.delayMs||180);
var self=this;
return (pageIds||[]).reduce(function (chain ,pageId){
return chain .then(function (){
return self.loadPage(pageId,pageMapping).then(function (){
return new Promise(function (resolve){setTimeout(resolve,delayMs);});
});
});
},Promise.resolve());
},
async loadModals(){
if(this._loadedPages['modals'])return ;
try{
var resp=await fetch(this._resolveAssetUrl('/pages/modals.html'));
if(!resp.ok)return ;
var html=await resp.text();
var wrapper=document.createElement('div');
wrapper.innerHTML=html;
while(wrapper.firstChild){
document.body.appendChild(wrapper.firstChild);
}
this._loadedPages['modals']=true;
}catch(e){
console.error('[PageLoader] Failed to load modals:',e);
}
},
async loadFragment(containerId,fragmentName,onLoaded){
var cacheKey='fragment:'+fragmentName;
if(this._loadedPages[cacheKey]){
if(typeof onLoaded==='function')onLoaded();
return ;
}
try{
var resp=await fetch(this._resolveAssetUrl('/pages/fragments/'+fragmentName+'.html'));
if(!resp.ok)throw new Error('HTTP '+resp.status);
var html=await resp.text();
var container=document.getElementById(containerId);
if(container){
container.innerHTML=html;
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText(container);
}
}
this._loadedPages[cacheKey]=true;
if(typeof onLoaded==='function')onLoaded();
}catch(e){
console.error('[PageLoader] Failed to load fragment:',fragmentName,e);
var container=document.getElementById(containerId);
if(container){
container.innerHTML='<div class="message message-error" data-i18n="fragment-load-error">加载失败，请刷新重试</div>';
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText(container);
}
}
}
},
isLoaded(moduleName){
return !!this._loadedPages[moduleName];
}
};
var ModuleLoader={
_loadedModules:{},
_moduleCallbacks:{},
_loadedFiles:{},
_sequenceLoading:{},
_moduleLoadQueue:[],
_moduleLoadingCount:0,
_MAX_CONCURRENT_LOADS:1,
_sequenceMap:{
'protocol':[
'protocol'
],
'protocol-full-config':[
'protocol-full-config'
],
'protocol-modbus-rtu':[
'protocol-full-config',
'protocol-modbus-rtu'
],
'protocol-modbus-control':[
'protocol-modbus-control'
],
'device-control':[
'device-control'
],
'device-control-runtime':[
'device-control-view',
'device-control-modbus'
],
'periph-exec':[
'periph-exec'
],
'periph-exec-editor':[
'periph-exec',
'periph-exec-modbus',
'periph-exec-form'
]
},
_resolveAssetUrl(path){
if(typeof window!=='undefined'&&typeof window.__fastbeeResolveAssetUrl==='function'){
return window.__fastbeeResolveAssetUrl(path);
}
return path;
},
_completeModuleLoad(name){
var self=this;
self._loadedModules[name]=true;
if(self._moduleCallbacks[name]){
var callbacks=self._moduleCallbacks[name];
delete self._moduleCallbacks[name];
setTimeout(function (){
callbacks.forEach(function (cb){cb();});
},0);
}
},
registerModule(name,methods,target){
var self=this;
var dest=target||(typeof AppState!=='undefined'?AppState:window);
Object.keys(methods).forEach(function (key){
dest[key]=typeof methods[key]==='function'?methods[key].bind(dest):methods[key];
});
self._completeModuleLoad(name);
},
_loadScriptFile(fileName,onSuccess,onFailure){
var self=this;
if(self._loadedFiles[fileName]){
if(typeof onSuccess==='function')onSuccess();
return ;
}
if(self._moduleLoadingCount>=self._MAX_CONCURRENT_LOADS){
setTimeout(function (){
self._loadScriptFile(fileName,onSuccess,onFailure);
},60);
return ;
}
self._moduleLoadingCount++;
self._loadedFiles[fileName]=true;
var oldScript=document.querySelector('script[data-module="'+fileName+'"]');
if(oldScript)oldScript.remove();
var script=document.createElement('script');
script.src=self._resolveAssetUrl('/js/modules/'+fileName+'.js');
script.dataset.module=fileName;
script.onload=function (){
self._moduleLoadingCount--;
if(typeof onSuccess==='function')onSuccess();
setTimeout(function (){
self._processQueue();
},10);
};
script.onerror=function (){
script.remove();
self._moduleLoadingCount--;
delete self._loadedFiles[fileName];
if(typeof onFailure==='function')onFailure();
setTimeout(function (){
self._processQueue();
},60);
};
document.head.appendChild(script);
},
_startSequenceLoad(name){
var self=this;
var files=self._sequenceMap[name];
if(!files||self._sequenceLoading[name])return ;
self._sequenceLoading[name]=true;
function failSequence(){
console.error('[Module] Giving up loading sequence:',name);
delete self._sequenceLoading[name];
delete self._moduleCallbacks[name];
}
function loadNext(index,retries){
if(self._loadedModules[name]){
delete self._sequenceLoading[name];
return ;
}
if(index>=files.length){
self._completeModuleLoad(name);
delete self._sequenceLoading[name];
return ;
}
var fileName=files[index];
self._loadScriptFile(
fileName,
function (){
loadNext(index+1,0);
},
function (){
console.warn('[Module] Failed to load sequence file: '+fileName+' (attempt '+(retries+1)+'/3)');
if(retries<2){
setTimeout(function (){
loadNext(index,retries+1);
},1000);
return ;
}
failSequence();
}
);
}
loadNext(0,0);
},
loadModule(name,callback){
if(this._loadedModules[name]){
if(callback)callback();
return ;
}
if(callback){
if(!this._moduleCallbacks[name])this._moduleCallbacks[name]=[];
this._moduleCallbacks[name].push(callback);
}
if(this._sequenceMap[name]){
this._startSequenceLoad(name);
return ;
}
if(this._moduleLoadQueue.some(function (item){return item.name===name;}))return ;
this._moduleLoadQueue.push({name:name,retries:0});
this._processQueue();
},
_processQueue(){
var self=this;
if(this._moduleLoadingCount>=this._MAX_CONCURRENT_LOADS||this._moduleLoadQueue.length===0)return ;
var item=null;
for(var i=0;i<this._moduleLoadQueue.length;i++){
if(!this._moduleLoadQueue[i].loading){
item=this._moduleLoadQueue[i];
break;
}
}
if(!item)return ;
if(this._loadedModules[item.name]){
this._moduleLoadQueue=this._moduleLoadQueue.filter(function (q){return q.name!==item.name;});
this._processQueue();
return ;
}
var fileName=item.name;
if(self._loadedFiles[fileName]){
item.loading=true;
self._moduleLoadQueue=self._moduleLoadQueue.filter(function (q){return q.name!==item.name;});
self._processQueue();
return ;
}
item.loading=true;
self._loadScriptFile(
fileName,
function (){
self._moduleLoadQueue=self._moduleLoadQueue.filter(function (q){
return !self._loadedModules[q.name];
});
setTimeout(function (){self._processQueue();},10);
},
function (){
console.warn('[Module] Failed to load: '+fileName+' (attempt '+(item.retries+1)+'/3)');
item.loading=false;
if(item.retries<2){
item.retries++;
setTimeout(function (){self._processQueue();},1000);
}else{
console.error('[Module] Giving up loading: '+fileName);
self._moduleLoadQueue=self._moduleLoadQueue.filter(function (q){return q.name!==item.name;});
setTimeout(function (){self._processQueue();},200);
}
}
);
this._processQueue();
},
isLoaded(name){
return !!this._loadedModules[name];
}
};
var ApiPreloader=(function (){
'use strict';
var CRITICAL_APIS=[
'/api/system/info',
'/api/network/config',
'/api/device/config'
];
function uniqueUrls(urls){
var seen={};
return (urls||[]).filter(function (url){
if(!url||seen[url])return false;
seen[url]=true;
return true;
});
}
function shouldPreloadUrl(url){
if(typeof apiGetRequestProfile!=='function')return true;
var profile=apiGetRequestProfile(url);
return !!profile&&profile.tier!=='heavy'&&profile.cacheTtl>0;
}
function pickGetter(url,options){
options=options||{};
var profile=(typeof apiGetRequestProfile==='function')?apiGetRequestProfile(url):null;
var useFresh=options.noCache===true;
var preferSilent=options.silent!==false;
if(profile&&profile.batchSafe){
if(useFresh&&preferSilent&&typeof apiBatchGetSilentFresh==='function')return apiBatchGetSilentFresh;
if(useFresh&&typeof apiBatchGetFresh==='function')return apiBatchGetFresh;
if(preferSilent&&typeof apiBatchGetSilent==='function')return apiBatchGetSilent;
if(typeof apiBatchGet==='function')return apiBatchGet;
}
if(useFresh&&preferSilent&&typeof apiGetSilentFresh==='function')return apiGetSilentFresh;
if(useFresh&&typeof apiGetFresh==='function')return apiGetFresh;
if(preferSilent&&typeof apiGetSilent==='function')return apiGetSilent;
return apiGet;
}
function preloadUrls(urls,options){
return uniqueUrls(urls).filter(shouldPreloadUrl).reduce(function (chain ,url){
return chain .then(function (){
return pickGetter(url,options)(url).catch(function (){
});
});
},Promise.resolve());
}
function preloadCriticalData(){
if(typeof apiGet!=='function'){
console.warn('[Preloader] apiGet not available, skip preload');
return Promise.resolve();
}
return preloadUrls(CRITICAL_APIS,{silent:true});
}
function preloadPageData(pageKey,options){
options=options||{};
if(typeof FastBeePageRequestContracts==='undefined'){
return Promise.resolve();
}
var contract=FastBeePageRequestContracts[pageKey];
if(!contract)return Promise.resolve();
var urls=[].concat(contract.firstScreen||[]);
if(options.includeDeferred===true){
urls=urls.concat(contract.deferred||[]);
}
return preloadUrls(urls,{silent:true,noCache:options.noCache===true});
}
function getData(url,params){
if(typeof apiGet!=='function'){
return Promise.reject(new Error('apiGet not available'));
}
return apiGet(url,params);
}
function invalidate(url){
if(typeof apiInvalidateCache==='function'){
apiInvalidateCache(url);
}
}
function clearAll(){
if(typeof apiInvalidateCache==='function'){
apiInvalidateCache();
}
}
function getCriticalAPIs(){
return CRITICAL_APIS.slice();
}
return {
preloadCriticalData:preloadCriticalData,
getData:getData,
invalidate:invalidate,
clearAll:clearAll,
getCriticalAPIs:getCriticalAPIs,
preloadPageData:preloadPageData
};
})();