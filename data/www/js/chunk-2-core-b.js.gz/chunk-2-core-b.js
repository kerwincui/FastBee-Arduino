const Notification={
container:null,notifications:[],
init(){
this.container=document.getElementById('notification-container');
if(!this.container){this.container=document.createElement('div');this.container.id='notification-container';this.container.className='notification-container';document.body.appendChild(this.container);}
},
show(options){
const id='notification-'+Date.now();const duration=options.duration||3000;
const notification=document.createElement('div');notification.id=id;
notification.className='notification notification-'+(options.type||'info');
const icons={primary:'✅',success:'✅',warning:'⚠️',error:'❌',info:'ℹ️'};
const header=document.createElement('div');
header.className='notification-header';
const title=document.createElement('div');
title.className='notification-title';
const icon=document.createElement('i');
icon.textContent=icons[options.type]||icons.info;
const titleText=document.createElement('span');
titleText.textContent=options.title||this.getDefaultTitle(options.type);
title.appendChild(icon);
title.appendChild(titleText);
const closeBtn=document.createElement('button');
closeBtn.type='button';
closeBtn.className='notification-close';
closeBtn.textContent='×';
closeBtn.addEventListener('click',()=>this.close(id));
header.appendChild(title);
header.appendChild(closeBtn);
const body=document.createElement('div');
body.className='notification-body';
if(options.html===true){body.innerHTML=options.message||'';}
else{body.textContent=options.message||'';}
const progress=document.createElement('div');
progress.className='notification-progress';
const progressBar=document.createElement('div');
progressBar.className='notification-progress-bar';
progressBar.style.setProperty('--notification-duration',duration+'ms');
progress.appendChild(progressBar);
notification.appendChild(header);
notification.appendChild(body);
notification.appendChild(progress);
this.container.appendChild(notification);
const notificationObj={id:id,element:notification,timeout:null};this.notifications.push(notificationObj);
if(options.autoClose!==false){notificationObj.timeout=setTimeout(()=>{this.close(id);},duration);}
return id;
},
close(id){
const notification=document.getElementById(id);
if(notification){notification.classList.add('hiding');
const notificationObj=this.notifications.find(n=>n.id===id);
if(notificationObj&&notificationObj.timeout){clearTimeout(notificationObj.timeout);}
setTimeout(()=>{if(notification.parentNode){notification.parentNode.removeChild(notification);}this.notifications=this.notifications.filter(n=>n.id!==id);},300);
}
},
closeAll(){this.notifications.forEach(n=>{this.close(n.id);});},
getDefaultTitle(type){const t={primary:'提示',success:'成功',warning:'警告',error:'错误',info:'信息'};return t[type]||'通知';},
primary(message,title){return this.show({type:'primary',title:title||'提示',message:message});},
success(message,title){return this.show({type:'success',title:title||'成功',message:message});},
warning(message,title){return this.show({type:'warning',title:title||'警告',message:message});},
error(message,title){return this.show({type:'error',title:title||'错误',message:message});},
info(message,title){return this.show({type:'info',title:title||'信息',message:message});}
};
var PageLoader={
_loadedPages:{},
async loadPage(pageId,pageMapping){
var moduleName=pageMapping[pageId];
if(!moduleName||this._loadedPages[moduleName])return ;
try{
var resp=await fetch('/pages/'+moduleName+'.html');
if(!resp.ok)throw new Error('HTTP '+resp.status);
var html=await resp.text();
var container=document.getElementById('content-area');
if(container){
var wrapper=document.createElement('div');
wrapper.innerHTML=html;
while(wrapper.firstChild){
container.appendChild(wrapper.firstChild);
}
}
this._loadedPages[moduleName]=true;
}catch(e){
console.error('[PageLoader] Failed to load:',moduleName,e);
}
},
async loadModals(){
if(this._loadedPages['modals'])return ;
try{
var resp=await fetch('/pages/modals.html');
if(!resp.ok)return ;
var html=await resp.text();
var wrapper=document.createElement('div');
wrapper.innerHTML=html;
while(wrapper.firstChild){
document.body.appendChild(wrapper.firstChild);
}
this._loadedPages['modals']=true;
}catch(e){
console.error('[PageLoader] Failed to load modals:',e);
}
},
async loadFragment(containerId,fragmentName,onLoaded){
var cacheKey='fragment:'+fragmentName;
if(this._loadedPages[cacheKey]){
if(typeof onLoaded==='function')onLoaded();
return ;
}
try{
var resp=await fetch('/pages/fragments/'+fragmentName+'.html');
if(!resp.ok)throw new Error('HTTP '+resp.status);
var html=await resp.text();
var container=document.getElementById(containerId);
if(container){
container.innerHTML=html;
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText(container);
}
}
this._loadedPages[cacheKey]=true;
if(typeof onLoaded==='function')onLoaded();
}catch(e){
console.error('[PageLoader] Failed to load fragment:',fragmentName,e);
var container=document.getElementById(containerId);
if(container){
container.innerHTML='<div class="message message-error" data-i18n="fragment-load-error">加载失败，请刷新重试</div>';
if(typeof i18n!=='undefined'&&i18n.updatePageText){
i18n.updatePageText(container);
}
}
}
},
isLoaded(moduleName){
return !!this._loadedPages[moduleName];
}
};
var ModuleLoader={
_loadedModules:{},
_moduleCallbacks:{},
_loadedFiles:{},
_moduleLoadQueue:[],
_moduleLoadingCount:0,
_MAX_CONCURRENT_LOADS:4,
_bundleMap:{
'users':'admin-bundle',
'roles':'admin-bundle',
'files':'admin-bundle',
'logs':'admin-bundle',
'rule-script':'admin-bundle'
},
registerModule(name,methods,target){
var self=this;
var dest=target||(typeof AppState!=='undefined'?AppState:window);
Object.keys(methods).forEach(key=>{
dest[key]=typeof methods[key]==='function'?methods[key].bind(dest):methods[key];
});
self._loadedModules[name]=true;
if(self._moduleCallbacks[name]){
var cbs=self._moduleCallbacks[name];
delete self._moduleCallbacks[name];
setTimeout(function (){
cbs.forEach(function (cb){cb();});
},0);
}
},
loadModule(name,callback){
var self=this;
if(this._loadedModules[name]){
if(callback)callback();
return ;
}
if(callback){
if(!this._moduleCallbacks[name])this._moduleCallbacks[name]=[];
this._moduleCallbacks[name].push(callback);
}
if(this._moduleLoadQueue.some(function (item){return item.name===name;}))return ;
this._moduleLoadQueue.push({name:name,retries:0});
this._processQueue();
},
_processQueue(){
var self=this;
if(this._moduleLoadingCount>=this._MAX_CONCURRENT_LOADS||this._moduleLoadQueue.length===0)return ;
var item=null;
for(var i=0;i<this._moduleLoadQueue.length;i++){
if(!this._moduleLoadQueue[i].loading){
item=this._moduleLoadQueue[i];
break;
}
}
if(!item)return ;
if(this._loadedModules[item.name]){
this._moduleLoadQueue=this._moduleLoadQueue.filter(q=>q.name!==item.name);
this._processQueue();
return ;
}
var fileName=self._bundleMap[item.name]||item.name;
if(self._loadedFiles[fileName]){
item.loading=true;
self._moduleLoadQueue=self._moduleLoadQueue.filter(q=>q.name!==item.name);
self._processQueue();
return ;
}
item.loading=true;
this._moduleLoadingCount++;
self._loadedFiles[fileName]=true;
var oldScript=document.querySelector('script[data-module="'+fileName+'"]');
if(oldScript)oldScript.remove();
var script=document.createElement('script');
script.src='/js/modules/'+fileName+'.js';
script.dataset.module=fileName;
script.onload=function (){
self._moduleLoadingCount--;
self._moduleLoadQueue=self._moduleLoadQueue.filter(function (q){
return !self._loadedModules[q.name];
});
setTimeout(function (){self._processQueue();},10);
};
script.onerror=function (){
console.warn('[Module] Failed to load: '+fileName+' (attempt '+(item.retries+1)+'/3)');
script.remove();
self._moduleLoadingCount--;
item.loading=false;
delete self._loadedFiles[fileName];
if(item.retries<2){
item.retries++;
setTimeout(function (){self._processQueue();},1000);
}else{
console.error('[Module] Giving up loading: '+fileName);
self._moduleLoadQueue=self._moduleLoadQueue.filter(q=>q.name!==item.name);
setTimeout(function (){self._processQueue();},200);
}
};
document.head.appendChild(script);
this._processQueue();
},
isLoaded(name){
return !!this._loadedModules[name];
}
};