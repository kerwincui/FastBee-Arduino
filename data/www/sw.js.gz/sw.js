// FastBee Service Worker - Auto-generated from sw.js.template
var CACHE_VERSION = 'v20260506-2327-6e796214';
var CACHE_NAME = 'fastbee-' + CACHE_VERSION;
var PRECACHE_URLS = [
    '/',
    '/404.html',
    '/assets/favicon.ico',
    '/assets/logo.png',
    '/css/main.css',
    '/index.html',
    '/js/api-preloader.js',
    '/js/app-bundle.js',
    '/js/main.js',
    '/js/module-loader.js',
    '/js/modules/admin-bundle.js',
    '/js/modules/dashboard-fullscreen.js',
    '/js/modules/dashboard.js',
    '/js/modules/device-config.js',
    '/js/modules/device-control.js',
    '/js/modules/device-control/core.js',
    '/js/modules/device-control/layout.js',
    '/js/modules/device-control/modbus-ctrl.js',
    '/js/modules/device-control/modbus-ops.js',
    '/js/modules/device-control/render.js',
    '/js/modules/files.js',
    '/js/modules/i18n-en.js',
    '/js/modules/i18n-engine.js',
    '/js/modules/i18n-zh-CN.js',
    '/js/modules/logs.js',
    '/js/modules/network.js',
    '/js/modules/periph-exec-form.js',
    '/js/modules/periph-exec-modbus.js',
    '/js/modules/periph-exec.js',
    '/js/modules/peripherals.js',
    '/js/modules/protocol.js',
    '/js/modules/protocol/common.js',
    '/js/modules/protocol/modbus-config.js',
    '/js/modules/protocol/modbus-control.js',
    '/js/modules/protocol/modbus-relay-motor.js',
    '/js/modules/protocol/mqtt-config.js',
    '/js/modules/protocol/protocol-config.js',
    '/js/modules/roles.js',
    '/js/modules/rule-script.js',
    '/js/modules/users.js',
    '/js/notification.js',
    '/js/page-loader.js',
    '/js/request-governor.js',
    '/js/state-session.js',
    '/js/state-sse.js',
    '/js/state-theme.js',
    '/js/state-ui.js',
    '/js/state.js',
    '/js/ui-components.js',
    '/js/utils.js',
    '/pages/admin.html',
    '/pages/dashboard.html',
    '/pages/device.html',
    '/pages/fragments/device-ota.html',
    '/pages/fragments/protocol-coap.html',
    '/pages/fragments/protocol-http.html',
    '/pages/fragments/protocol-modbus-rtu.html',
    '/pages/fragments/protocol-mqtt.html',
    '/pages/fragments/protocol-tcp.html',
    '/pages/fullscreen.html',
    '/pages/modals.html',
    '/pages/network.html',
    '/pages/peripheral.html',
    '/pages/protocol.html',
    '/pages/rule-script.html',
    '/setup.html'
];
var MAX_IMG_ENTRIES = 30;

function sequentialCache(cache, urls) {
    var i = 0;
    function next() {
        if (i >= urls.length) return Promise.resolve();
        var url = urls[i++];
        return fetch(url).then(function(r) {
            if (r.ok) return cache.put(url, r);
        }).catch(function() {}).then(function() {
            return new Promise(function(r) { setTimeout(r, 100); });
        }).then(next);
    }
    return next();
}

function trimCache(cache) {
    return cache.keys().then(function(k) {
        if (k.length <= MAX_IMG_ENTRIES) return;
        return Promise.all(k.slice(0, k.length - MAX_IMG_ENTRIES).map(function(r) {
            return cache.delete(r);
        }));
    });
}

function offline() {
    return caches.match('/404.html.gz').then(function(r) {
        return r || new Response('Offline', { status: 503 });
    });
}

// 缓存过期检测 - 基于缓存响应的Date头或自定义时间戳
function isStaleCache(response, maxAgeMs) {
    if (!response) return true;
    var dateHeader = response.headers.get('date') || response.headers.get('sw-cached-at');
    if (!dateHeader) return true;
    var cacheTime = new Date(dateHeader).getTime();
    return (Date.now() - cacheTime) > (maxAgeMs || 86400000); // 默认24小时
}

function staleWhileRevalidate(event, trim) {
    return caches.match(event.request).then(function(cached) {
        var fetchPromise = fetch(event.request).then(function(resp) {
            if (resp.ok) {
                var clone = resp.clone();
                caches.open(CACHE_NAME).then(function(c) {
                    c.put(event.request, clone);
                    if (trim) trimCache(c);
                });
            }
            return resp;
        });
        // 有缓存且未过期：立即返回缓存，后台更新
        // 无缓存或已过期：等待网络
        if (cached && !isStaleCache(cached, 86400000)) {
            fetchPromise.catch(function(){}); // 后台静默更新
            return cached;
        }
        return fetchPromise.catch(function() { return cached || offline(); });
    });
}

self.addEventListener('install', function() { self.skipWaiting(); });

self.addEventListener('activate', function(e) {
    e.waitUntil(
        self.clients.claim().then(function() {
            return caches.keys().then(function(names) {
                return Promise.all(
                    names.filter(function(n) {
                        return n.startsWith('fastbee-') && n !== CACHE_NAME;
                    }).map(function(n) { return caches.delete(n); })
                );
            });
        }).then(function() {
            setTimeout(function() {
                caches.open(CACHE_NAME).then(function(c) {
                    sequentialCache(c, PRECACHE_URLS);
                });
            }, 5000);
        })
    );
});

self.addEventListener('fetch', function(e) {
    var url = new URL(e.request.url);
    if (url.origin !== self.location.origin) return;

    // SSE: pass through, never cache
    if (url.pathname === '/api/events') return;
    var accept = e.request.headers.get('Accept') || '';
    if (accept.indexOf('text/event-stream') !== -1) return;

    // API: Network First
    if (url.pathname.startsWith('/api/')) {
        e.respondWith(
            fetch(e.request).then(function(resp) {
                if (resp.ok) {
                    var clone = resp.clone();
                    caches.open(CACHE_NAME).then(function(c) { c.put(e.request, clone); });
                }
                return resp;
            }).catch(function() {
                return caches.match(e.request).then(function(c) { return c || offline(); });
            })
        );
        return;
    }

    // Static: Stale-While-Revalidate
    var ext = url.pathname.split('.').pop().split('?')[0].toLowerCase();
    var isStatic = ext === 'css' || ext === 'js' || ext === 'html';
    var isMedia = ext === 'png' || ext === 'jpg' || ext === 'jpeg' ||
        ext === 'gif' || ext === 'ico' || ext === 'svg' ||
        ext === 'woff' || ext === 'woff2' || ext === 'ttf';

    if (isStatic || isMedia) {
        e.respondWith(staleWhileRevalidate(e, isMedia));
        return;
    }

    // Navigation: Stale-While-Revalidate
    if (e.request.mode === 'navigate' || accept.indexOf('text/html') !== -1) {
        e.respondWith(staleWhileRevalidate(e, false));
        return;
    }

    // Default: Stale-While-Revalidate
    e.respondWith(staleWhileRevalidate(e, false));
});
