// FastBee Service Worker - auto-generated, do not edit
const CACHE_NAME = 'fastbee-' + 'v20260628-0227-3f6d4262';
const PRECACHE_URLS = [
    '/',
    '/assets/logo.png',
    '/css/main.css',
    '/index.html',
    '/js/chunk-1-core-a.js',
    '/js/chunk-2-core-b.js',
    '/js/chunk-3-i18n-engine.js',
    '/js/chunk-8-state-1.js',
    '/js/chunk-9-state-2.js'
];

/**
 * Stamp cached responses with an `sw-cached-at` header so the client
 * can determine when a resource was placed in the cache.
 */
function withCacheTimestamp(response) {
  if (!response || response.status !== 200) return response;
  if (response.headers.get('date') || response.headers.get('sw-cached-at')) return response;
  try {
    const headers = new Headers(response.headers);
    headers.set('sw-cached-at', new Date().toUTCString());
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers: headers
    });
  } catch (_) {
    return response;
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(
        names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        if (!response || response.status !== 200) return response;
        const clone = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, withCacheTimestamp(clone)));
        return response;
      });
    }).catch(() => caches.match('/'))
  );
});
