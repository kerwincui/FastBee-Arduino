// FastBee Service Worker - Auto-generated from sw.js.template
var CACHE_VERSION = 'v20260612-1642-9372d967';
var CACHE_NAME = 'fastbee-' + CACHE_VERSION;
var PRECACHE_URLS = [
    '/',
    '/assets/logo.png',
    '/css/main.css',
    '/index.html',
    '/js/chunk-1-core-a.js',
    '/js/chunk-2-core-b.js',
    '/js/chunk-3-i18n-engine.js',
    '/js/chunk-8-state-1.js',
    '/js/chunk-9-state-2.js'
];
var MAX_IMG_ENTRIES = 30;

function sequentialCache(cache, urls) {
    var i = 0;
    function next() {
        if (i >= urls.length) return Promise.resolve();
        var url = urls[i++];
        return fetch(url).then(function(r) {
            if (r.ok) return cache.put(url, withCacheTimestamp(r));
        }).catch(function() {}).then(function() {
            // 500ms 间隔：ESP32 处理 chunk 需要时间释放 heap，避免预缓存与首屏加载冲突
            return new Promise(function(r) { setTimeout(r, 500); });
        }).then(next);
    }
    return next();
}

function trimCache(cache) {
    return cache.keys().then(function(k) {
        if (k.length <= MAX_IMG_ENTRIES) return;
        return Promise.all(k.slice(0, k.length - MAX_IMG_ENTRIES).map(function(r) {
            return cache.delete(r);
        }));
    });
}

function offline() {
    return caches.match('/404.html.gz').then(function(r) {
        return r || new Response('Offline', { status: 503 });
    });
}

function withCacheTimestamp(response) {
    if (!response) return response;
    if (response.headers.get('date') || response.headers.get('sw-cached-at')) return response;

    try {
        var headers = new Headers(response.headers);
        headers.set('sw-cached-at', new Date().toUTCString());
        return new Response(response.body, {
            status: response.status,
            statusText: response.statusText,
            headers: headers
        });
    } catch (err) {
        return response;
    }
}
// 缓存过期检测 - 基于缓存响应的Date头或自定义时间戳
function isStaleCache(response, maxAgeMs) {
    if (!response) return true;
    var dateHeader = response.headers.get('date') || response.headers.get('sw-cached-at');
    if (!dateHeader) return true;
    var cacheTime = new Date(dateHeader).getTime();
    return (Date.now() - cacheTime) > (maxAgeMs || 86400000); // 默认24小时
}

function staleWhileRevalidate(event, trim) {
    return caches.match(event.request).then(function(cached) {
        var fetchPromise = fetch(event.request).then(function(resp) {
            if (resp.ok) {
                var clone = resp.clone();
                caches.open(CACHE_NAME).then(function(c) {
                    c.put(event.request, withCacheTimestamp(clone));
                    if (trim) trimCache(c);
                });
            }
            return resp;
        });
        // 有缓存且未过期：立即返回缓存，后台更新
        // 无缓存或已过期：等待网络
        if (cached && !isStaleCache(cached, 86400000)) {
            fetchPromise.catch(function(){}); // 后台静默更新
            return cached;
        }
        return fetchPromise.catch(function() { return cached || offline(); });
    });
}

function networkFirst(event, trim) {
    return fetch(event.request).then(function(resp) {
        if (resp.ok) {
            var clone = resp.clone();
            caches.open(CACHE_NAME).then(function(c) {
                c.put(event.request, withCacheTimestamp(clone));
                if (trim) trimCache(c);
            });
        }
        return resp;
    }).catch(function() {
        return caches.match(event.request).then(function(cached) {
            return cached || offline();
        });
    });
}

self.addEventListener('install', function() { self.skipWaiting(); });

self.addEventListener('activate', function(e) {
    e.waitUntil(
        self.clients.claim().then(function() {
            return caches.keys().then(function(names) {
                return Promise.all(
                    names.filter(function(n) {
                        return n.startsWith('fastbee-') && n !== CACHE_NAME;
                    }).map(function(n) { return caches.delete(n); })
                );
            });
        }).then(function() {
            // 延迟 30s 后才开始预缓存，确保首屏 9 个 chunk 完全加载完成后再背景拉其他资源
            setTimeout(function() {
                caches.open(CACHE_NAME).then(function(c) {
                    sequentialCache(c, PRECACHE_URLS);
                });
            }, 30000);
        })
    );
});

self.addEventListener('fetch', function(e) {
    var url = new URL(e.request.url);
    if (url.origin !== self.location.origin) return;

    // SSE: pass through, never cache
    if (url.pathname === '/api/events') return;
    var accept = e.request.headers.get('Accept') || '';
    if (accept.indexOf('text/event-stream') !== -1) return;

    // API: pass through, never cache.
    // Returning stale API payloads makes "device offline" look like "UI still online",
    // which hides the real root cause when ESP32 web access is unstable.
    if (url.pathname.startsWith('/api/')) {
        return;
    }

    // Navigation: network-first so index.html never pins an old asset version.
    if (e.request.mode === 'navigate' || accept.indexOf('text/html') !== -1) {
        e.respondWith(networkFirst(e, false));
        return;
    }

    // Static: Stale-While-Revalidate
    var ext = url.pathname.split('.').pop().split('?')[0].toLowerCase();
    var isStatic = ext === 'css' || ext === 'js' || ext === 'html';
    var isMedia = ext === 'png' || ext === 'jpg' || ext === 'jpeg' ||
        ext === 'gif' || ext === 'ico' || ext === 'svg' ||
        ext === 'woff' || ext === 'woff2' || ext === 'ttf';

    if (isStatic || isMedia) {
        e.respondWith(staleWhileRevalidate(e, isMedia));
        return;
    }

    // Default: Stale-While-Revalidate
    e.respondWith(staleWhileRevalidate(e, false));
});
